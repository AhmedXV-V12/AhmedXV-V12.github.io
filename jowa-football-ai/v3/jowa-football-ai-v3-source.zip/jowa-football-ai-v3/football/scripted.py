"""Rule-based football AI operating in the *same action space* as the learned policy.

Uses:
* benchmark opponent for evaluation (win-rate vs scripted is tracked through training),
* weakened opponent for the early curriculum (``skill`` < 1 mixes in random valid actions),
* optional "kickstarting" teacher whose imitation loss decays to zero early in training.

It is deliberately simple: the learned policy is expected to surpass it.
"""
from __future__ import annotations

import numpy as np

from . import actions as A
from . import geometry as G
from . import tactics as T
from .formation import GK, ST, WM, CB

HL = G.HL


def _dribble_dir(v, i) -> int:
    """Pick the dribble direction balancing progress and distance from opponents."""
    p = v.P[i]
    best, best_s = A.MOVE_START, -1e9
    for k in range(A.NUM_DIRS):
        d = A.DIRECTIONS[k]
        q = p + d * 4.0
        if abs(q[1]) > G.HW - 1.5 or q[0] > HL - 1.0:
            continue
        clearance = np.min(G.norm(v.O - q, axis=1))
        s = 1.2 * d[0] + 0.35 * min(clearance, 6.0) - 0.1 * abs(q[1]) / G.HW
        if s > best_s:
            best, best_s = A.MOVE_START + k, s
    return best


def _carrier_action(env, v, i, m, rng, deterministic) -> int:
    opts = v.passes
    b = v.b
    is_gk = env.form.roles[i] == GK
    if m[A.SHOOT] and (v.shot_xg > 0.11 or (v.shot_xg > 0.06 and b[0] > HL - 16.5)):
        return A.SHOOT
    ev = np.maximum(opts.ev_feet, opts.ev_thr)
    ev = np.where(opts.valid, ev, -9.0)
    pbest = np.maximum(opts.p_feet, opts.p_thr)
    cur = float(G.xt(b[0], b[1]))
    passable = [j for j in range(11)
                if m[A.PASS_FEET_START + j] or m[A.PASS_THROUGH_START + j]]
    if passable:
        j = max(passable, key=lambda k: ev[k] + (rng.normal(0, 0.004) if not deterministic else 0))
        use_thr = opts.ev_thr[j] > opts.ev_feet[j] and m[A.PASS_THROUGH_START + j]
        a = (A.PASS_THROUGH_START if use_thr else A.PASS_FEET_START) + j
        safe = [k for k in passable if pbest[k] > 0.8]
        if is_gk or env.dead:
            if pbest[j] > 0.55:
                return a
            if safe:
                k = max(safe, key=lambda s: ev[s])
                return A.PASS_FEET_START + k
            return A.CLEAR if m[A.CLEAR] else a
        if ev[j] > cur * 1.1 + 0.002 and pbest[j] > 0.6:
            return a
        if v.carrier_pressure > 0.6:
            if b[0] < -HL / 3 and m[A.CLEAR]:
                return A.CLEAR
            if safe:
                return A.PASS_FEET_START + max(safe, key=lambda s: ev[s])
    if m[A.MOVE_START]:
        return _dribble_dir(v, i)
    return int(np.argmax(m))


def scripted_team_actions(env, t: int, skill: float = 1.0, deterministic: bool = False):
    v = env.views[t]
    m_all = env.masks[t]
    rng = env.rng
    roles = env.form.roles
    out = np.zeros(11, dtype=np.int64)
    gk = env.form.gk_index
    rand_p = 0.0 if deterministic else (1.0 - skill) * 0.7
    base = 11 * t
    for i in range(11):
        m = m_all[i]
        if rand_p > 0 and rng.random() < rand_p:
            out[i] = int(rng.choice(np.flatnonzero(m)))
            continue
        a = A.STAND
        if env.dead and base + i == env.sp_taker:
            a = A.STAND if m[A.STAND] and env.sp_timer < 2.0 else _carrier_action(
                env, v, i, m, rng, deterministic)
        elif v.carrier == i:
            a = _carrier_action(env, v, i, m, rng, deterministic)
        elif env.dead:
            if env.sp_team == t:
                a = A.SUPPORT if (m[A.SUPPORT] and roles[i] in (ST, WM)) else A.TO_ANCHOR
            else:
                a = A.MARK if (m[A.MARK] and v.mark_assign[i] >= 0) else A.TO_ANCHOR
        elif i == gk:
            if m[A.INTERCEPT] and v.rank[i] == 0 and v.t2b[i] < v.opp_t2b.min():
                a = A.INTERCEPT
            elif m[A.PRESS] and v.opp_carrier >= 0 and \
                    G.norm(v.P[i] - v.O[v.opp_carrier]) < 8.0:
                a = A.PRESS
            else:
                a = A.TO_ANCHOR
        elif v.possession == 1:
            if v.carrier < 0 and m[A.INTERCEPT] and v.rank[i] == 0:
                a = A.INTERCEPT       # receive the pass in flight
            elif roles[i] == ST and m[A.RUN_BEHIND] and not v.offside_pos[i] and \
                    v.b[0] > -15.0 and rng.random() < (0.25 if not deterministic else 0.0):
                a = A.RUN_BEHIND
            elif roles[i] == ST and v.offside_pos[i]:
                a = A.RUN_BEHIND      # target is back onside
            elif roles[i] != CB and G.norm(v.P[i] - v.b) < 28.0 and m[A.SUPPORT]:
                a = A.SUPPORT
            else:
                a = A.TO_ANCHOR
        elif v.possession == -1:
            if v.rank[i] == 0:
                a = A.TACKLE if (m[A.TACKLE] and (deterministic or rng.random() < 0.6)) \
                    else A.PRESS
            elif v.rank[i] == 1:
                a = A.COVER
            elif v.mark_assign[i] >= 0 and m[A.MARK]:
                a = A.MARK
            else:
                a = A.TO_ANCHOR
        else:   # loose ball
            if v.rank[i] == 0 and m[A.INTERCEPT]:
                a = A.INTERCEPT
            elif v.rank[i] == 1 and m[A.INTERCEPT] and v.t2b[i] < v.opp_t2b.min() + 0.5:
                a = A.INTERCEPT
            else:
                a = A.TO_ANCHOR
        if not m[a]:
            a = A.TO_ANCHOR if m[A.TO_ANCHOR] else int(np.flatnonzero(m)[0])
        out[i] = a
    return out
