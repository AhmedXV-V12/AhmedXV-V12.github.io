"""Entity-based observations.

Each team receives a set of 24 tokens (team frame, the team always attacks +x):

    [0]      context token   - score, clock, possession, tactical phase, coach instruction,
                               set piece, team shapes of both sides
    [1]      ball token      - position, velocity, height, predicted trajectory, possession
    [2..12]  own players     - self state, role, anchor/zone, openness, pass-option evaluation
    [13..23] opponents       - state, role, threat, how tightly marked, offside position

plus (24, 2) token positions used for a geometric attention bias, role ids and the previous
action of every player. The policy transformer outputs one decision per own-player token, so
the representation scales naturally with the number of entities and never needs a huge flat
state vector. Token feature slots are fixed-width (F = 56) with unused slots left at 0.
"""
from __future__ import annotations

import numpy as np

from . import actions as A
from . import geometry as G
from . import tactics as T
from .formation import GK, NUM_ROLES

HL, HW = G.HL, G.HW
N_TOKENS = 24
F = 56
CTX, BALL, OWN0, OPP0 = 0, 1, 2, 13
PAD_ACTION = A.NUM_ACTIONS          # prev-action id for ball/context tokens
PAD_ROLE = NUM_ROLES                # role id for ball/context tokens


def _player_block(v: T.TeamView, env, team: int, own: bool) -> np.ndarray:
    out = np.zeros((11, F), dtype=np.float32)
    P, V = (v.P, v.V) if own else (v.O, v.OV)
    sl = slice(0, 11) if (team == 0) == own else slice(11, 22)
    b = v.b
    out[:, 0] = P[:, 0] / HL
    out[:, 1] = P[:, 1] / HW
    out[:, 2:4] = V / 8.0
    out[:, 4] = G.norm(V) / 8.0
    out[:, 5] = env.stamina[sl]
    carrier = v.carrier if own else v.opp_carrier
    if carrier >= 0:
        out[carrier, 6] = 1.0
    d = b - P
    out[:, 7] = G.norm(d) / 50.0
    out[:, 8:10] = d / 50.0
    t2b = v.t2b if own else v.opp_t2b
    out[:, 10] = np.clip(t2b / 5.0, 0.0, 2.0)
    if own:
        out[:, 11] = v.rank / 10.0
        out[:, 12] = v.anchors[:, 0] / HL
        out[:, 13] = v.anchors[:, 1] / HW
        out[:, 14:16] = (P - v.anchors) / 20.0
    else:
        order = np.argsort(t2b, kind="stable")
        r = np.empty(11)
        r[order] = np.arange(11)
        out[:, 11] = r / 10.0
    out[:, 16] = G.norm(P - np.array([-HL, 0.0])) / 105.0
    out[:, 17] = G.norm(P - np.array([HL, 0.0])) / 105.0
    if own:
        out[:, 18] = G.xg_raw(P[:, 0], P[:, 1])
        out[:, 19] = G.xt(P[:, 0], P[:, 1]) * 4.0
        out[:, 20] = v.openness
        out[:, 21] = v.offside_pos
    else:
        out[:, 18] = G.xg_raw(-P[:, 0], -P[:, 1])
        out[:, 19] = v.opp_threat * 4.0
        out[:, 20] = v.opp_openness
        out[:, 21] = v.opp_offside_pos
    out[:, 22] = (env.stun[sl] > 0) | (env.kick_cd[sl] > 0)
    # pass-option evaluation from this token's team carrier
    po = v.passes if own else v.opp_passes
    if carrier >= 0:
        out[:, 23] = po.p_feet
        out[:, 24] = po.p_thr
        out[:, 25] = po.ev_feet * 5.0
        out[:, 26] = po.ev_thr * 5.0
        out[:, 27] = np.clip(po.prog_feet, -2, 2)
        out[:, 28] = np.clip(po.prog_thr, -2, 2)
        out[:, 29] = po.loft_feet
        out[:, 30] = po.loft_thr
        out[:, 31] = po.thr_target[:, 0] / HL
        out[:, 32] = po.thr_target[:, 1] / HW
    k = env.kick
    if k.kind in ("pass", "through") and k.target >= 0 and (k.target // 11 == team) == own:
        out[k.target % 11, 33] = 1.0
    out[:, 34] = G.in_penalty_area(P[:, 0], P[:, 1])
    out[:, 35] = G.in_penalty_area(P[:, 0], P[:, 1], attacking=True)
    out[:, 36:38] = env.facing[sl] * v.attack_dir
    lt = env.last_touch
    if lt >= 0 and (lt // 11 == team) == own:
        out[lt % 11, 38] = 1.0
    if own:
        has = v.mark_assign >= 0
        out[:, 39] = has
        dm = np.ones(11)
        dm[has] = G.norm(P[has] - v.O[v.mark_assign[has]]) / 10.0
        out[:, 40] = np.clip(dm, 0, 2)
        out[:, 41] = np.clip(G.norm(P - v.anchors) / 15.0, 0, 3)
        out[:, 42] = v.engaged
        out[:, 44] = env.masks[team][:, A.TACKLE] if env.masks is not None else 0.0
        out[:, 45] = np.clip((v.anchors[:, 0] - b[0]) / 30.0, -2, 2)
    else:
        out[:, 39] = v.opp_marked
    roles = env.form.roles
    out[:, 43] = roles == GK
    return out


def _ball_token(v: T.TeamView, env, team: int) -> np.ndarray:
    out = np.zeros(F, dtype=np.float32)
    b, bv = v.b, v.bv
    out[0], out[1] = b[0] / HL, b[1] / HW
    out[2:4] = bv / 30.0
    out[4] = G.norm(bv) / 30.0
    out[5] = env.bz / 3.0
    out[6] = env.bvz / 10.0
    out[7] = env.possessor >= 0
    out[8] = v.carrier >= 0
    out[9] = v.opp_carrier >= 0
    out[10] = env.possessor < 0 and not env.dead
    out[11] = env.dead
    if env.possessor < 0:
        pts, _ = T.predict_ball_path(b, bv, env.bz, env.bvz, phys=env.phys)
        idx = [3, 6, 10]            # 0.6 s, 1.2 s, 2.0 s
        out[12:18] = (pts[idx] / np.array([HL, HW])).reshape(-1)
    else:
        out[12:18] = np.tile(out[0:2], 3)
    k = env.kick
    out[18] = env.flight_team == team
    out[19] = env.flight_team == 1 - team
    out[20] = k.kind == "shot"
    out[21] = G.xt(b[0], b[1]) * 4.0
    out[22] = G.xt(-b[0], -b[1]) * 4.0
    out[23] = G.norm(b - np.array([-HL, 0.0])) / 105.0
    out[24] = G.norm(b - np.array([HL, 0.0])) / 105.0
    out[25] = G.in_penalty_area(b[0], b[1])
    out[26] = G.in_penalty_area(b[0], b[1], attacking=True)
    out[27] = v.shot_xg
    out[28] = v.carrier_pressure
    # probability that we win a loose ball (1/0 when someone already has it)
    if v.carrier >= 0:
        out[29] = 1.0
    elif v.opp_carrier >= 0:
        out[29] = 0.0
    else:
        out[29] = float(G.sigmoid((v.opp_t2b.min() - v.t2b.min()) / 0.6))
    out[30] = min(v.t2b.min(), 5.0) / 5.0
    out[31] = min(v.opp_t2b.min(), 5.0) / 5.0
    return out


def _context_token(v: T.TeamView, env, team: int) -> np.ndarray:
    out = np.zeros(F, dtype=np.float32)
    s_own, s_opp = env.score[team], env.score[1 - team]
    out[0] = s_own / 5.0
    out[1] = s_opp / 5.0
    out[2] = np.clip((s_own - s_opp) / 3.0, -1, 1)
    hd = env.rules.half_duration_s
    out[3] = env.t_half / hd
    out[4] = env.half
    out[5] = (env.half * hd + env.t_half) / (2 * hd)
    out[6 + {1: 0, -1: 1, 0: 2}[v.possession]] = 1.0
    ts = env.tactics[team]
    out[9] = min(ts.time_in_possession_state / 10.0, 2.0)
    out[10 + v.phase] = 1.0
    out[21 + ts.coach_action] = 1.0
    out[27 + (env.sp_kind if env.dead else 0)] = 1.0
    out[35] = env.dead and env.sp_team == team
    out[36] = min(env.sp_timer / 5.0, 1.0) if env.dead else 0.0
    out[37:45] = v.shape
    out[45:53] = v.opp_shape * np.array([-1, -1, 1, 1, -1, -1, 1, -1])
    sl = slice(0, 11) if team == 0 else slice(11, 22)
    out[53] = env.stamina[sl].mean()
    out[54] = v.alpha
    out[55] = np.sum(v.O[:, 0] > v.b[0]) / 10.0
    return out


def build_team_obs(env, team: int, want_teacher: bool = False) -> dict:
    v = env.views[team]
    tokens = np.zeros((N_TOKENS, F), dtype=np.float32)
    tokens[CTX] = _context_token(v, env, team)
    tokens[BALL] = _ball_token(v, env, team)
    tokens[OWN0:OWN0 + 11] = _player_block(v, env, team, own=True)
    tokens[OPP0:OPP0 + 11] = _player_block(v, env, team, own=False)
    pos = np.zeros((N_TOKENS, 2), dtype=np.float32)
    pos[CTX] = v.P[np.arange(11) != env.form.gk_index].mean(axis=0) / HL
    pos[BALL] = v.b / HL
    pos[OWN0:OWN0 + 11] = v.P / HL
    pos[OPP0:OPP0 + 11] = v.O / HL
    roles = np.full(N_TOKENS, PAD_ROLE, dtype=np.int64)
    roles[OWN0:OWN0 + 11] = env.form.roles
    roles[OPP0:OPP0 + 11] = env.form.roles
    prev = np.full(N_TOKENS, PAD_ACTION, dtype=np.int64)
    own_sl = slice(0, 11) if team == 0 else slice(11, 22)
    opp_sl = slice(11, 22) if team == 0 else slice(0, 11)
    prev[OWN0:OWN0 + 11] = env.prev_actions[own_sl]
    prev[OPP0:OPP0 + 11] = env.prev_actions[opp_sl]
    agent_valid = np.ones(11, dtype=bool)
    if 0 <= env.human_player < 22 and env.human_player // 11 == team:
        agent_valid[env.human_player % 11] = False
    teacher = env.teacher(team) if want_teacher else np.full(11, -1, dtype=np.int64)
    obs = {
        "tokens": tokens,
        "pos": pos,
        "roles": roles,
        "prev": prev,
        "mask": env.masks[team].copy(),
        "agent_valid": agent_valid,
        "teacher": teacher.astype(np.int64),
    }
    if not np.all(np.isfinite(tokens)):
        obs["tokens"] = np.nan_to_num(tokens, nan=0.0, posinf=1.0, neginf=-1.0)
    return obs


def obs_spec() -> dict:
    """Shapes/dtypes of a single-team observation (for buffers and shared memory)."""
    return {
        "tokens": ((N_TOKENS, F), np.float32),
        "pos": ((N_TOKENS, 2), np.float32),
        "roles": ((N_TOKENS,), np.int64),
        "prev": ((N_TOKENS,), np.int64),
        "mask": ((11, A.NUM_ACTIONS), np.bool_),
        "agent_valid": ((11,), np.bool_),
        "teacher": ((11,), np.int64),
    }
