"""Self-play league and curriculum.

Two independent brains learn: red (always team 0) and blue (always team 1).
Opponent mix per match (probabilities set by the curriculum stage):
* ``rival``    - red brain vs blue brain (both sides produce training data),
* ``pool``     - one brain vs a frozen historical snapshot of the OTHER brain (each brain has
                 its own pool), sampled with prioritised fictitious self-play (PFSP: opponents
                 we struggle against are sampled more) -> avoids forgetting and cyclic
                 exploitation of the current rival,
* ``scripted`` - the rule-based AI (benchmark / early curriculum).
"""
from __future__ import annotations

import logging
import os
from collections import deque
from typing import Dict, List, Optional

import numpy as np
import torch

from .config import Config, CurriculumStage
from .model import Actor

log = logging.getLogger("football")


class OpponentPool:
    def __init__(self, cfg: Config, directory: str, device: torch.device):
        self.cfg = cfg
        self.dir = directory
        self.device = device
        self.entries: List[dict] = []          # {id, path, step, w, d, l}
        self._cache: Dict[int, Actor] = {}
        self._next_id = 0
        os.makedirs(directory, exist_ok=True)

    # -- persistence ---------------------------------------------------------------------
    def state_dict(self) -> dict:
        return {"entries": self.entries, "next_id": self._next_id}

    def load_state_dict(self, st: dict):
        self.entries = [e for e in st.get("entries", []) if os.path.exists(e["path"])]
        missing = len(st.get("entries", [])) - len(self.entries)
        if missing:
            log.warning(f"Opponent pool: {missing} snapshot file(s) missing, skipped")
        self._next_id = st.get("next_id", len(self.entries))
        self._cache.clear()

    # -- snapshots -----------------------------------------------------------------------
    def add_snapshot(self, actor: Actor, step: int):
        path = os.path.join(self.dir, f"pool_step_{step:012d}.pt")
        tmp = path + ".tmp"
        sd = {k: v.detach().cpu() for k, v in actor.state_dict().items()}
        torch.save({"actor": sd, "step": step}, tmp)
        os.replace(tmp, path)
        self.entries.append({"id": self._next_id, "path": path, "step": step,
                             "w": 0, "d": 0, "l": 0})
        self._next_id += 1
        if len(self.entries) > self.cfg.league.pool_size:
            # drop the most-beaten old snapshot (keep the very first as a fixed anchor)
            cands = self.entries[1:-3] or self.entries[1:]
            worst = max(cands, key=lambda e: self.learner_winrate(e))
            self.entries.remove(worst)
            self._cache.pop(worst["id"], None)
        log.info(f"Opponent pool: added snapshot @ step {step:,} (pool size {len(self.entries)})")

    def learner_winrate(self, e: dict) -> float:
        n = e["w"] + e["d"] + e["l"]
        return (e["w"] + 0.5 * e["d"] + 1.0) / (n + 2.0)      # Laplace-smoothed

    def sample(self, rng: np.random.Generator) -> Optional[dict]:
        if not self.entries:
            return None
        p = np.array([(1.0 - self.learner_winrate(e)) ** self.cfg.league.pfsp_power + 0.02
                      for e in self.entries])
        p = p / p.sum()
        return self.entries[int(rng.choice(len(self.entries), p=p))]

    def get_model(self, entry_id: int) -> Optional[Actor]:
        if entry_id in self._cache:
            return self._cache[entry_id]
        e = next((x for x in self.entries if x["id"] == entry_id), None)
        if e is None:
            return None
        try:
            data = torch.load(e["path"], map_location="cpu", weights_only=False)
            m = Actor(self.cfg.model)
            m.load_state_dict(data["actor"])
            m.to(self.device).eval()
        except Exception as ex:
            log.error(f"Opponent pool: failed to load {e['path']}: {ex} - removing entry")
            self.entries.remove(e)
            return None
        if len(self._cache) >= 6:
            self._cache.pop(next(iter(self._cache)))
        self._cache[entry_id] = m
        return m

    def record(self, entry_id: int, learner_goals: int, opp_goals: int):
        for e in self.entries:
            if e["id"] == entry_id:
                key = "w" if learner_goals > opp_goals else ("l" if learner_goals < opp_goals else "d")
                e[key] += 1
                return


class Curriculum:
    """Stage selection by env steps (+ optional performance gate)."""

    def __init__(self, stages: List[CurriculumStage]):
        self.stages = stages
        self.index = 0
        self.recent_vs_scripted = deque(maxlen=50)   # learner result points (1/0.5/0)

    def update(self, step: int) -> bool:
        changed = False
        while self.index + 1 < len(self.stages):
            nxt = self.stages[self.index + 1]
            if step < nxt.min_steps:
                break
            if nxt.gate_winrate_vs_scripted > 0:
                if len(self.recent_vs_scripted) < 20 or \
                        np.mean(self.recent_vs_scripted) < nxt.gate_winrate_vs_scripted:
                    break
            self.index += 1
            changed = True
            log.info(f"Curriculum: entering stage {nxt.name} at step {step:,}")
        return changed

    @property
    def stage(self) -> CurriculumStage:
        return self.stages[self.index]

    def winrate_vs_scripted(self) -> float:
        return float(np.mean(self.recent_vs_scripted)) if self.recent_vs_scripted else float("nan")

    def state_dict(self):
        return {"index": self.index, "recent": list(self.recent_vs_scripted)}

    def load_state_dict(self, st):
        self.index = min(st.get("index", 0), len(self.stages) - 1)
        self.recent_vs_scripted.extend(st.get("recent", []))
