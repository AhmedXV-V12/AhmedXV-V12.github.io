"""Device detection, seeding, logging helpers."""
from __future__ import annotations

import json
import logging
import os
import random
import sys
import time
from typing import Any, Dict

import numpy as np
import torch


def select_device(pref: str = "auto") -> torch.device:
    if pref == "cpu":
        return torch.device("cpu")
    if pref in ("auto", "cuda") and torch.cuda.is_available():
        return torch.device("cuda")
    if pref == "cuda":
        logging.getLogger("football").warning("CUDA requested but not available - using CPU")
    return torch.device("cpu")


def device_report(device: torch.device) -> Dict[str, Any]:
    info: Dict[str, Any] = {"cuda_available": torch.cuda.is_available(), "device": str(device),
                            "torch": torch.__version__}
    if torch.cuda.is_available():
        p = torch.cuda.get_device_properties(0)
        info.update(gpu_name=p.name, vram_gb=round(p.total_memory / 2 ** 30, 2),
                    bf16=torch.cuda.is_bf16_supported(), cuda=torch.version.cuda)
    return info


def device_label(device: torch.device) -> str:
    if device.type == "cuda":
        return f"CUDA - {torch.cuda.get_device_name(0)}"
    return "CPU"


def configure_torch(device: torch.device):
    if device.type == "cuda":
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.backends.cudnn.benchmark = True


def seed_everything(seed: int):
    random.seed(seed)
    np.random.seed(seed % (2 ** 32))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def rng_state() -> Dict[str, Any]:
    st = {"python": random.getstate(), "numpy": np.random.get_state(),
          "torch": torch.get_rng_state()}
    if torch.cuda.is_available():
        st["cuda"] = torch.cuda.get_rng_state_all()
    return st


def set_rng_state(st: Dict[str, Any]):
    try:
        random.setstate(st["python"])
        np.random.set_state(st["numpy"])
        torch.set_rng_state(st["torch"])
        if "cuda" in st and torch.cuda.is_available():
            torch.cuda.set_rng_state_all(st["cuda"])
    except Exception as e:  # RNG restore is best-effort (e.g. different GPU count)
        logging.getLogger("football").warning(f"Could not restore RNG state: {e}")


def setup_logging(log_dir: str, name: str = "train") -> logging.Logger:
    os.makedirs(log_dir, exist_ok=True)
    log = logging.getLogger("football")
    if log.handlers:
        return log
    log.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s", "%Y-%m-%d %H:%M:%S")
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    log.addHandler(sh)
    fh = logging.FileHandler(os.path.join(log_dir, f"{name}.log"), encoding="utf-8")
    fh.setFormatter(fmt)
    log.addHandler(fh)
    return log


class MetricsWriter:
    """Append-only JSONL metrics log (one record per logging interval)."""

    def __init__(self, path: str):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self.path = path

    def write(self, record: Dict[str, Any]):
        record = dict(record, wall_time=time.time())
        try:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, default=float) + "\n")
        except OSError as e:
            logging.getLogger("football").warning(f"metrics write failed: {e}")


def fmt_int(n: float) -> str:
    return f"{int(n):,}"
