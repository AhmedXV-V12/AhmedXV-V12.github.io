"""Pitch geometry and football value models.

Coordinate systems
------------------
* **World frame**: metres, origin at the centre spot, x along the length (+x = right goal),
  y along the width. Used by physics and rendering.
* **Team frame**: the world frame rotated 180 degrees for a team that attacks the left goal,
  so that *every team always attacks +x* in its own frame. Rotation (not a mirror) keeps
  left/right handedness consistent. All observations, tactical anchors and the xG/xT models
  work in the team frame, which lets both teams share one policy.
"""
from __future__ import annotations

import numpy as np

from .config import PitchConfig

PITCH = PitchConfig()
HL = PITCH.half_length          # 52.5
HW = PITCH.half_width           # 34.0
GOAL_HALF = PITCH.goal_width / 2  # 3.66


def norm(v, axis=-1, keepdims=False):
    """Fast Euclidean norm over the last axis (np.linalg.norm has large per-call overhead)."""
    v = np.asarray(v)
    return np.sqrt(np.sum(v * v, axis=axis, keepdims=keepdims))


def to_team(p: np.ndarray, attack_dir: float) -> np.ndarray:
    """World -> team frame (works for positions and velocities; last dim = 2)."""
    return p * attack_dir


def from_team(p: np.ndarray, attack_dir: float) -> np.ndarray:
    return p * attack_dir  # rotation by 180 degrees is its own inverse


def goal_angle(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Angle (rad) subtended by the attacked goal's posts from (x, y) in team frame."""
    dx = np.maximum(HL - x, 1e-3)
    a1 = np.arctan2(GOAL_HALF - y, dx)
    a2 = np.arctan2(-GOAL_HALF - y, dx)
    return np.abs(a1 - a2)


def goal_distance(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    return np.hypot(HL - x, y)


def xg_raw(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Unpressured expected-goals of a shot from (x, y) in team frame.

    Logistic model on visible goal angle and distance, calibrated so that:
    penalty spot ~0.34, edge of box (18m central) ~0.14, 25m ~0.05, tight angles ~0.03.
    """
    ang = goal_angle(x, y)
    d = goal_distance(x, y)
    z = -3.0 + 4.5 * ang - 0.05 * d
    out = 1.0 / (1.0 + np.exp(-z))
    return np.where(x > HL, 0.0, out)


def xt(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Expected threat: probability that possession at (x, y) leads to a goal soon.

    Smooth analytic surrogate of empirical xT grids: grows gently through the pitch and
    sharply near the opponent's box. ~0.004 at own goal, ~0.012 at halfway, ~0.25 at the
    penalty spot.
    """
    prog = np.clip((x + HL) / PITCH.length, 0.0, 1.0)
    return 0.004 + 0.06 * prog ** 3 + 0.6 * xg_raw(x, y) * (x > 0)


def in_penalty_area(x: np.ndarray, y: np.ndarray, attacking: bool = False) -> np.ndarray:
    """Penalty area test in team frame. ``attacking=False`` -> own box (x < 0 side)."""
    inside_y = np.abs(y) <= PITCH.penalty_area_width / 2
    if attacking:
        return inside_y & (x >= HL - PITCH.penalty_area_depth) & (x <= HL)
    return inside_y & (x <= -HL + PITCH.penalty_area_depth) & (x >= -HL)


def segment_point_distance(a: np.ndarray, b: np.ndarray, p: np.ndarray):
    """Distance from points ``p`` (..., 2) to segment a->b (2,), plus projection param t."""
    ab = b - a
    denom = float(ab @ ab)
    if denom < 1e-9:
        t = np.zeros(p.shape[:-1])
    else:
        t = np.clip(((p - a) @ ab) / denom, 0.0, 1.0)
    closest = a + t[..., None] * ab
    return norm(p - closest, axis=-1), t


def time_to_reach(pos: np.ndarray, vel: np.ndarray, targets: np.ndarray, vmax: np.ndarray,
                  reaction: float = 0.2, reach: float = 0.9) -> np.ndarray:
    """Approximate time for players to reach target points.

    pos, vel: (P, 2); targets: (..., 2); vmax: (P,). Returns targets.shape[:-1] + (P,).
    Players already moving toward the target benefit from their current velocity; players
    moving away pay a turning penalty. Written component-wise for speed (hot path).
    """
    dx = targets[..., 0, None] - pos[:, 0]
    dy = targets[..., 1, None] - pos[:, 1]
    dist = np.sqrt(dx * dx + dy * dy)
    along = (dx * vel[:, 0] + dy * vel[:, 1]) / np.maximum(dist, 1e-6)
    turn_pen = 0.25 * np.clip(1.0 - along / vmax, 0.0, 2.0)
    return reaction + turn_pen + np.maximum(dist - reach, 0.0) / vmax


def sigmoid(x):
    """Numerically safe logistic function."""
    return 0.5 * (1.0 + np.tanh(0.5 * x))


def time_to_reach_paired(pos: np.ndarray, vel: np.ndarray, targets: np.ndarray,
                         vmax: np.ndarray, reaction: float = 0.2, reach: float = 0.9) -> np.ndarray:
    """Element-wise version of :func:`time_to_reach` (pos[i] -> targets[i])."""
    d = targets - pos
    dist = norm(d, axis=-1)
    unit = d / np.maximum(dist[..., None], 1e-6)
    along = np.sum(unit * vel, axis=-1)
    turn_pen = 0.25 * np.clip(1.0 - along / np.maximum(vmax, 1e-3), 0.0, 2.0)
    return reaction + turn_pen + np.maximum(dist - reach, 0.0) / vmax


def segments_points_distance(a: np.ndarray, B: np.ndarray, p: np.ndarray) -> np.ndarray:
    """Distances from points p (M, 2) to many segments a->B[c] (C, 2). Returns (C, M)."""
    ab = B - a                                            # (C, 2)
    denom = np.maximum(np.sum(ab * ab, axis=-1), 1e-9)    # (C,)
    t = np.clip(((p - a) @ ab.T).T / denom[:, None], 0.0, 1.0)   # (C, M)
    closest = a + t[..., None] * ab[:, None, :]
    return norm(p[None] - closest, axis=-1)


def predict_ball(pos: np.ndarray, vel: np.ndarray, times: np.ndarray, decel: float,
                 damping: float) -> np.ndarray:
    """Predict ground-ball positions after ``times`` seconds (closed-form-ish).

    Uses v(t) = v0 * exp(-k t) - c t (clamped at stop). Good enough for anticipation.
    """
    speed = float(np.hypot(*vel))
    if speed < 1e-3:
        return np.repeat(pos[None, :], len(times), axis=0)
    unit = vel / speed
    k, c = damping, decel
    # distance travelled with exponential damping and constant decel (approximate; stop time)
    t_stop = np.log1p(k * speed / c) / k if k > 0 else speed / c
    t = np.minimum(times, t_stop)
    dist = (speed + c / k) * (1 - np.exp(-k * t)) / k - c * t / k
    dist = np.maximum(dist, 0.0)
    out = pos[None, :] + dist[:, None] * unit[None, :]
    out[:, 0] = np.clip(out[:, 0], -HL - 1.0, HL + 1.0)
    out[:, 1] = np.clip(out[:, 1], -HW - 1.0, HW + 1.0)
    return out
