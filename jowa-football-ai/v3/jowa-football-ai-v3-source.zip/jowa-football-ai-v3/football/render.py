"""Pygame visualisation (training and evaluation).

Rendering is decoupled from simulation: the renderer is called after every decision step of
env 0 and decides, from the selected speed, whether to draw each physics frame (slow
speeds, real-time pacing), only the latest frame at <= render_fps (fast speeds), or nothing.
It never forces the simulation into a fixed 60 FPS loop.

Controls
--------
  P / SPACE (when not controlling)  pause / resume
  1..8 or +/-                       speed: 0.5x 1x 2x 5x 10x 20x 50x MAX
  O                                 tactical overlay (anchors, lines, pass options)
  H                                 toggle stats panel
  R                                 toggle pitch rendering (training continues at full speed)
  TAB / UP / DOWN                   select a player          ENTER  take control
  ESC                               release control (back to AI)
  WASD / arrows                     move (controlled player)  SPACE shoot  F pass  T tackle
  S                                 save a screenshot to screenshots/
  Q or close window                 save checkpoint and exit safely
"""
from __future__ import annotations

import os
import time
from typing import Dict, Optional

import numpy as np

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
import pygame  # noqa: E402

from . import geometry as G  # noqa: E402
from . import tactics as T  # noqa: E402
from .formation import ROLE_NAMES  # noqa: E402

HL, HW = G.HL, G.HW
SCALE = 10.0
PITCH_X0, PITCH_Y0 = 40, 88
WIN_W, WIN_H = 1420, 860
PANEL_X = PITCH_X0 + int(G.PITCH.length * SCALE) + 40
SPEEDS = [0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 0.0]       # 0 = uncapped (MAX)
GRASS, GRASS2 = (38, 128, 52), (34, 118, 48)
WHITE, BLACK, YELLOW, ORANGE = (255, 255, 255), (0, 0, 0), (255, 215, 0), (255, 150, 0)
RED, BLUE = (215, 35, 50), (35, 110, 230)
RED_GK, BLUE_GK = (250, 150, 40), (40, 210, 210)
PANEL_BG, TEXT, DIM = (22, 24, 30), (230, 230, 230), (150, 155, 165)


def w2s(p) -> tuple:
    return int(PITCH_X0 + (p[0] + HL) * SCALE), int(PITCH_Y0 + (HW - p[1]) * SCALE)


class Renderer:
    def __init__(self, title: str = "JOWA Football AI 11v11", speed: float = 1.0,
                 render_fps: int = 30, allow_human: bool = True):
        pygame.init()
        pygame.display.set_caption(title)
        self.screen = pygame.display.set_mode((WIN_W, WIN_H))
        self.font_big = pygame.font.SysFont("Arial", 30, bold=True)
        self.font = pygame.font.SysFont("Arial", 16)
        self.font_b = pygame.font.SysFont("Arial", 16, bold=True)
        self.font_s = pygame.font.SysFont("Arial", 13)
        self.font_num = pygame.font.SysFont("Arial", 11, bold=True)
        self.bg = self._draw_pitch()
        self.nums = {}
        self.speed_idx = min(range(len(SPEEDS)), key=lambda i: abs(SPEEDS[i] - speed)
                             if SPEEDS[i] > 0 else (0 if speed <= 0 else 1e9))
        self.render_fps = render_fps
        self.allow_human = allow_human
        self.paused = False
        self.quit_requested = False
        self.overlay = False
        self.show_panel = True
        self.pitch_enabled = True
        self.selected = 0
        self.controlled: Optional[int] = None
        self._last_draw = 0.0
        self._pace_real = time.perf_counter()
        self._pace_sim = 0.0
        self._fps_t = time.perf_counter()
        self._fps_n = 0
        self.fps = 0.0
        self._shot_request = False
        self._auto_dir = os.environ.get("FOOTBALL_SCREENSHOT_DIR")
        self._auto_every = float(os.environ.get("FOOTBALL_SCREENSHOT_EVERY", "10"))
        self._auto_last = 0.0

    @property
    def speed(self) -> float:
        return SPEEDS[self.speed_idx]

    # ------------------------------------------------------------------------------------
    def _draw_pitch(self) -> pygame.Surface:
        s = pygame.Surface((WIN_W, WIN_H))
        s.fill((18, 70, 30))
        L, W = int(G.PITCH.length * SCALE), int(G.PITCH.width * SCALE)
        for k in range(10):
            col = GRASS if k % 2 == 0 else GRASS2
            pygame.draw.rect(s, col, (PITCH_X0 + k * L // 10, PITCH_Y0, L // 10 + 1, W))
        pygame.draw.rect(s, WHITE, (PITCH_X0, PITCH_Y0, L, W), 2)
        cx, cy = w2s((0, 0))
        pygame.draw.line(s, WHITE, (cx, PITCH_Y0), (cx, PITCH_Y0 + W), 2)
        pygame.draw.circle(s, WHITE, (cx, cy), int(9.15 * SCALE), 2)
        pygame.draw.circle(s, WHITE, (cx, cy), 3)
        p = G.PITCH
        for sgn in (-1, 1):
            gx = sgn * HL
            for depth, width in ((p.penalty_area_depth, p.penalty_area_width),
                                 (p.goal_area_depth, p.goal_area_width)):
                x0 = gx if sgn < 0 else gx - depth
                a = w2s((x0, width / 2))
                pygame.draw.rect(s, WHITE, (a[0], a[1], int(depth * SCALE), int(width * SCALE)), 2)
            spot = w2s((gx - sgn * p.penalty_spot_dist, 0))
            pygame.draw.circle(s, WHITE, spot, 3)
            arc_r = int(9.15 * SCALE)
            rect = pygame.Rect(spot[0] - arc_r, spot[1] - arc_r, 2 * arc_r, 2 * arc_r)
            if sgn < 0:
                pygame.draw.arc(s, WHITE, rect, -0.93, 0.93, 2)
            else:
                pygame.draw.arc(s, WHITE, rect, np.pi - 0.93, np.pi + 0.93, 2)
            g0 = w2s((gx, G.GOAL_HALF))
            depth_px = int(2.0 * SCALE)
            gxpx = g0[0] - depth_px if sgn < 0 else g0[0]
            pygame.draw.rect(s, (235, 235, 235), (gxpx, g0[1], depth_px, int(p.goal_width * SCALE)),
                             0)
            pygame.draw.rect(s, (90, 90, 90), (gxpx, g0[1], depth_px, int(p.goal_width * SCALE)), 2)
        return s

    def _num_surface(self, team: int, number: int):
        key = (team, number)
        if key not in self.nums:
            self.nums[key] = self.font_num.render(str(number), True, WHITE)
        return self.nums[key]

    # ------------------------------------------------------------------------------------
    def handle_events(self, env=None):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit_requested = True
            elif event.type == pygame.KEYDOWN:
                k = event.key
                if k == pygame.K_q:
                    self.quit_requested = True
                elif k == pygame.K_p or (k == pygame.K_SPACE and self.controlled is None):
                    self.paused = not self.paused
                elif pygame.K_1 <= k <= pygame.K_8:
                    self.speed_idx = k - pygame.K_1
                elif k in (pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
                    self.speed_idx = min(len(SPEEDS) - 1, self.speed_idx + 1)
                elif k in (pygame.K_MINUS, pygame.K_KP_MINUS):
                    self.speed_idx = max(0, self.speed_idx - 1)
                elif k == pygame.K_o:
                    self.overlay = not self.overlay
                elif k == pygame.K_h:
                    self.show_panel = not self.show_panel
                elif k == pygame.K_r:
                    self.pitch_enabled = not self.pitch_enabled
                elif k == pygame.K_s and self.controlled is None:
                    self._shot_request = True
                elif self.controlled is None and k in (pygame.K_TAB, pygame.K_DOWN):
                    self.selected = (self.selected + 1) % 22
                elif self.controlled is None and k == pygame.K_UP:
                    self.selected = (self.selected - 1) % 22
                elif k in (pygame.K_RETURN, pygame.K_KP_ENTER) and self.controlled is None:
                    if self.allow_human:
                        self.controlled = self.selected
                elif k == pygame.K_ESCAPE and self.controlled is not None:
                    self.controlled = None
            if self.quit_requested:
                break
        if env is not None:
            self._apply_human(env)

    def _apply_human(self, env):
        if self.controlled is None:
            env.human_player = -1
            env.human_command = None
            return
        keys = pygame.key.get_pressed()
        dx = (keys[pygame.K_d] or keys[pygame.K_RIGHT]) - (keys[pygame.K_a] or keys[pygame.K_LEFT])
        dy = (keys[pygame.K_w] or keys[pygame.K_UP]) - (keys[pygame.K_s] or keys[pygame.K_DOWN])
        env.human_player = self.controlled
        env.human_command = {"dir": (dx, dy) if (dx or dy) else None,
                             "shoot": bool(keys[pygame.K_SPACE]), "pass": bool(keys[pygame.K_f]),
                             "tackle": bool(keys[pygame.K_t])}

    def pump(self):
        """Keep the window responsive during long computations (e.g. PPO updates)."""
        try:
            pygame.event.pump()
        except pygame.error:
            pass

    # ------------------------------------------------------------------------------------
    def display_due(self, step_sim: float = 0.2) -> bool:
        """Non-blocking pacing check used while training is busy (e.g. PPO update):
        True when the visible match should advance one decision step at the chosen speed."""
        now = time.perf_counter()
        if self.speed <= 0:
            due = now - self._last_draw >= 1.0 / self.render_fps
        else:
            due = now - getattr(self, "_last_disp", 0.0) >= step_sim / self.speed
        if due:
            self._last_disp = now
        return due

    def after_step(self, env, hud: Dict, allow_sleep: bool = True) -> None:
        """Called once per decision step of the visible env. Handles pacing and drawing.
        With allow_sleep=False (used during PPO updates) it only draws, never waits."""
        self.handle_events(env)
        if not allow_sleep:
            if not self.paused:
                self._draw(env, hud, env.pos, env.bpos, env.bz)
            self._pace_real, self._pace_sim = time.perf_counter(), 0.0
            return
        while self.paused and not self.quit_requested:
            self._draw(env, hud, env.pos, env.bpos, env.bz, paused=True)
            time.sleep(0.03)
            self.handle_events(env)
            self._pace_real = time.perf_counter()
            self._pace_sim = 0.0
        step_sim = env.phys.dt * env.phys.substeps
        spd = self.speed
        now = time.perf_counter()
        if spd <= 0:                                   # uncapped: draw at most render_fps
            self._pace_real, self._pace_sim = now, 0.0
            if now - self._last_draw >= 1.0 / self.render_fps:
                self._draw(env, hud, env.pos, env.bpos, env.bz)
            return
        frames = env.frames if env.frames else [(env.pos, env.bpos, env.bz, env.possessor)]
        if now - self._pace_real > 1.0:               # fell behind (e.g. PPO update): resync
            self._pace_real, self._pace_sim = now, 0.0
        per_frame = step_sim / len(frames)
        draw_each = spd <= 5.0
        for k, fr in enumerate(frames):
            self._pace_sim += per_frame
            target = self._pace_real + self._pace_sim / spd
            if draw_each or k == len(frames) - 1:
                if time.perf_counter() - self._last_draw >= (1.0 / 60 if draw_each
                                                             else 1.0 / self.render_fps):
                    self._draw(env, hud, fr[0], fr[1], fr[2])
            delay = target - time.perf_counter()
            if delay > 0:
                time.sleep(min(delay, 0.25))

    # ------------------------------------------------------------------------------------
    def _draw(self, env, hud: Dict, pos, bpos, bz, paused: bool = False):
        self._last_draw = time.perf_counter()
        self._fps_n += 1
        if self._last_draw - self._fps_t > 1.0:
            self.fps = self._fps_n / (self._last_draw - self._fps_t)
            self._fps_t, self._fps_n = self._last_draw, 0
        scr = self.screen
        scr.blit(self.bg, (0, 0))
        if self.pitch_enabled:
            if self.overlay:
                self._draw_overlay(env)
            self._draw_players(env, pos)
            self._draw_ball(bpos, bz)
        else:
            t = self.font_b.render("Pitch rendering paused (R) - training continues at full speed",
                                   True, WHITE)
            scr.blit(t, (PITCH_X0 + 200, PITCH_Y0 + 320))
        self._draw_topbar(env, hud)
        if self.show_panel:
            self._draw_panel(env, hud)
        if paused:
            t = self.font_big.render("PAUSED (P)", True, YELLOW)
            scr.blit(t, (PITCH_X0 + 450, PITCH_Y0 + 300))
        self._draw_help()
        pygame.display.flip()
        self._maybe_screenshot()

    def _maybe_screenshot(self):
        now = time.time()
        path = None
        if self._shot_request:
            os.makedirs("screenshots", exist_ok=True)
            path = os.path.join("screenshots", time.strftime("frame_%Y%m%d_%H%M%S.png"))
            self._shot_request = False
        elif self._auto_dir and now - self._auto_last >= self._auto_every:
            os.makedirs(self._auto_dir, exist_ok=True)
            path = os.path.join(self._auto_dir, f"auto_{int(now)}.png")
            self._auto_last = now
        if path:
            try:
                pygame.image.save(self.screen, path)
            except pygame.error:
                pass

    def _draw_players(self, env, pos):
        for p in range(22):
            t = p // 11
            is_gk = env.roles[p] == 0
            col = (RED_GK if is_gk else RED) if t == 0 else (BLUE_GK if is_gk else BLUE)
            c = w2s(pos[p])
            pygame.draw.circle(self.screen, col, c, 9)
            pygame.draw.circle(self.screen, BLACK, c, 9, 1)
            ns = self._num_surface(t, int(env.numbers[p]))
            self.screen.blit(ns, (c[0] - ns.get_width() // 2, c[1] - ns.get_height() // 2))
            if p == env.possessor:
                pygame.draw.circle(self.screen, YELLOW, c, 12, 2)
            if self.controlled == p:
                pygame.draw.circle(self.screen, ORANGE, c, 15, 3)
            elif self.controlled is None and self.selected == p and self.allow_human:
                pygame.draw.circle(self.screen, WHITE, c, 14, 1)

    def _draw_ball(self, bpos, bz):
        g = w2s(bpos)
        pygame.draw.circle(self.screen, (20, 60, 25), (g[0] + 2, g[1] + 2), 4)
        lift = int(bz * 4)
        pygame.draw.circle(self.screen, WHITE, (g[0], g[1] - lift), 5 + min(3, int(bz)))
        pygame.draw.circle(self.screen, BLACK, (g[0], g[1] - lift), 5 + min(3, int(bz)), 1)

    def _draw_overlay(self, env):
        for t in range(2):
            v = env.views[t]
            col = (255, 170, 170) if t == 0 else (170, 200, 255)
            for i in range(11):
                a = w2s(v.anchors[i] * v.attack_dir)
                pygame.draw.line(self.screen, col, (a[0] - 3, a[1] - 3), (a[0] + 3, a[1] + 3), 1)
                pygame.draw.line(self.screen, col, (a[0] - 3, a[1] + 3), (a[0] + 3, a[1] - 3), 1)
            dl = v.lines[0] * v.attack_dir
            x = w2s((dl, 0))[0]
            pygame.draw.line(self.screen, col, (x, PITCH_Y0), (x, PITCH_Y0 + int(G.PITCH.width * SCALE)), 1)
            if v.carrier >= 0:
                cp = w2s(v.P[v.carrier] * v.attack_dir)
                po = v.passes
                for j in range(11):
                    if not po.valid[j]:
                        continue
                    pr = max(po.p_feet[j], po.p_thr[j])
                    c2 = (int(255 * (1 - pr)), int(255 * pr), 60)
                    pygame.draw.line(self.screen, c2, cp, w2s(v.P[j] * v.attack_dir), 1)

    def _draw_topbar(self, env, hud):
        scr = self.screen
        pygame.draw.rect(scr, PANEL_BG, (0, 0, WIN_W, 70))
        score = self.font_big.render(f"RED {env.score[0]}  -  {env.score[1]} BLUE", True, WHITE)
        scr.blit(score, (PITCH_X0 + 525 - score.get_width() // 2, 6))
        hd = env.rules.half_duration_s
        disp = env.rules.display_half_minutes * 60 * (env.t_half / hd)
        disp += env.half * env.rules.display_half_minutes * 60
        clock = f"{int(disp // 60):02d}:{int(disp % 60):02d}  {'1st' if env.half == 0 else '2nd'} half"
        tc = self.font.render(clock, True, TEXT)
        scr.blit(tc, (PITCH_X0 + 525 - tc.get_width() // 2, 42))
        for t, x, col in ((0, PITCH_X0, RED), (1, PITCH_X0 + 760, BLUE)):
            ts = env.tactics[t]
            name = hud.get("team_labels", ["RED", "BLUE"])[t]
            s1 = self.font_b.render(f"{name}: {T.PHASE_NAMES[ts.phase]}", True, col)
            s2 = self.font_s.render(f"coach: {T.COACH_NAMES[ts.coach_action]}", True, DIM)
            scr.blit(s1, (x, 10))
            scr.blit(s2, (x, 34))
        if env.dead and env.sp_kind:
            sp = self.font_b.render(T.SP_NAMES[env.sp_kind], True, YELLOW)
            scr.blit(sp, (PITCH_X0 + 525 - sp.get_width() // 2, PITCH_Y0 + 6))

    def _draw_panel(self, env, hud):
        scr = self.screen
        x0 = PANEL_X
        pygame.draw.rect(scr, PANEL_BG, (x0 - 12, 70, WIN_W - x0 + 12, WIN_H - 70))
        y = 82
        mode = hud.get("mode", "TRAINING")
        scr.blit(self.font_b.render(mode, True, YELLOW), (x0, y))
        y += 26
        a, b = env.stats.t
        tot = a["possession_time"] + b["possession_time"] + 1e-9
        pa = a["passes_completed"] / max(1, a["passes"])
        pb = b["passes_completed"] / max(1, b["passes"])
        lines = []
        for key, label in (("step", "Training step"), ("episode", "Matches played"),
                           ("update", "PPO updates")):
            if key in hud:
                lines.append((f"{label}: {hud[key]:,}", TEXT))
        lines += [("", TEXT), ("This match:", DIM),
                  (f"Possession  R {100 * a['possession_time'] / tot:.0f}% | "
                   f"B {100 * b['possession_time'] / tot:.0f}%", TEXT),
                  (f"Pass acc.   R {100 * pa:.0f}% | B {100 * pb:.0f}%", TEXT),
                  (f"Shots       R {a['shots']:.0f} ({a['shots_on_target']:.0f}) | "
                   f"B {b['shots']:.0f} ({b['shots_on_target']:.0f})", TEXT),
                  (f"xG          R {a['xg']:.2f} | B {b['xg']:.2f}", TEXT)]
        rl = getattr(env, "reward_log", None)
        if rl:
            lines.append((f"Reward/plr  R {sum(rl[0].values()):+.2f} | B {sum(rl[1].values()):+.2f}",
                          TEXT))
        if "controllers" in hud:
            lines.append((f"Red: {hud['controllers'][0]}", (255, 160, 160)))
            lines.append((f"Blue: {hud['controllers'][1]}", (160, 190, 255)))
        lines.append(("", TEXT))
        for key in ("recent", "stage", "winrate", "sps", "loss", "checkpoint", "device", "gpu_mem"):
            if key in hud and hud[key] is not None:
                val = hud[key]
                if isinstance(val, list):
                    for v in val:
                        lines.append((v, TEXT))
                else:
                    lines.append((str(val), TEXT if key != "checkpoint" else (170, 230, 170)))
        spd = "MAX" if self.speed <= 0 else f"{self.speed:g}x"
        lines += [("", TEXT), (f"Speed: {spd}   Render FPS: {self.fps:.0f}", YELLOW)]
        if self.controlled is not None:
            role = ROLE_NAMES[int(env.roles[self.controlled])]
            lines.append((f"You control #{int(env.numbers[self.controlled])} ({role}, "
                          f"{'RED' if self.controlled < 11 else 'BLUE'})", ORANGE))
        for text, col in lines:
            if text:
                scr.blit(self.font_s.render(text, True, col), (x0, y))
            y += 18
            if y > WIN_H - 40:
                break

    def _draw_help(self):
        t = self.font_s.render("P pause | 1-8 speed | O overlay | H panel | R pitch on/off | S shot | "
                               "TAB/ENTER control player, ESC release | Q save & quit",
                               True, DIM)
        self.screen.blit(t, (PITCH_X0, WIN_H - 22))

    def close(self):
        try:
            pygame.quit()
        except Exception:
            pass
