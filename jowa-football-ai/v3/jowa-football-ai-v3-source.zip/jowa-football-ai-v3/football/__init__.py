"""JOWA Football AI - 11v11 football simulation and multi-agent reinforcement learning."""
from .config import Config, VERSION, ARCH_VERSION  # noqa: F401
