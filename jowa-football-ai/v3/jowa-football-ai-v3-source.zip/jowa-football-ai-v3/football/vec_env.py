"""Vectorised environments.

Env 0 always lives in the main process so the renderer can draw the exact match that is
being trained on. The remaining envs are spread over worker processes (multiprocessing
'spawn', Windows-safe). Worker envs step while the main process steps env 0 and renders.

Each env auto-resets at full time. The trainer queues a *match configuration* (who controls
each team, scripted skill, curriculum rules / reward weights) that is applied atomically when
the next match starts.
"""
from __future__ import annotations

import copy
import dataclasses
import multiprocessing as mp
import traceback
from typing import Dict, List, Optional

import numpy as np

from .config import Config
from .engine import FootballEnv
from .observation import build_team_obs, obs_spec

_ZERO_OBS = None


def zero_obs() -> Dict[str, np.ndarray]:
    global _ZERO_OBS
    if _ZERO_OBS is None:
        _ZERO_OBS = {k: np.zeros(shape, dtype=dt) for k, (shape, dt) in obs_spec().items()}
        _ZERO_OBS["teacher"][:] = -1
    return _ZERO_OBS


def default_match_config(cfg: Config) -> dict:
    return {"team_control": ["policy", "policy"], "scripted_skill": [1.0, 1.0],
            "want_teacher": [False, False], "half_duration_s": cfg.rules.half_duration_s,
            "offside": cfg.rules.offside, "fouls": cfg.rules.fouls,
            "individual_weight": cfg.reward.individual_weight, "shape_mult": 1.0}


class EnvRunner:
    """A FootballEnv plus auto-reset, match configuration and observation building."""

    def __init__(self, cfg: Config, seed: int):
        self.cfg = cfg
        self.env = FootballEnv(cfg, seed)
        self.next_config: Optional[dict] = None
        self.config = default_match_config(cfg)
        self._apply(self.config)

    def _apply(self, mc: dict):
        env = self.env
        self.config = mc
        env.team_control = list(mc["team_control"])
        env.scripted_skill = list(mc["scripted_skill"])
        env.want_teacher = list(mc["want_teacher"])
        env.rules = dataclasses.replace(self.cfg.rules, half_duration_s=mc["half_duration_s"],
                                        offside=mc["offside"], fouls=mc["fouls"])
        env.reward_weights = dataclasses.replace(self.cfg.reward,
                                                 individual_weight=mc["individual_weight"])
        env.shape_mult = mc["shape_mult"]

    def reset(self):
        if self.next_config is not None:
            self._apply(self.next_config)
            self.next_config = None
        self.env.reset()
        return self.observe()

    def observe(self):
        env = self.env
        return [build_team_obs(env, t, env.want_teacher[t]) if env.team_control[t] == "policy"
                else zero_obs() for t in range(2)]

    def step(self, actions, coach):
        env = self.env
        r, rt, done, info = env.step(actions, coach)
        out = {"coach_tick_next": env.coach_step % self.cfg.train.coach_interval == 0}
        if done:
            out["summary"] = info["match_summary"]
            out["score"] = info["score"]
            out["reward_log"] = copy.deepcopy(getattr(env, "reward_log", None))
            out["control"] = list(env.team_control)
            obs = self.reset()
            out["coach_tick_next"] = True
        else:
            obs = self.observe()
        return obs, r, rt, done, out


def _worker(conn, cfg_dict, seeds):
    try:
        cfg = Config.from_dict(cfg_dict)
        runners = [EnvRunner(cfg, s) for s in seeds]
        while True:
            cmd, data = conn.recv()
            if cmd == "step":
                acts, coach = data
                conn.send(("ok", [r.step(acts[i], coach[i]) for i, r in enumerate(runners)]))
            elif cmd == "reset":
                conn.send(("ok", [r.reset() for r in runners]))
            elif cmd == "next_config":
                idx, mc = data
                runners[idx].next_config = mc
                conn.send(("ok", None))
            elif cmd == "configure_now":
                idx, mc = data
                runners[idx]._apply(mc)
                conn.send(("ok", runners[idx].reset()))
            elif cmd == "close":
                conn.send(("ok", None))
                break
    except (KeyboardInterrupt, EOFError, BrokenPipeError):
        pass
    except Exception:
        try:
            conn.send(("error", traceback.format_exc()))
        except Exception:
            pass
    finally:
        conn.close()


def stack_obs(obs_list: List[list]) -> Dict[str, np.ndarray]:
    keys = obs_list[0][0].keys()
    return {k: np.stack([np.stack([o[0][k], o[1][k]]) for o in obs_list]) for k in keys}


class VecEnv:
    def __init__(self, cfg: Config, num_envs: int, num_workers: int, seed: int):
        assert num_envs >= 1
        self.cfg = cfg
        self.num_envs = num_envs
        self.local = EnvRunner(cfg, seed)
        n_remote = num_envs - 1
        num_workers = max(0, min(num_workers, n_remote))
        self.workers = []
        self.assign: List[tuple] = [("local", 0)]
        self.inproc: List[EnvRunner] = []
        if num_workers == 0:
            self.inproc = [EnvRunner(cfg, seed + 1 + i) for i in range(n_remote)]
            self.assign += [("inproc", i) for i in range(n_remote)]
        else:
            ctx = mp.get_context("spawn")
            splits = np.array_split(np.arange(n_remote), num_workers)
            cfg_dict = cfg.to_dict()
            for w, idx in enumerate(splits):
                parent, child = ctx.Pipe()
                seeds = [seed + 1 + int(i) for i in idx]
                p = ctx.Process(target=_worker, args=(child, cfg_dict, seeds), daemon=True)
                p.start()
                child.close()
                self.workers.append((p, parent, len(idx)))
                self.assign += [("worker", (w, j)) for j in range(len(idx))]
        self._pending = False

    # -------------------------------------------------------------------------------------
    @property
    def env0(self) -> FootballEnv:
        return self.local.env

    def _recv(self, conn):
        status, data = conn.recv()
        if status == "error":
            raise RuntimeError(f"Environment worker crashed:\n{data}")
        return data

    def reset(self):
        for _, conn, _ in self.workers:
            conn.send(("reset", None))
        obs = [self.local.reset()] + [r.reset() for r in self.inproc]
        for _, conn, _ in self.workers:
            obs += self._recv(conn)
        return stack_obs(obs)

    def step(self, actions: np.ndarray, coach: np.ndarray, local_hook=None):
        """Step all envs. ``local_hook`` runs in the main process after env 0 has stepped
        (while the workers are still busy) - used for rendering."""
        off = 1 + len(self.inproc)
        for w, (_, conn, n) in enumerate(self.workers):
            conn.send(("step", (actions[off:off + n], coach[off:off + n])))
            off += n
        results = [self.local.step(actions[0], coach[0])]
        if local_hook is not None:
            local_hook()
        results += [r.step(actions[1 + i], coach[1 + i]) for i, r in enumerate(self.inproc)]
        for _, conn, _ in self.workers:
            results += self._recv(conn)
        obs = stack_obs([r[0] for r in results])
        rew = np.stack([r[1] for r in results]).astype(np.float32)
        team_rew = np.stack([r[2] for r in results]).astype(np.float32)
        dones = np.array([r[3] for r in results])
        infos = [r[4] for r in results]
        return obs, rew, team_rew, dones, infos

    def set_next_config(self, i: int, mc: dict):
        kind, where = self.assign[i]
        if kind == "local":
            self.local.next_config = mc
        elif kind == "inproc":
            self.inproc[where].next_config = mc
        else:
            w, j = where
            conn = self.workers[w][1]
            conn.send(("next_config", (j, mc)))
            self._recv(conn)

    def configure_now(self, i: int, mc: dict):
        """Apply a config immediately (restarts that env's match). Returns its new obs."""
        kind, where = self.assign[i]
        if kind == "local":
            self.local._apply(mc)
            return self.local.reset()
        if kind == "inproc":
            self.inproc[where]._apply(mc)
            return self.inproc[where].reset()
        w, j = where
        conn = self.workers[w][1]
        conn.send(("configure_now", (j, mc)))
        return self._recv(conn)

    def close(self):
        for p, conn, _ in self.workers:
            try:
                conn.send(("close", None))
                conn.recv()
            except Exception:
                pass
            p.join(timeout=3)
            if p.is_alive():
                p.terminate()
        self.workers = []
