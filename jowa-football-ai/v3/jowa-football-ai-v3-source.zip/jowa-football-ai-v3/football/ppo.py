"""MAPPO building blocks: value normalisation, rollout storage, GAE and the PPO update."""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import torch
import torch.nn as nn

from .config import PPOConfig
from .observation import obs_spec

OBS_KEYS = list(obs_spec().keys())
NP2TORCH = {np.float32: torch.float32, np.int64: torch.long, np.bool_: torch.bool}


def obs_to_torch(obs: Dict[str, np.ndarray], device: torch.device) -> Dict[str, torch.Tensor]:
    """numpy obs (E, 2, ...) -> torch (E*2, ...) on device (one transfer per key)."""
    out = {}
    for k, v in obs.items():
        t = torch.from_numpy(np.ascontiguousarray(v.reshape((-1,) + v.shape[2:])))
        out[k] = t.to(device, non_blocking=True)
    return out


class ValueNorm(nn.Module):
    """Running normalisation of value targets (debiased EMA, as in MAPPO)."""

    def __init__(self, beta: float = 0.9999, eps: float = 1e-5):
        super().__init__()
        self.beta, self.eps = beta, eps
        self.register_buffer("mean", torch.zeros(()))
        self.register_buffer("mean_sq", torch.zeros(()))
        self.register_buffer("debias", torch.zeros(()))

    def _stats(self):
        d = self.debias.clamp(min=self.eps)
        mean = self.mean / d
        var = (self.mean_sq / d - mean ** 2).clamp(min=1e-2)
        return mean, var

    @torch.no_grad()
    def update(self, x: torch.Tensor):
        x = x.float()
        self.mean.mul_(self.beta).add_(x.mean() * (1 - self.beta))
        self.mean_sq.mul_(self.beta).add_((x ** 2).mean() * (1 - self.beta))
        self.debias.mul_(self.beta).add_(1 - self.beta)

    def normalize(self, x):
        m, v = self._stats()
        return (x - m) / v.sqrt()

    def denormalize(self, x):
        m, v = self._stats()
        return x * v.sqrt() + m


class RolloutBuffer:
    """GPU storage for T steps x S team-slots (S = 2 * num_envs)."""

    def __init__(self, T: int, S: int, device: torch.device):
        self.T, self.S, self.device = T, S, device
        self.obs = {k: torch.zeros((T, S) + shape, dtype=NP2TORCH[dt], device=device)
                    for k, (shape, dt) in obs_spec().items()}
        z = lambda *s, dt=torch.float32: torch.zeros((T, S) + s, dtype=dt, device=device)  # noqa
        self.actions = z(11, dt=torch.long)
        self.logp = z(11)
        self.values = z(11)
        self.rewards = z(11)
        self.team_rew = z()
        self.team_values = z()
        self.coach = z(dt=torch.long)
        self.coach_logp = z()
        self.coach_tick = z(dt=torch.bool)
        self.dones = z()
        self.learner = z(dt=torch.bool)
        self.adv = z(11)
        self.ret = z(11)
        self.coach_adv = z()
        self.coach_ret = z()

    def compute_gae(self, last_values, last_team_values, gamma: float, lam: float):
        T = self.T
        gae = torch.zeros_like(last_values)
        gae_t = torch.zeros_like(last_team_values)
        for t in reversed(range(T)):
            nonterm = 1.0 - self.dones[t]
            nv = last_values if t == T - 1 else self.values[t + 1]
            ntv = last_team_values if t == T - 1 else self.team_values[t + 1]
            delta = self.rewards[t] + gamma * nv * nonterm[:, None] - self.values[t]
            gae = delta + gamma * lam * nonterm[:, None] * gae
            self.adv[t] = gae
            delta_t = self.team_rew[t] + gamma * ntv * nonterm - self.team_values[t]
            gae_t = delta_t + gamma * lam * nonterm * gae_t
            self.coach_adv[t] = gae_t
        self.ret = self.adv + self.values
        self.coach_ret = self.coach_adv + self.team_values


def ppo_update(model, opt, buf: RolloutBuffer, vnorm_p: ValueNorm, vnorm_t: ValueNorm,
               cfg: PPOConfig, ent_coef: float, ks_coef: float, amp: bool, pump=None,
               valid: Optional[torch.Tensor] = None) -> Dict:
    """PPO on the slots in `valid` (T, S) bool (default: all learner slots), e.g. only the
    team slots played by one brain."""
    device = buf.device
    flat_valid = (buf.learner if valid is None else valid).reshape(-1)
    idx_all = torch.nonzero(flat_valid).squeeze(-1)
    N = idx_all.numel()
    if N == 0:
        return {}
    flat = lambda x: x.reshape((-1,) + tuple(x.shape[2:]))  # noqa
    obs = {k: flat(v) for k, v in buf.obs.items()}
    actions, old_logp = flat(buf.actions), flat(buf.logp)
    adv, ret = flat(buf.adv), flat(buf.ret)
    old_v = flat(buf.values)
    coach, old_clogp = flat(buf.coach), flat(buf.coach_logp)
    cadv, cret, tick = flat(buf.coach_adv), flat(buf.coach_ret), flat(buf.coach_tick)
    old_tv = flat(buf.team_values)
    agent_ok = obs["agent_valid"]
    # value normalisation stats from this batch's returns (learner samples only)
    ok_ret = ret[idx_all][agent_ok[idx_all]]
    if ok_ret.numel():
        vnorm_p.update(ok_ret)
    vnorm_t.update(cret[idx_all])

    stats = {"pg": 0.0, "vf": 0.0, "ent": 0.0, "kl": 0.0, "clip": 0.0, "coach_pg": 0.0,
             "coach_ent": 0.0, "ks": 0.0, "n": 0}
    mb = max(64, cfg.minibatch_team_samples)
    stop = False
    for epoch in range(cfg.epochs):
        if pump is not None:
            pump()
        perm = idx_all[torch.randperm(N, device=device)]
        epoch_kl = []
        for s in range(0, N, mb):
            b = perm[s:s + mb]
            ob = {k: v[b] for k, v in obs.items()}
            with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp):
                ev = model.evaluate(ob, actions[b], coach[b])
            am = ob["agent_valid"].float()                          # (B, 11)
            denom = am.sum().clamp(min=1.0)
            A = adv[b]
            a_mean = (A * am).sum() / denom
            a_std = (((A - a_mean) ** 2 * am).sum() / denom).sqrt()
            A = (A - a_mean) / (a_std + 1e-8)
            log_ratio = ev["logp"] - old_logp[b]
            ratio = log_ratio.exp()
            pg = -torch.min(ratio * A, ratio.clamp(1 - cfg.clip, 1 + cfg.clip) * A)
            pg_loss = (pg * am).sum() / denom
            ent = (ev["entropy"] * am).sum() / denom
            # value (normalised space, clipped)
            v_new = ev["value"]
            v_old_n = vnorm_p.normalize(old_v[b])
            target = vnorm_p.normalize(ret[b])
            v_clip = v_old_n + (v_new - v_old_n).clamp(-cfg.value_clip, cfg.value_clip)
            vf = torch.max((v_new - target) ** 2, (v_clip - target) ** 2)
            vf_loss = 0.5 * (vf * am).sum() / denom
            tv_new = ev["team_value"]
            tv_target = vnorm_t.normalize(cret[b])
            tv_old = vnorm_t.normalize(old_tv[b])
            tv_clip = tv_old + (tv_new - tv_old).clamp(-cfg.value_clip, cfg.value_clip)
            tvf_loss = 0.5 * torch.max((tv_new - tv_target) ** 2, (tv_clip - tv_target) ** 2).mean()
            # coach (team-level tactical policy) - only on its decision ticks
            tk = tick[b].float()
            tden = tk.sum()
            if tden > 0:
                CA = cadv[b]
                cm = (CA * tk).sum() / tden
                cs = (((CA - cm) ** 2 * tk).sum() / tden).sqrt()
                CA = (CA - cm) / (cs + 1e-8)
                cr = (ev["coach_logp"] - old_clogp[b]).exp()
                cpg = -torch.min(cr * CA, cr.clamp(1 - cfg.clip, 1 + cfg.clip) * CA)
                coach_pg = (cpg * tk).sum() / tden
                coach_ent = (ev["coach_entropy"] * tk).sum() / tden
            else:
                coach_pg = torch.zeros((), device=device)
                coach_ent = torch.zeros((), device=device)
            # kick-starting: imitation of the scripted teacher, decays to zero early on
            if ks_coef > 0:
                # label-smoothed target (teacher action + uniform over valid actions) so that
                # imitation cannot collapse the policy's entropy before RL takes over
                t_act = ob["teacher"]
                tm = (t_act >= 0).float() * am
                safe = t_act.clamp(min=0)
                lp_all = ev["logp_all"].clamp(min=-20.0)
                t_logp = lp_all.gather(-1, safe[..., None]).squeeze(-1)
                vmask = ob["mask"].float()
                u_logp = (lp_all * vmask).sum(-1) / vmask.sum(-1).clamp(min=1.0)
                eps = cfg.kickstart_smoothing
                ce = -((1 - eps) * t_logp + eps * u_logp)
                ks = (ce * tm).sum() / tm.sum().clamp(min=1.0)
            else:
                ks = torch.zeros((), device=device)
            loss = (pg_loss + coach_pg + cfg.value_coef * (vf_loss + tvf_loss)
                    - ent_coef * ent - cfg.coach_entropy_coef * coach_ent + ks_coef * ks)
            if not torch.isfinite(loss):
                raise FloatingPointError("non-finite PPO loss")
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), cfg.max_grad_norm)
            opt.step()
            with torch.no_grad():
                kl = (((ratio - 1) - log_ratio) * am).sum() / denom
                clipfrac = (((ratio - 1).abs() > cfg.clip).float() * am).sum() / denom
            epoch_kl.append(kl.item())
            for k, v in (("pg", pg_loss), ("vf", vf_loss + tvf_loss), ("ent", ent), ("kl", kl),
                         ("clip", clipfrac), ("coach_pg", coach_pg), ("coach_ent", coach_ent),
                         ("ks", ks)):
                stats[k] += float(v)
            stats["n"] += 1
            if pump is not None:
                pump()
        if cfg.target_kl > 0 and sum(epoch_kl) / max(1, len(epoch_kl)) > 1.5 * cfg.target_kl:
            stop = True
        if stop:
            break
    n = max(1, stats.pop("n"))
    out = {k: v / n for k, v in stats.items()}
    out["epochs"] = epoch + 1
    out["samples"] = int(N)
    return out
