"""Crash-safe checkpointing (one file per brain) with automatic resume and corruption fallback.

Two independent brains are trained: ``red`` (team 0) and ``blue`` (team 1). Every save writes
one file per brain for the same step.

Layout::

    checkpoints/
        latest.json                                      pointer + metadata of the newest pair
        latest_red.pt   latest_red.pt.sha256             copy of the newest red brain
        latest_blue.pt  latest_blue.pt.sha256            copy of the newest blue brain
        checkpoints/checkpoint_step_000000050000_red.pt  lightweight (rolling; last `keep_last`
        checkpoints/checkpoint_step_000000050000_blue.pt  steps kept) + .sha256 sidecars
        full/checkpoint_step_000000500000_red.pt         full (never deleted automatically)
        full/checkpoint_step_000000500000_blue.pt
        pool/red/pool_step_*.pt  pool/blue/pool_step_*.pt   historical snapshots per brain
        legacy_single_brain/                             pre-split files (archived, untouched)

Every file is written to a temporary name, fsync'ed and atomically renamed, so a crash or
power loss mid-write can never leave a half-written file under a real checkpoint name.
A SHA-256 sidecar lets loading detect silent corruption. Loading tries the newest step first
(both brains must be valid at the same step) and falls back to older ones, logging every
failure. Old single-brain checkpoints are split automatically (both brains start from the
same weights) and the originals are moved to ``legacy_single_brain/``.
"""
from __future__ import annotations

import copy
import glob
import hashlib
import io
import json
import logging
import os
import re
import shutil
import time
from typing import Any, Dict, List, Optional, Tuple

import torch

from .config import ARCH_VERSION, VERSION

log = logging.getLogger("football")
BRAINS = ("red", "blue")                       # index = team (0 = red, 1 = blue)
_STEP_RE = re.compile(r"checkpoint_step_(\d+)_(red|blue)\.pt$")
_LEGACY_RE = re.compile(r"checkpoint_step_(\d+)\.pt$")


class IncompatibleCheckpoint(Exception):
    pass


def _fsync_write(path: str, data: bytes):
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def validate_payload(ck: Dict[str, Any]) -> None:
    """Raise if a loaded checkpoint is not usable by this code version."""
    if not isinstance(ck, dict):
        raise IncompatibleCheckpoint("not a dict")
    if "policy" in ck and "model" not in ck:
        raise IncompatibleCheckpoint(
            "legacy 6v6 DQN checkpoint (football_model_*.pth). The 11v11 architecture is "
            "fundamentally different (entity transformer MAPPO); old weights cannot be "
            "migrated. The old code and models are preserved in legacy/.")
    for k in ("model", "global_step", "arch_version"):
        if k not in ck:
            raise IncompatibleCheckpoint(f"missing key {k!r}")
    if ck["arch_version"] != ARCH_VERSION:
        raise IncompatibleCheckpoint(
            f"architecture version {ck['arch_version']} != current {ARCH_VERSION}")
    for name, t in ck["model"].items():
        if torch.is_tensor(t) and t.is_floating_point() and not torch.isfinite(t).all():
            raise IncompatibleCheckpoint(f"non-finite values in weight {name}")


class CheckpointManager:
    def __init__(self, directory: str, keep_last: int = 20):
        self.dir = directory
        self.step_dir = os.path.join(directory, "checkpoints")
        self.full_dir = os.path.join(directory, "full")
        self.keep_last = keep_last
        os.makedirs(self.step_dir, exist_ok=True)
        os.makedirs(self.full_dir, exist_ok=True)
        self.last_saved: Optional[Dict[str, str]] = None
        migrate_single_brain(directory)

    def latest_path(self, brain: str) -> str:
        return os.path.join(self.dir, f"latest_{brain}.pt")

    # ------------------------------------------------------------------------------------
    def save(self, payloads: Dict[str, Dict[str, Any]], step: int, full: bool = False
             ) -> Dict[str, str]:
        """Write one file per brain (``payloads = {"red": ..., "blue": ...}``) for `step`."""
        saved_at = time.strftime("%Y-%m-%d %H:%M:%S")
        d = self.full_dir if full else self.step_dir
        blobs, paths, brains_meta = {}, {}, {}
        for brain in BRAINS:
            payload = dict(payloads[brain], brain=brain, team=BRAINS.index(brain),
                           global_step=step, arch_version=ARCH_VERSION, version=VERSION,
                           saved_at=saved_at, full=full)
            buf = io.BytesIO()
            torch.save(payload, buf)
            data = buf.getvalue()
            digest = _sha256(data)
            path = os.path.join(d, f"checkpoint_step_{step:012d}_{brain}.pt")
            _fsync_write(path, data)
            _fsync_write(path + ".sha256", digest.encode())
            blobs[brain], paths[brain] = (data, digest), path
            brains_meta[brain] = {"path": os.path.abspath(path), "sha256": digest,
                                  "size": len(data)}
        for brain, (data, digest) in blobs.items():
            _fsync_write(self.latest_path(brain), data)
            _fsync_write(self.latest_path(brain) + ".sha256", digest.encode())
        meta = {"step": step, "full": full, "saved_at": saved_at, "brains": brains_meta,
                "version": VERSION, "arch_version": ARCH_VERSION}
        _fsync_write(os.path.join(self.dir, "latest.json"), json.dumps(meta, indent=2).encode())
        self.last_saved = paths
        self._retention()
        return paths

    def _retention(self):
        steps = sorted(self._list(self.step_dir).items())
        excess = len(steps) - self.keep_last
        for step, files in steps[:max(0, excess)]:
            for path in files.values():
                try:
                    os.remove(path)
                    if os.path.exists(path + ".sha256"):
                        os.remove(path + ".sha256")
                except OSError as e:
                    log.warning(f"Could not remove {path}: {e}")
            log.info(f"Checkpoint retention: removed old lightweight checkpoint step {step:,} "
                     f"(red+blue; full checkpoints are never removed)")

    @staticmethod
    def _list(d: str) -> Dict[int, Dict[str, str]]:
        """step -> {brain: path} for every brain file in directory `d`."""
        out: Dict[int, Dict[str, str]] = {}
        for p in glob.glob(os.path.join(d, "checkpoint_step_*_*.pt")):
            m = _STEP_RE.search(p)
            if m:
                out.setdefault(int(m.group(1)), {})[m.group(2)] = p
        return out

    # ------------------------------------------------------------------------------------
    def candidates(self) -> List[Tuple[int, Dict[str, str]]]:
        """(step, {brain: path}) newest first. For each step and brain the versioned file is
        tried before the latest_<brain>.pt copy; steps may be incomplete (one brain only)."""
        items: Dict[int, Dict[str, List[str]]] = {}
        for d in (self.step_dir, self.full_dir):
            for step, files in self._list(d).items():
                for brain, p in files.items():
                    items.setdefault(step, {}).setdefault(brain, []).append(p)
        step = -1
        try:
            with open(os.path.join(self.dir, "latest.json"), encoding="utf-8") as f:
                step = int(json.load(f).get("step", -1))
        except Exception:
            pass
        for brain in BRAINS:
            lp = self.latest_path(brain)
            if os.path.exists(lp):
                items.setdefault(step, {}).setdefault(brain, []).append(lp)
        return [(s, items[s]) for s in sorted(items, reverse=True)]

    @staticmethod
    def load_file(path: str, map_location="cpu") -> Dict[str, Any]:
        with open(path, "rb") as f:
            data = f.read()
        side = path + ".sha256"
        if os.path.exists(side):
            with open(side, "rb") as f:
                expected = f.read().decode().strip()
            if expected and _sha256(data) != expected:
                raise IncompatibleCheckpoint("SHA-256 mismatch (file corrupted)")
        ck = torch.load(io.BytesIO(data), map_location=map_location, weights_only=False)
        validate_payload(ck)
        return ck

    def _load_first(self, paths: List[str], brain: str, step: int, map_location):
        for path in paths:
            try:
                ck = self.load_file(path, map_location)
                if ck.get("brain", brain) != brain:
                    raise IncompatibleCheckpoint(f"file holds the {ck['brain']} brain")
                if step >= 0 and int(ck["global_step"]) != step:
                    raise IncompatibleCheckpoint(f"step {ck['global_step']} != expected {step}")
                return path, ck
            except IncompatibleCheckpoint as e:
                log.error(f"Checkpoint {path} rejected: {e} -> trying an older one")
            except Exception as e:
                log.error(f"Checkpoint {path} is unreadable/corrupted ({type(e).__name__}: {e})"
                          f" -> trying an older one")
        return None

    def load_latest_valid(self, map_location="cpu"
                          ) -> Optional[Tuple[Dict[str, str], Dict[str, Dict[str, Any]]]]:
        """Newest step at which BOTH brains load: ({brain: path}, {brain: payload})."""
        cands = self.candidates()
        if not cands:
            return None
        for step, files in cands:
            got = {}
            for brain in BRAINS:
                r = self._load_first(files.get(brain, []), brain, step, map_location)
                if r is None:
                    break
                got[brain] = r
            if len(got) == len(BRAINS):
                paths = {b: got[b][0] for b in BRAINS}
                log.info(f"Loaded checkpoint step {got['red'][1]['global_step']:,}: "
                         + ", ".join(f"{b} {paths[b]}" for b in BRAINS))
                return paths, {b: got[b][1] for b in BRAINS}
            if files:
                log.error(f"Checkpoint step {step:,} incomplete or invalid (needs red AND blue) "
                          f"-> trying an older one")
        log.error("No valid checkpoint found; starting a new training run "
                  "(existing files were NOT modified).")
        return None

    def load_latest_brain(self, brain: str, map_location="cpu"
                          ) -> Optional[Tuple[str, Dict[str, Any]]]:
        """Newest valid file of a single brain (for --play / --eval)."""
        for step, files in self.candidates():
            r = self._load_first(files.get(brain, []), brain, step, map_location)
            if r is not None:
                return r
        return None


# ----------------------------------------------------------------------------------------
# migration of the old single-brain layout
# ----------------------------------------------------------------------------------------
def split_payload(ck: Dict[str, Any], brain: str, directory: str) -> Dict[str, Any]:
    """Brain-specific copy of an old single-brain payload (same weights for both brains)."""
    out = copy.deepcopy(ck)
    out.update(brain=brain, team=BRAINS.index(brain), split_from_single_brain=True)
    pool = out.get("pool") or {}
    for e in pool.get("entries", []):
        e["path"] = os.path.join(directory, "pool", brain, os.path.basename(e["path"]))
    old_res = out.pop("results", {}) or {}
    out["results"] = {("rival" if k == "self" else k): list(v) for k, v in old_res.items()}
    return out


def _move(src: str, dst_dir: str):
    os.makedirs(dst_dir, exist_ok=True)
    dst = os.path.join(dst_dir, os.path.basename(src))
    if os.path.exists(dst):
        dst = f"{dst}.{time.strftime('%Y%m%d_%H%M%S')}"
    shutil.move(src, dst)


def migrate_single_brain(directory: str) -> bool:
    """Split checkpoints written by the single-brain trainer into red/blue files.

    Nothing is deleted: originals are moved to ``<directory>/legacy_single_brain/``.
    Returns True when something was migrated."""
    root_ck = [p for p in glob.glob(os.path.join(directory, "checkpoint_step_*.pt*"))
               if _LEGACY_RE.search(p.replace(".sha256", "").replace(".tmp", ""))]
    old_latest = os.path.join(directory, "latest.pt")
    full_dir = os.path.join(directory, "full")
    old_full = [p for p in glob.glob(os.path.join(full_dir, "checkpoint_step_*.pt*"))
                if _LEGACY_RE.search(p.replace(".sha256", "").replace(".tmp", ""))]
    pool_dir = os.path.join(directory, "pool")
    old_pool = glob.glob(os.path.join(pool_dir, "pool_step_*.pt"))
    if not (root_ck or os.path.exists(old_latest) or old_full or old_pool):
        return False
    legacy = os.path.join(directory, "legacy_single_brain")
    step_dir = os.path.join(directory, "checkpoints")
    os.makedirs(step_dir, exist_ok=True)
    log.warning(f"Single-brain checkpoints found in {directory} - splitting them into "
                f"separate red and blue brains (originals kept in {legacy})")
    # pool snapshots: one copy per brain
    for p in old_pool:
        for brain in BRAINS:
            os.makedirs(os.path.join(pool_dir, brain), exist_ok=True)
            dst = os.path.join(pool_dir, brain, os.path.basename(p))
            if not os.path.exists(dst):
                shutil.copy2(p, dst + ".tmp")
                os.replace(dst + ".tmp", dst)
        _move(p, os.path.join(legacy, "pool"))
    old_meta = os.path.join(directory, "latest.json")
    if os.path.exists(old_meta):
        try:
            with open(old_meta, encoding="utf-8") as f:
                single = "brains" not in json.load(f)
        except Exception:
            single = True
        if single:
            _move(old_meta, legacy)
    newest = None
    for p in sorted(root_ck):
        if not p.endswith(".pt"):
            continue
        try:
            ck = CheckpointManager.load_file(p)
        except Exception as e:
            log.error(f"Migration: {p} unusable ({type(e).__name__}: {e}); archived as is")
            continue
        step = int(ck["global_step"])
        for brain in BRAINS:
            data = _serialize(split_payload(ck, brain, directory))
            dst = os.path.join(step_dir, f"checkpoint_step_{step:012d}_{brain}.pt")
            _fsync_write(dst, data)
            _fsync_write(dst + ".sha256", _sha256(data).encode())
        if newest is None or step > newest[0]:
            newest = (step, ck)
        log.info(f"Migration: split {os.path.basename(p)} into red + blue")
    if os.path.exists(old_latest):
        try:
            ck = CheckpointManager.load_file(old_latest)
            if newest is None or int(ck["global_step"]) >= newest[0]:
                newest = (int(ck["global_step"]), ck)
        except Exception as e:
            log.error(f"Migration: latest.pt unusable ({type(e).__name__}: {e})")
    if newest is not None:
        step, ck = newest
        brains_meta = {}
        for brain in BRAINS:
            data = _serialize(split_payload(ck, brain, directory))
            lp = os.path.join(directory, f"latest_{brain}.pt")
            _fsync_write(lp, data)
            _fsync_write(lp + ".sha256", _sha256(data).encode())
            brains_meta[brain] = {"path": os.path.abspath(lp), "sha256": _sha256(data),
                                  "size": len(data)}
        meta = {"step": step, "full": bool(ck.get("full", False)),
                "saved_at": ck.get("saved_at", ""), "brains": brains_meta,
                "version": VERSION, "arch_version": ARCH_VERSION,
                "migrated_from_single_brain": True}
        _fsync_write(os.path.join(directory, "latest.json"), json.dumps(meta, indent=2).encode())
    for p in root_ck:
        _move(p, legacy)
    for name in ("latest.pt", "latest.pt.sha256", "latest.pt.tmp"):
        p = os.path.join(directory, name)
        if os.path.exists(p):
            _move(p, legacy)
    for p in old_full:            # permanent history: archived (still loadable with --play)
        _move(p, os.path.join(legacy, "full"))
    log.warning("Migration to red/blue brains finished")
    return True


def _serialize(payload: Dict[str, Any]) -> bytes:
    buf = io.BytesIO()
    torch.save(payload, buf)
    return buf.getvalue()
