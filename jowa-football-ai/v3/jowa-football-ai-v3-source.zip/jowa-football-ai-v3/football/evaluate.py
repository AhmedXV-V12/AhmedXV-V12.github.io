"""Evaluation: deterministic matches between controllers (policy / historical / scripted)."""
from __future__ import annotations

import dataclasses
import json
import logging
import os
import time
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch

from .checkpoint import BRAINS, CheckpointManager
from .config import Config
from .engine import FootballEnv
from .model import Actor, ActorCritic
from .observation import build_team_obs
from .ppo import obs_to_torch
from .stats import aggregate

log = logging.getLogger("football")


def load_actor(spec: str, device: torch.device, ckpt_dir: str = "checkpoints",
               brain: str = "red") -> Tuple[Actor, Config, dict]:
    """Load an actor from 'latest' (newest file of `brain`), 'red' / 'blue' (newest file of
    that brain), a checkpoint file, or an opponent-pool file."""
    if spec in ("latest", "", None) or spec in BRAINS:
        brain = spec if spec in BRAINS else brain
        res = CheckpointManager(ckpt_dir).load_latest_brain(brain)
        if res is None:
            raise FileNotFoundError(f"No valid {brain} checkpoint in {ckpt_dir}/ - train first "
                                    f"(python jowa-football-ai.py --train)")
        path, ck = res
    else:
        path = spec
        ck = torch.load(spec, map_location="cpu", weights_only=False)
        if "actor" in ck and "model" not in ck:          # opponent-pool snapshot
            cfg = Config()
            a = Actor(cfg.model)
            a.load_state_dict(ck["actor"])
            return a.to(device).eval(), cfg, {"path": path, "step": ck.get("step", 0)}
        from .checkpoint import validate_payload
        validate_payload(ck)
    cfg = Config.from_dict(ck["config"])
    ac = ActorCritic(cfg.model)
    ac.load_state_dict(ck["model"])
    return ac.actor.to(device).eval(), cfg, {"path": path, "step": ck["global_step"],
                                             "brain": ck.get("brain")}


@torch.no_grad()
def actor_act(actor: Actor, obs_list: List[dict], device, deterministic: bool = True,
              temperature: float = 1.0):
    batch = {k: np.stack([o[k] for o in obs_list])[:, None] for k in obs_list[0]}
    ob = obs_to_torch(batch, device)
    with torch.autocast(device_type=device.type, dtype=torch.bfloat16,
                        enabled=device.type == "cuda"):
        logits, coach = actor(ob)
    if deterministic:
        a, c = logits.argmax(-1), coach.argmax(-1)
    else:
        a = torch.distributions.Categorical(logits=logits / temperature).sample()
        c = torch.distributions.Categorical(logits=coach / temperature).sample()
    return a.cpu().numpy(), c.cpu().numpy()


def play_match(cfg: Config, controllers: list, device, deterministic: bool = True,
               seed: int = 0, renderer=None, hud: Optional[dict] = None,
               env: Optional[FootballEnv] = None) -> Dict:
    """controllers[t] = Actor | ('scripted', skill). Returns the match summary."""
    env = env or FootballEnv(cfg, seed)
    for t, c in enumerate(controllers):
        if isinstance(c, tuple) and c[0] == "scripted":
            env.team_control[t] = "scripted"
            env.scripted_skill[t] = c[1]
        else:
            env.team_control[t] = "policy"
    env.record_frames = renderer is not None
    env.reset()
    while True:
        acts = np.zeros(22, dtype=np.int64)
        coach = np.zeros(2, dtype=np.int64)
        for t, c in enumerate(controllers):
            if isinstance(c, Actor):
                a, ca = actor_act(c, [build_team_obs(env, t)], device, deterministic)
                acts[11 * t:11 * t + 11] = a[0]
                coach[t] = ca[0]
        _, _, done, info = env.step(acts, coach)
        if renderer is not None:
            renderer.after_step(env, hud or {})
            if renderer.quit_requested:
                return {"aborted": True, **env.stats.summary()}
        if done:
            return info["match_summary"]


def evaluate(cfg: Config, learner: Actor, opponent, n_matches: int, device,
             half_duration_s: Optional[float] = None, seed: int = 0) -> Dict:
    """Deterministic evaluation of `learner` vs `opponent`, alternating sides."""
    if half_duration_s:
        cfg = dataclasses.replace(cfg, rules=dataclasses.replace(cfg.rules,
                                                                 half_duration_s=half_duration_s))
    summaries, sides, results = [], [], []
    for m in range(n_matches):
        side = m % 2
        ctrls = [None, None]
        ctrls[side], ctrls[1 - side] = learner, opponent
        s = play_match(cfg, ctrls, device, deterministic=True, seed=seed + m)
        summaries.append(s)
        sides.append(side)
        gf, ga = s[f"t{side}_goals"], s[f"t{1 - side}_goals"]
        results.append(1.0 if gf > ga else (0.5 if gf == ga else 0.0))
    agg = aggregate(summaries, sides)
    agg["points"] = float(np.mean(results))
    agg["matches"] = n_matches
    return agg


def background_eval(ckpt_paths: Dict[str, str], out_path: str, n_matches: int,
                    half_duration_s: float, seed: int):
    """Entry point for the background evaluation process (CPU, never blocks training).
    Evaluates every brain in `ckpt_paths` ({brain: file}) and appends one line per brain."""
    try:
        torch.set_num_threads(2)
        device = torch.device("cpu")
        for brain, path in ckpt_paths.items():
            actor, cfg, meta = load_actor(path, device)
            t0 = time.time()
            res = evaluate(cfg, actor, ("scripted", 1.0), n_matches, device, half_duration_s,
                           seed)
            res.update(step=meta["step"], brain=brain, opponent="scripted",
                       eval_seconds=time.time() - t0)
            os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
            with open(out_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(res, default=float) + "\n")
    except Exception as e:     # never let evaluation crash anything
        with open(out_path + ".errors", "a", encoding="utf-8") as f:
            f.write(f"{time.ctime()} {type(e).__name__}: {e}\n")
