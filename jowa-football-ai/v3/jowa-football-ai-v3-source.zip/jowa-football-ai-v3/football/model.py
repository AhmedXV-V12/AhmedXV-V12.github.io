"""Neural networks: entity transformer actor-critic for 11-player teams (MAPPO).

Architecture
------------
* **Token embedding**: per-token linear projection of the 56 features + token-type embedding
  (context / ball / teammate / opponent) + role embedding + previous-action embedding.
* **Geometric attention bias**: for every token pair the offset (dx, dy) and distance are fed
  to a small MLP that outputs a per-head additive attention bias. Spatial relations (who is
  near whom, who is between the ball and goal) are then first-class for attention instead of
  having to be rediscovered from absolute coordinates.
* **Actor** (shared parameters for all 22 players, role-conditioned): transformer encoder,
  then for each own-player token
    - base head: 19 logits (stand, 8 moves, 7 tactical options, tackle, shoot, clear)
    - pointer head: bilinear passer x receiver scores for pass-to-feet and through-ball
  and a **coach head** on the context token (team-level tactical instruction).
  Players act independently given the shared attention context (decentralised execution
  with implicit communication through attention).
* **Critic** (centralised): separate transformer with the same input; per-player value
  heads (each player has its own reward stream) and a team value for the coach.
"""
from __future__ import annotations

import math
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F_

from . import actions as A
from .formation import NUM_ROLES
from .observation import F, N_TOKENS, OWN0, OPP0, PAD_ACTION, PAD_ROLE
from .tactics import NUM_COACH_ACTIONS
from .config import ModelConfig

NEG_INF = -1e9


def token_types(device) -> torch.Tensor:
    t = torch.zeros(N_TOKENS, dtype=torch.long, device=device)
    t[1] = 1
    t[OWN0:OWN0 + 11] = 2
    t[OPP0:OPP0 + 11] = 3
    return t


class GeoBias(nn.Module):
    """Pairwise geometric attention bias: (B, T, 2) positions -> (B, H, T, T)."""

    def __init__(self, n_heads: int, hidden: int = 32):
        super().__init__()
        self.mlp = nn.Sequential(nn.Linear(4, hidden), nn.GELU(), nn.Linear(hidden, n_heads))

    def forward(self, pos: torch.Tensor) -> torch.Tensor:
        d = pos[:, :, None, :] - pos[:, None, :, :]                    # (B, T, T, 2)
        dist = torch.sqrt((d * d).sum(-1, keepdim=True) + 1e-6)
        feat = torch.cat([d * 2.0, dist * 2.0, torch.exp(-dist * 8.0)], dim=-1)
        return self.mlp(feat).permute(0, 3, 1, 2).contiguous()           # (B, H, T, T)


class Block(nn.Module):
    def __init__(self, d: int, h: int, ff_mult: int, dropout: float):
        super().__init__()
        self.h = h
        self.ln1 = nn.LayerNorm(d)
        self.qkv = nn.Linear(d, 3 * d)
        self.proj = nn.Linear(d, d)
        self.ln2 = nn.LayerNorm(d)
        self.ff = nn.Sequential(nn.Linear(d, ff_mult * d), nn.GELU(), nn.Linear(ff_mult * d, d))
        self.drop = dropout

    def forward(self, x: torch.Tensor, bias: torch.Tensor) -> torch.Tensor:
        B, T_, D = x.shape
        q, k, v = self.qkv(self.ln1(x)).view(B, T_, 3, self.h, D // self.h).unbind(2)
        q, k, v = (t.transpose(1, 2) for t in (q, k, v))                # (B, H, T, dh)
        att = F_.scaled_dot_product_attention(q, k, v, attn_mask=bias.to(q.dtype),
                                              dropout_p=self.drop if self.training else 0.0)
        x = x + self.proj(att.transpose(1, 2).reshape(B, T_, D))
        return x + self.ff(self.ln2(x))


class EntityEncoder(nn.Module):
    def __init__(self, cfg: ModelConfig, n_layers: int):
        super().__init__()
        d = cfg.d_model
        self.inp = nn.Sequential(nn.Linear(F, d), nn.GELU(), nn.Linear(d, d))
        self.type_emb = nn.Embedding(4, d)
        self.role_emb = nn.Embedding(NUM_ROLES + 1, d)
        self.act_emb = nn.Embedding(A.NUM_ACTIONS + 1, d)
        self.geo = GeoBias(cfg.n_heads)
        self.blocks = nn.ModuleList([Block(d, cfg.n_heads, cfg.ff_mult, cfg.dropout)
                                     for _ in range(n_layers)])
        self.ln = nn.LayerNorm(d)
        self.register_buffer("types", token_types("cpu"), persistent=False)

    def forward(self, obs: Dict[str, torch.Tensor]) -> torch.Tensor:
        x = self.inp(obs["tokens"])
        x = x + self.type_emb(self.types)[None] + self.role_emb(obs["roles"]) \
            + self.act_emb(obs["prev"])
        bias = self.geo(obs["pos"])
        for blk in self.blocks:
            x = blk(x, bias)
        return self.ln(x)


class Actor(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        d = cfg.d_model
        self.enc = EntityEncoder(cfg, cfg.actor_layers)
        self.base_head = nn.Sequential(nn.Linear(d, d), nn.GELU(), nn.Linear(d, A.NUM_BASE))
        self.q_feet = nn.Linear(d, d)
        self.k_feet = nn.Linear(d, d)
        self.q_thr = nn.Linear(d, d)
        self.k_thr = nn.Linear(d, d)
        self.coach_head = nn.Sequential(nn.Linear(d, d), nn.GELU(),
                                        nn.Linear(d, NUM_COACH_ACTIONS))
        self.scale = 1.0 / math.sqrt(d)
        # small init on output layers -> near-uniform initial policy
        for head in (self.base_head[-1], self.coach_head[-1]):
            nn.init.orthogonal_(head.weight, gain=0.01)
            nn.init.zeros_(head.bias)
        for lin in (self.q_feet, self.q_thr):
            nn.init.orthogonal_(lin.weight, gain=0.1)

    def forward(self, obs: Dict[str, torch.Tensor]) -> Tuple[torch.Tensor, torch.Tensor]:
        """Returns masked player logits (B, 11, NUM_ACTIONS) and coach logits (B, 6)."""
        h = self.enc(obs)
        own = h[:, OWN0:OWN0 + 11]                                         # (B, 11, d)
        base = self.base_head(own)
        feet = torch.einsum("bid,bjd->bij", self.q_feet(own), self.k_feet(own)) * self.scale
        thr = torch.einsum("bid,bjd->bij", self.q_thr(own), self.k_thr(own)) * self.scale
        logits = torch.cat([base, feet, thr], dim=-1).float()
        logits = logits.masked_fill(~obs["mask"], NEG_INF)
        coach = self.coach_head(h[:, 0]).float()
        return logits, coach


class Critic(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        d = cfg.d_model
        self.enc = EntityEncoder(cfg, cfg.critic_layers)
        self.player_v = nn.Sequential(nn.Linear(2 * d, d), nn.GELU(), nn.Linear(d, 1))
        self.team_v = nn.Sequential(nn.Linear(d, d), nn.GELU(), nn.Linear(d, 1))

    def forward(self, obs: Dict[str, torch.Tensor]) -> Tuple[torch.Tensor, torch.Tensor]:
        h = self.enc(obs)
        own = h[:, OWN0:OWN0 + 11]
        ctx = h[:, :1].expand(-1, 11, -1)
        v_players = self.player_v(torch.cat([own, ctx], dim=-1)).squeeze(-1).float()
        v_team = self.team_v(h[:, 0]).squeeze(-1).float()
        return v_players, v_team


class ActorCritic(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.actor = Actor(cfg)
        self.critic = Critic(cfg)

    @torch.no_grad()
    def act(self, obs: Dict[str, torch.Tensor], deterministic: bool = False,
            need_value: bool = True):
        logits, coach_logits = self.actor(obs)
        if deterministic:
            a = logits.argmax(-1)
            c = coach_logits.argmax(-1)
        else:
            a = torch.distributions.Categorical(logits=logits).sample()
            c = torch.distributions.Categorical(logits=coach_logits).sample()
        logp = torch.log_softmax(logits, -1).gather(-1, a[..., None]).squeeze(-1)
        clogp = torch.log_softmax(coach_logits, -1).gather(-1, c[:, None]).squeeze(-1)
        out = {"actions": a, "logp": logp, "coach": c, "coach_logp": clogp}
        if need_value:
            v, vt = self.critic(obs)
            out["value"], out["team_value"] = v, vt
        return out

    def evaluate(self, obs: Dict[str, torch.Tensor], actions: torch.Tensor,
                 coach: torch.Tensor):
        logits, coach_logits = self.actor(obs)
        logp_all = torch.log_softmax(logits, -1)
        logp = logp_all.gather(-1, actions[..., None]).squeeze(-1)
        probs = logp_all.exp()
        entropy = -(probs * torch.where(obs["mask"], logp_all, torch.zeros_like(logp_all))).sum(-1)
        clogp_all = torch.log_softmax(coach_logits, -1)
        clogp = clogp_all.gather(-1, coach[:, None]).squeeze(-1)
        centropy = -(clogp_all.exp() * clogp_all).sum(-1)
        v, vt = self.critic(obs)
        return {"logp": logp, "entropy": entropy, "coach_logp": clogp, "coach_entropy": centropy,
                "value": v, "team_value": vt, "logp_all": logp_all}


def _gumbel_sample(logits: torch.Tensor) -> torch.Tensor:
    u = torch.rand_like(logits).clamp_(1e-10, 1.0 - 1e-7)
    return (logits - torch.log(-torch.log(u))).argmax(-1)


class GraphedPolicy:
    """Rollout inference for a fixed batch of team slots captured in a CUDA graph.

    Small-batch transformer inference is dominated by kernel-launch overhead; replaying a
    captured graph removes it (and all host synchronisation). Sampling uses the Gumbel-max
    trick so it lives inside the graph. Parameters are shared with the live model, so
    optimizer updates are picked up automatically. Falls back to eager execution on CPU or if
    capture fails.
    """

    def __init__(self, model: ActorCritic, example_obs: Dict[str, torch.Tensor]):
        self.model = model
        self.graph = None
        self.static_in = {k: v.clone() for k, v in example_obs.items()}
        self.static_out = None
        if example_obs["tokens"].device.type != "cuda":
            return
        try:
            s = torch.cuda.Stream()
            s.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(s), torch.no_grad():
                for _ in range(3):
                    self._forward(self.static_in)
            torch.cuda.current_stream().wait_stream(s)
            g = torch.cuda.CUDAGraph()
            with torch.cuda.graph(g), torch.no_grad():
                self.static_out = self._forward(self.static_in)
            self.graph = g
        except Exception as e:  # pragma: no cover - hardware dependent
            import logging
            logging.getLogger("football").warning(f"CUDA graph capture failed ({e}); eager mode")
            self.graph = None

    def _forward(self, obs):
        logits, coach_logits = self.model.actor(obs)
        a = _gumbel_sample(logits)
        c = _gumbel_sample(coach_logits)
        logp = torch.log_softmax(logits, -1).gather(-1, a[..., None]).squeeze(-1)
        clogp = torch.log_softmax(coach_logits, -1).gather(-1, c[:, None]).squeeze(-1)
        v, vt = self.model.critic(obs)
        return {"actions": a, "logp": logp, "coach": c, "coach_logp": clogp,
                "value": v, "team_value": vt}

    @torch.no_grad()
    def __call__(self, obs: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        if self.graph is None:
            return self._forward(obs)
        for k, v in obs.items():
            self.static_in[k].copy_(v, non_blocking=True)
        self.graph.replay()
        return self.static_out


def count_parameters(m: nn.Module) -> int:
    return sum(p.numel() for p in m.parameters())
