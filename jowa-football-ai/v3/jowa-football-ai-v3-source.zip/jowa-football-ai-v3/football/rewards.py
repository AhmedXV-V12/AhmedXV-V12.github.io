"""Reward system.

Design principles (see RewardConfig for weights):

1. **Goals are the unit of value** (+1 scored / -1 conceded, shared by the whole team).
2. **Dense team shaping is potential-based**: r = gamma * Phi(s') - Phi(s) with
   Phi = xT possession value + pressure on the opposing carrier + quality of our passing
   options - exposure of dangerous unmarked opponents. Potential-based shaping cannot change
   the optimal policy and cannot be farmed: any cycle (ping-pong passing, hoarding the ball in
   a corner, oscillating runs) returns to the same potential and nets <= 0 (the discount even
   makes idle possession slowly lose value, which rewards progression).
3. **Individual terms are small and event-based**, credited to the player who caused them
   (passes, recoveries, blocks, saves, fouls, turnovers...). Farmable ones are guarded:
   progressive-pass credit requires advancing the team's *possession frontier*, repeated
   non-progressive passes earn geometrically decaying credit, shooting from hopeless
   positions is penalised.
4. **Structural regularisers** keep the football believable: leaving the tactical zone
   without being engaged in play, crowding team-mates, surplus players around the ball,
   running into opponents, ball hoarding, pointless sprinting.

The coach (team-level policy) is trained on the team-shared part only.
"""
from __future__ import annotations

import numpy as np

from . import geometry as G
from . import tactics as T
from .formation import ROLE_ZONE_TOLERANCE, GK

HL = G.HL

REWARD_COMPONENTS = ["goal", "shaping", "shot", "pass", "turnover", "recovery", "defence",
                     "discipline", "shape", "crowding", "chase", "stall", "effort"]


def _sp_value(kind: int, b: np.ndarray) -> float:
    if kind == T.SP_PENALTY:
        return 0.75
    if kind == T.SP_CORNER:
        return 0.035
    base = float(G.xt(b[0], b[1]))
    if kind == T.SP_FREE_KICK and b[0] > 0:
        base += 0.35 * float(G.xg_raw(b[0], b[1]))
    return base


def team_potential(env, t: int) -> float:
    v = env.views[t]
    w = env.reward_weights
    b = v.b
    if env.dead:
        if env.sp_team == t:
            phi_xt = _sp_value(env.sp_kind, b)
        else:
            phi_xt = -_sp_value(env.sp_kind, -b)
    elif v.carrier >= 0:
        phi_xt = float(G.xt(b[0], b[1]))
    elif v.opp_carrier >= 0:
        phi_xt = -float(G.xt(-b[0], -b[1]))
    else:
        dt = float(v.opp_t2b.min() - v.t2b.min())
        p_own = 1.0 / (1.0 + np.exp(-np.clip(dt / 0.6, -30, 30)))
        phi_xt = p_own * float(G.xt(b[0], b[1])) - (1 - p_own) * float(G.xt(-b[0], -b[1]))
    return (w.xt_potential * phi_xt + w.pressure_potential * v.phi_press
            + w.options_potential * v.phi_opt - w.exposure_potential * v.phi_exposure)


def compute_rewards(env):
    """Returns (player_rewards (22,), team_rewards (2,)) and logs components on the env."""
    w = env.reward_weights
    gamma = env.cfg.ppo.gamma
    iw = w.individual_weight
    r_team = np.zeros(2)
    r_ind = np.zeros(22)
    comp = env.reward_log            # reset by env.reset() at the start of every match

    def add(p: int, key: str, val: float):
        r_ind[p] += val * iw
        comp[p // 11][key] += val * iw / 11.0      # log = per-player average decomposition

    # ---- team shaping (potential-based) ----------------------------------------------
    new_phi = [team_potential(env, t) for t in range(2)]
    for t in range(2):
        nxt = 0.0 if env.done else new_phi[t]
        shaping = gamma * nxt - env.phi[t]
        r_team[t] += shaping
        comp[t]["shaping"] += shaping
    env.phi = new_phi

    # ---- events -------------------------------------------------------------------------
    for e in env.events:
        kind = e[0]
        if kind == "goal":
            team, scorer = e[1], e[2]
            r_team[team] += w.goal
            r_team[1 - team] -= w.goal
            comp[team]["goal"] += w.goal
            comp[1 - team]["goal"] -= w.goal
            if scorer >= 0:
                add(scorer, "shot", 0.1)
            if len(e) > 3 and e[3] >= 0:
                add(e[3], "pass", 0.05)
        elif kind == "shot":
            p, xg = e[1], e[2]
            if xg >= w.shot_min_xg:
                add(p, "shot", w.shot_quality * min(1.0, xg / 0.3))
            elif xg < w.bad_shot_xg:
                add(p, "shot", -w.bad_shot)
        elif kind == "pass_complete":
            passer, progressive, n_nonprog = e[1], e[3], e[4]
            if progressive:
                add(passer, "pass", w.pass_complete + w.progressive_pass)
            else:
                add(passer, "pass", w.pass_complete * (w.pass_decay ** max(0, n_nonprog - 1)))
        elif kind == "turnover":
            loser, winner = e[1], e[2]
            if loser >= 0:
                lt = loser // 11
                bx = float(env.bpos[0] * env.attack_dir[lt])
                own_third = 1.0 if bx < -HL / 3 else 0.0
                add(loser, "turnover", -w.turnover * (1.0 + 2.0 * own_third))
            if winner >= 0:
                wt = winner // 11
                bx = float(env.bpos[0] * env.attack_dir[wt])
                add(winner, "recovery", w.recovery * (1.0 + 0.5 * (bx < -HL / 3)))
        elif kind == "save":
            add(e[1], "defence", w.save * max(0.05, e[2]))
        elif kind == "block":
            add(e[1], "defence", w.block)
        elif kind == "foul":
            add(e[1], "discipline", -w.foul)
            if e[3]:
                add(e[1], "discipline", -w.penalty_conceded)
        elif kind == "offside":
            add(e[1], "discipline", -w.offside)
        elif kind == "out":
            p, how, last_kick = e[1], e[2], (e[3] if len(e) > 3 else "")
            if p >= 0 and last_kick not in ("clear", "shot"):
                add(p, "turnover", -w.out_of_play)
        elif kind == "collision":
            add(e[1], "discipline", -w.collision)

    # ---- per-step structural terms ----------------------------------------------------
    jog = env.phys.jog_speed
    speed = G.norm(env.vel, axis=1)
    for t in range(2):
        v = env.views[t]
        base = 11 * t
        # tactical zone discipline
        tol = np.array([ROLE_ZONE_TOLERANCE[int(r)] for r in env.form.roles])
        if v.possession == 1:
            tol = tol * 1.3
        dev = np.clip((G.norm(v.P - v.anchors, axis=1) - tol) / 15.0, 0.0, 1.0)
        dev[v.engaged] = 0.0
        for i in np.nonzero(dev)[0]:
            add(base + i, "shape", -w.shape * env.shape_mult * dev[i])
        # crowding (outfield pairs closer than 5 m)
        outfield = np.array([i for i in range(11) if env.form.roles[i] != GK])
        Pm = v.P[outfield]
        dd = G.norm(Pm[:, None] - Pm[None], axis=-1)
        np.fill_diagonal(dd, np.inf)
        pen = np.clip(1.0 - dd / 5.0, 0.0, 1.0).sum(axis=1)
        for k, i in enumerate(outfield):
            if pen[k] > 0:
                add(base + i, "crowding", -w.crowding * min(pen[k], 2.0))
        # surplus players around the ball
        if not env.dead:
            near = G.norm(v.P - v.b, axis=1) < 10.0
            surplus = near & (v.rank > 2)
            if v.carrier >= 0:
                surplus[v.carrier] = False
            surplus &= ~(v.mark_assign >= 0)
            for i in np.nonzero(surplus)[0]:
                add(base + i, "chase", -w.ball_chase)
        # hoarding the ball without progress
        if v.carrier >= 0 and not env.dead and env.stall_time > env.rules.max_stall_s:
            add(base + v.carrier, "stall", -w.stall)
        # pointless sprinting
        sprinting = speed[base:base + 11] > jog + 0.5
        for i in np.nonzero(sprinting)[0]:
            add(base + i, "effort", -w.sprint_cost)

    r_players = np.concatenate([np.full(11, r_team[0]), np.full(11, r_team[1])]) + r_ind
    if not np.all(np.isfinite(r_players)):
        r_players = np.nan_to_num(r_players, nan=0.0, posinf=0.0, neginf=0.0)
        r_team = np.nan_to_num(r_team, nan=0.0, posinf=0.0, neginf=0.0)
    return r_players.astype(np.float32), r_team.astype(np.float32)
