"""11v11 football match engine: physics + simplified laws of the game.

Players 0..10 are team 0 (red), 11..21 team 1 (blue). Everything here is in the world frame
(metres, origin at the centre spot). Agents decide at 5 Hz (``physics.substeps`` sub-steps
of ``physics.dt``); the low-level controller turns each decision into a movement target that is
re-evaluated every sub-step.

Implemented laws (simplified): kick-off, halves & side switch, full time, goals, throw-ins,
corners, goal kicks, direct/indirect free kicks, fouls from tackles, penalties, offside
(judged at the moment of the pass, punished on first touch), goalkeeper handling in the
penalty area with a 6 s holding limit, double-touch at restarts, 9.15 m wall distance.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from . import actions as A
from . import geometry as G
from . import tactics as T
from .config import Config
from .formation import Formation, GK, ST
from .stats import MatchStats

HL, HW = G.HL, G.HW
TEAM_SLICES = (slice(0, 11), slice(11, 22))
PASS_KINDS = ("pass", "through")


def team_of(p: int) -> int:
    return 0 if p < 11 else 1


@dataclass
class KickInfo:
    kicker: int = -1
    team: int = -1
    kind: str = ""                 # pass | through | shot | clear | ""
    target: int = -1               # intended receiver (world index)
    start: np.ndarray = field(default_factory=lambda: np.zeros(2))
    time: float = 0.0
    offside_set: frozenset = frozenset()
    xg: float = 0.0
    restart: int = T.SP_NONE       # set-piece kind the kick restarted play from
    frontier: float = -HL          # possession frontier (team frame) at kick time


class FootballEnv:
    """A single 11v11 match environment."""

    def __init__(self, cfg: Config, seed: Optional[int] = None):
        self.cfg = cfg
        self.phys = cfg.physics
        self.rules = cfg.rules
        self.rng = np.random.default_rng(seed)
        self.form = Formation(cfg.formation.name)
        self.roles = np.concatenate([self.form.roles, self.form.roles])
        self.numbers = np.concatenate([self.form.numbers, self.form.numbers])
        self.gk_idx = (self.form.gk_index, 11 + self.form.gk_index)
        # control configuration (set by the training loop / play mode)
        self.team_control = ["policy", "policy"]      # or "scripted"
        self.scripted_skill = [1.0, 1.0]
        self.want_teacher = [False, False]
        self.human_player: int = -1
        self.human_command: Optional[dict] = None
        self.record_frames = False
        self.frames: List[tuple] = []
        self.reward_weights = cfg.reward
        self.shape_mult = 1.0
        self._scripted = None
        self.match_count = 0
        self.reset()

    # =====================================================================================
    # reset / restarts
    # =====================================================================================
    def reset(self):
        c = self.phys
        self.pos = np.zeros((22, 2))
        self.vel = np.zeros((22, 2))
        self.facing = np.zeros((22, 2))
        self.stamina = np.ones(22)
        self.stun = np.zeros(22)
        self.kick_cd = np.zeros(22)
        self.tackle_cd = np.zeros(22)
        self.bpos = np.zeros(2)
        self.bvel = np.zeros(2)
        self.bz = 0.0
        self.bvz = 0.0
        self.possessor = -1
        self.poss_team = -1
        self.last_controller = -1
        self.last_touch = -1
        self.last_touch_team = -1
        self.flight_team = -1
        self.kick = KickInfo()
        self.shot_pending: Optional[dict] = None
        self.dead = False
        self.sp_kind = T.SP_NONE
        self.sp_team = -1
        self.sp_spot = np.zeros(2)
        self.sp_taker = -1
        self.sp_timer = 0.0
        self.double_touch = -1
        self.half = 0
        self.t_half = 0.0
        self.time = 0.0
        self.attack_dir = np.array([1.0, -1.0])
        self.score = [0, 0]
        self.tactics = [T.TacticalState(), T.TacticalState()]
        self.prev_actions = np.zeros(22, dtype=np.int64)
        self.coach_step = 0
        self.hold_time = 0.0
        self.stall_time = 0.0
        self.last_pass = None
        self.loose_time = 0.0
        self.frontier = [-HL, -HL]
        self.nonprog_passes = [0, 0]
        self.poss_start_time = 0.0
        self.stats = MatchStats()
        from .rewards import REWARD_COMPONENTS
        self.reward_log = [dict.fromkeys(REWARD_COMPONENTS, 0.0) for _ in range(2)]
        self._prev_phase = [-1, -1]
        self._contacts = set()
        self.events: List[tuple] = []
        self.done = False
        self.first_kickoff = int(self.rng.integers(2))
        self._kickoff(self.first_kickoff)
        self.views = self._analyze()
        self.phi = [self._potential(t) for t in range(2)]
        self.masks = self._build_masks()
        return self

    def _world(self, team: int, p: np.ndarray) -> np.ndarray:
        return p * self.attack_dir[team]

    def _team_pos(self, team: int, p: np.ndarray) -> np.ndarray:
        return p * self.attack_dir[team]

    def _kickoff(self, team: int):
        """Teleport everyone to kick-off positions; ``team`` kicks off."""
        for t in range(2):
            kp = self.form.kickoff_positions(HW, HL)
            kp[:, 1] += self.rng.normal(0, 0.5, 11)
            self.pos[TEAM_SLICES[t]] = self._world(t, kp)
            self.facing[TEAM_SLICES[t]] = self._world(t, np.array([1.0, 0.0]))
        self.vel[:] = 0.0
        strikers = [i for i in range(11) if self.form.roles[i] == ST]
        taker = TEAM_SLICES[team].start + (strikers[0] if strikers else 9)
        self._begin_setpiece(T.SP_KICKOFF, team, np.zeros(2), taker)

    def _nearest_outfield(self, team: int, spot: np.ndarray, exclude_gk: bool = True) -> int:
        sl = TEAM_SLICES[team]
        d = G.norm(self.pos[sl] - spot, axis=1)
        if exclude_gk:
            d[self.form.gk_index] = 1e9
        return sl.start + int(np.argmin(d))

    def _begin_setpiece(self, kind: int, team: int, spot: np.ndarray, taker: int = -1):
        self.dead = True
        self.sp_kind = kind
        self.sp_team = team
        self.sp_spot = np.array(spot, dtype=float)
        self.sp_timer = 0.0
        self.bpos = self.sp_spot.copy()
        self.bvel[:] = 0.0
        self.bz = self.bvz = 0.0
        self.flight_team = -1
        self.shot_pending = None
        self.kick = KickInfo()
        if taker < 0:
            if kind == T.SP_GOAL_KICK:
                taker = self.gk_idx[team]
            else:
                own_box = G.in_penalty_area(*(self._team_pos(team, self.sp_spot)))
                if kind in (T.SP_FREE_KICK, T.SP_INDIRECT) and bool(own_box):
                    taker = self.gk_idx[team]
                else:
                    taker = self._nearest_outfield(team, self.sp_spot)
        self.sp_taker = taker
        self.possessor = taker
        self.poss_team = team
        self.last_controller = taker
        self.double_touch = -1
        self.hold_time = 0.0
        self._place_taker()
        names = {T.SP_CORNER: "corners", T.SP_THROW_IN: "throw_ins", T.SP_GOAL_KICK: "goal_kicks",
                 T.SP_FREE_KICK: "free_kicks", T.SP_INDIRECT: "free_kicks",
                 T.SP_PENALTY: "penalties"}
        if kind in names:
            self.stats.add(team, names[kind])
        self.events.append(("restart", kind, team))

    def _place_taker(self):
        t = self.sp_team
        into = self._world(t, np.array([1.0, 0.0]))
        if self.sp_kind == T.SP_THROW_IN:
            into = np.array([0.0, -np.sign(self.sp_spot[1]) or 1.0])
        elif self.sp_kind == T.SP_CORNER:
            into = -self.sp_spot / max(G.norm(self.sp_spot), 1e-6)
        self.facing[self.sp_taker] = into
        self.pos[self.sp_taker] = self.sp_spot - into * 0.6
        self.vel[self.sp_taker] = 0.0

    # =====================================================================================
    # main step
    # =====================================================================================
    def step(self, actions: np.ndarray, coach_actions: Optional[np.ndarray] = None):
        """Advance one decision step (0.2 s).

        actions: (22,) int array for all players (ignored for scripted teams / human player).
        coach_actions: (2,) team-level tactical instruction, applied on coach ticks.
        Returns (player_rewards (22,), team_rewards (2,), done, info).
        """
        self.events = []
        self.frames = []
        cfg = self.cfg
        dt = self.phys.dt
        actions = np.asarray(actions, dtype=np.int64).copy()

        # ---- coach (team tactical layer)
        coach_tick = self.coach_step % cfg.train.coach_interval == 0
        self.coach_step += 1
        for t in range(2):
            if self.team_control[t] == "scripted":
                if coach_tick:
                    self.tactics[t].coach_action = self._scripted_coach(t)
            elif coach_tick and coach_actions is not None:
                self.tactics[t].coach_action = int(coach_actions[t]) % T.NUM_COACH_ACTIONS

        # ---- scripted / human overrides, action validation
        for t in range(2):
            if self.team_control[t] == "scripted":
                actions[TEAM_SLICES[t]] = self.scripted_actions(t)
        if 0 <= self.human_player < 22 and self.human_command is not None:
            actions[self.human_player] = self._human_action()
        for p in range(22):
            t, i = team_of(p), p % 11
            if not self.masks[t][i, actions[p]]:
                actions[p] = self._fallback_action(t, i)
        self.last_actions = actions

        # ---- instantaneous ball actions (kicks first, then tackles)
        for p in range(22):
            a = int(actions[p])
            if (a == A.SHOOT or a == A.CLEAR or A.is_pass(a)) and self.possessor == p:
                self._execute_kick(p, a)
        for p in self.rng.permutation(22):
            if actions[p] == A.TACKLE:
                self._execute_tackle(int(p))

        # ---- movement commands
        self._plan_movement(actions)

        # ---- physics sub-steps
        for _ in range(self.phys.substeps):
            self._substep(dt, actions)
            if self.record_frames:
                self.frames.append((self.pos.copy(), self.bpos.copy(), self.bz, self.possessor))
            if self.done:
                break

        # ---- clock / periods
        step_dt = dt * self.phys.substeps
        self.time += step_dt
        self.t_half += step_dt
        if self.dead:
            self.sp_timer += step_dt
        if self.poss_team >= 0 and not self.dead:
            self.stats.add(self.poss_team, "possession_time", step_dt)
        self._update_loose_timer(step_dt)
        if self.t_half >= self.rules.half_duration_s - 1e-6 and not self.done:
            self._end_half()

        # ---- analysis, rewards, observations
        self.views = self._analyze()
        from .rewards import compute_rewards
        r_players, r_team = compute_rewards(self)
        self._track_stats(step_dt)
        self.prev_actions = actions
        self.masks = self._build_masks()
        info = {"events": self.events, "coach_tick": coach_tick}
        if self.done:
            info["match_summary"] = self.stats.summary()
            info["score"] = tuple(self.score)
        return r_players, r_team, self.done, info

    # =====================================================================================
    # analysis
    # =====================================================================================
    def vmax(self) -> np.ndarray:
        v = self.phys.sprint_speed * (0.72 + 0.28 * self.stamina)
        v = np.where(self.stun > 0, v * 0.45, v)
        return v

    def _analyze(self):
        vmax = self.vmax()
        order = [0, 1]
        carrier_team = team_of(self.possessor) if self.possessor >= 0 else -1
        if carrier_team == 1:
            order = [1, 0]
        views = [None, None]
        opts = None
        step_dt = self.phys.dt * self.phys.substeps
        for t in order:
            other_opts = None
            if opts is not None:           # carrier team's options in this team's frame
                other_opts = T.PassOptions(**{k: (v * -1 if k in ("feet_target", "thr_target")
                                                  else v) for k, v in opts.__dict__.items()})
            v = T.build_team_view(t, self.attack_dir[t], self.form, self.tactics[t], self.pos,
                                  self.vel, vmax, self.bpos, self.bvel, self.bz, self.bvz,
                                  self.possessor, self.dead, self.sp_kind, self.sp_team,
                                  self.phys, step_dt, other_opts, self.flight_team)
            views[t] = v
            if v.carrier >= 0:
                opts = v.passes
        return views

    def _potential(self, t: int) -> float:
        """Team potential Phi used for shaping (see rewards.py)."""
        from .rewards import team_potential
        return team_potential(self, t)

    # =====================================================================================
    # masks
    # =====================================================================================
    def _build_masks(self):
        return [self._team_mask(t) for t in range(2)]

    def _team_mask(self, t: int) -> np.ndarray:
        v = self.views[t]
        m = np.zeros((11, A.NUM_ACTIONS), dtype=bool)
        gk = self.form.gk_index
        base = TEAM_SLICES[t].start
        b = v.b
        for i in range(11):
            p = base + i
            if self.dead and p == self.sp_taker:
                if self.sp_timer < self.rules.setpiece_setup_s:
                    m[i, A.STAND] = True
                    continue
                if self.sp_timer < self.rules.setpiece_force_s and self.sp_kind != T.SP_PENALTY:
                    m[i, A.STAND] = True
                if self.sp_kind == T.SP_PENALTY:
                    m[i, A.SHOOT] = True
                    continue
                self._pass_mask(m, i, v, max_dist=32.0 if self.sp_kind == T.SP_THROW_IN else 90.0)
                if self.sp_kind in (T.SP_GOAL_KICK, T.SP_FREE_KICK, T.SP_INDIRECT, T.SP_KICKOFF):
                    m[i, A.CLEAR] = True
                if self.sp_kind == T.SP_FREE_KICK and b[0] > 0 and \
                        np.hypot(HL - b[0], b[1]) < 35.0:
                    m[i, A.SHOOT] = True
                if not m[i].any():
                    m[i, A.CLEAR] = True
                continue
            if v.carrier == i:
                holding_gk = (i == gk)
                m[i, A.STAND] = True
                m[i, A.MOVE_START:A.MOVE_START + A.NUM_DIRS] = True
                m[i, A.CLEAR] = True
                self._pass_mask(m, i, v)
                if not holding_gk and b[0] > 0 and np.hypot(HL - b[0], b[1]) < 38.0:
                    m[i, A.SHOOT] = True
                if holding_gk and self.hold_time > self.rules.gk_max_hold_s - 1.0:
                    m[i, A.STAND] = False
                    m[i, A.MOVE_START:A.MOVE_START + A.NUM_DIRS] = False
                if self.stall_time > self.rules.max_stall_s * 2:    # hard anti-hoarding limit
                    m[i, A.STAND] = False
                continue
            m[i, A.STAND] = True
            m[i, A.MOVE_START:A.MOVE_START + A.NUM_DIRS] = True
            m[i, A.TO_ANCHOR] = True
            m[i, A.COVER] = True
            if self.dead:
                m[i, A.MARK] = not (self.sp_team == t)
                if self.sp_team == t:
                    m[i, A.SUPPORT] = m[i, A.RUN_BEHIND] = (i != gk)
                continue
            if v.possession != 1:
                m[i, A.PRESS] = True
                m[i, A.MARK] = True
            if v.carrier < 0:
                m[i, A.INTERCEPT] = True
            if v.possession == 1:
                m[i, A.SUPPORT] = True
                m[i, A.RUN_BEHIND] = True
            if v.opp_carrier >= 0 and self.tackle_cd[p] <= 0 and self.stun[p] <= 0:
                oc = TEAM_SLICES[1 - t].start + v.opp_carrier
                opp_gk_holding = (v.opp_carrier == gk) and bool(G.in_penalty_area(
                    *(self._team_pos(1 - t, self.pos[oc]))))
                if not opp_gk_holding and G.norm(self.pos[p] - self.pos[oc]) <= \
                        self.phys.tackle_range:
                    m[i, A.TACKLE] = True
            if i == gk:
                m[i, A.MARK] = m[i, A.SUPPORT] = m[i, A.RUN_BEHIND] = False
                ob = self.views[t].b
                near_goal = np.hypot(ob[0] + HL, ob[1]) < 24.0
                m[i, A.PRESS] = m[i, A.PRESS] and near_goal
                ip = v.intercept_pt[i]
                m[i, A.INTERCEPT] = m[i, A.INTERCEPT] and (ip[0] < -HL + 22.0)
        return m

    def _pass_mask(self, m, i, v, max_dist: float = 90.0):
        d = G.norm(v.P - v.P[i], axis=1)
        ok = v.passes.valid & (d <= max_dist)
        m[i, A.PASS_FEET_START:A.PASS_FEET_START + 11] = ok
        thr_ok = ok & (G.norm(v.passes.thr_target - v.P[i], axis=1) <= max_dist)
        m[i, A.PASS_THROUGH_START:A.PASS_THROUGH_START + 11] = thr_ok
        m[i, A.PASS_FEET_START + i] = False
        m[i, A.PASS_THROUGH_START + i] = False

    def _fallback_action(self, t: int, i: int) -> int:
        m = self.masks[t][i]
        for a in (A.TO_ANCHOR, A.STAND, A.CLEAR):
            if m[a]:
                return a
        return int(np.argmax(m))

    # =====================================================================================
    # kicks & tackles
    # =====================================================================================
    def _kick_noise(self, p: int, dist: float):
        v = self.views[team_of(p)]
        pr = v.carrier_pressure if v.carrier == p % 11 else 0.0
        ang_sigma = math.radians(1.8 + 5.0 * pr + 3.0 * dist / 60.0)
        spd = 1.0 + self.rng.normal(0, 0.035 + 0.05 * pr)
        return self.rng.normal(0, ang_sigma), spd, pr

    def _launch_ground(self, target: np.ndarray, v_arr: float, max_speed: float, p: int):
        d_vec = target - self.bpos
        d = float(G.norm(d_vec))
        v0 = self._ground_speed_for(d, v_arr)
        v0 = min(v0, max_speed)
        ang_noise, spd, _ = self._kick_noise(p, d)
        ang = math.atan2(d_vec[1], d_vec[0]) + ang_noise
        self.bvel = np.array([math.cos(ang), math.sin(ang)]) * v0 * spd
        self.bz, self.bvz = 0.0, 0.0

    def _launch_lofted(self, target: np.ndarray, p: int, flight: Optional[float] = None,
                       z0: float = 0.0):
        d_vec = target - self.bpos
        d = float(G.norm(d_vec))
        T_ = flight if flight is not None else float(np.clip(0.9 + d / 25.0, 1.1, 2.6))
        ang_noise, spd, _ = self._kick_noise(p, d)
        ang = math.atan2(d_vec[1], d_vec[0]) + ang_noise * 1.3
        # horizontal speed compensating for air damping so that the ball lands ~at the target
        k = self.phys.ball_air_damping
        vh = d * 0.97 * k / (1 - math.exp(-k * T_)) if k > 0 else d / T_
        self.bvel = np.array([math.cos(ang), math.sin(ang)]) * vh * spd
        g = self.phys.gravity
        self.bz = z0
        self.bvz = (0.5 * g * T_ * T_ - z0) / T_

    def _ground_speed_for(self, d: float, v_arr: float) -> float:
        """Initial speed so that a ground ball arrives at distance d with speed v_arr."""
        k, c = self.phys.ball_roll_damping, self.phys.ball_roll_decel
        lo, hi = v_arr, 45.0

        def dist_at_speed(v0):
            A_ = v0 + c / k
            B_ = v_arr + c / k
            t = math.log(A_ / B_) / k
            return (A_ - B_) / k - c / k * t

        for _ in range(30):
            mid = 0.5 * (lo + hi)
            if dist_at_speed(mid) < d:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi)

    def _offside_set(self, team: int) -> frozenset:
        if not self.rules.offside:
            return frozenset()
        v_opp_pos = self._team_pos(team, self.pos[TEAM_SLICES[1 - team]])
        second_last = np.sort(v_opp_pos[:, 0])[::-1][1]
        b = self._team_pos(team, self.bpos)
        line = max(second_last, b[0], 0.0)
        own = self._team_pos(team, self.pos[TEAM_SLICES[team]])
        base = TEAM_SLICES[team].start
        return frozenset(base + i for i in range(11) if own[i, 0] > line + 0.1)

    def _execute_kick(self, p: int, a: int):
        t = team_of(p)
        v = self.views[t]
        i = p % 11
        restart = self.sp_kind if self.dead else T.SP_NONE
        start = self.bpos.copy()
        kind, target = "", -1
        xg = 0.0
        if A.is_pass(a):
            j, ptype = A.pass_target(a)
            target = TEAM_SLICES[t].start + j
            opts = v.passes
            if ptype == 0:
                aim_team, lofted, kind = opts.feet_target[j], opts.loft_feet[j] > 0.5, "pass"
            else:
                aim_team, lofted, kind = opts.thr_target[j], opts.loft_thr[j] > 0.5, "through"
            aim = self._world(t, aim_team)
            if restart == T.SP_THROW_IN:
                d = float(G.norm(aim - self.bpos))
                self._launch_lofted(aim, p, flight=float(np.clip(0.45 + d / 22.0, 0.6, 1.5)),
                                    z0=1.8)
            elif restart == T.SP_CORNER or lofted:
                self._launch_lofted(aim, p)
            else:
                self._launch_ground(aim, 7.0 if ptype == 0 else 4.5, self.phys.max_pass_speed, p)
            self.stats.add(t, "passes")
            if restart == T.SP_NONE or restart in (T.SP_FREE_KICK, T.SP_INDIRECT):
                offside = self._offside_set(t)
            else:
                offside = frozenset()
        elif a == A.SHOOT:
            kind = "shot"
            xg = v.shot_xg if restart != T.SP_PENALTY else 0.76
            self._execute_shot(p, t, restart == T.SP_PENALTY)
            offside = frozenset()
            self.stats.add(t, "shots")
            self.stats.add(t, "xg", xg)
            if xg > 0.1:
                self.stats.add(t, "chances")
            self.shot_pending = {"shooter": p, "team": t, "xg": xg}
            self.events.append(("shot", p, xg))
        else:   # CLEAR
            kind = "clear"
            bt = self._team_pos(t, self.bpos)
            side = 1.0 if bt[1] >= 0 else -1.0
            aim_t = np.array([min(bt[0] + 42.0, HL - 12.0), side * 22.0])
            self._launch_lofted(self._world(t, aim_t), p, flight=2.4)
            offside = self._offside_set(t)
            self.stats.add(t, "clearances")
        self.possessor = -1
        self.kick_cd[p] = self.phys.kick_cooldown
        self.kick = KickInfo(kicker=p, team=t, kind=kind, target=target, start=start,
                             time=self.time, offside_set=offside, xg=xg, restart=restart,
                             frontier=self.frontier[t])
        self.flight_team = t if kind in PASS_KINDS else -1
        self.last_touch, self.last_touch_team = p, t
        if self.dead:
            self.dead = False
            self.double_touch = p
            self.sp_kind = T.SP_NONE
        self.events.append(("kick", p, kind, target))

    def _execute_shot(self, p: int, t: int, penalty: bool):
        gk = self.gk_idx[1 - t]
        gk_y = self._team_pos(t, self.pos[gk])[1]
        cands = np.array([-3.1, -2.0, 2.0, 3.1])
        if penalty:
            aim_y = float(self.rng.choice(cands))
        else:
            score = np.abs(cands - gk_y) + self.rng.normal(0, 0.8, len(cands))
            aim_y = float(cands[int(np.argmax(score))])
        aim = self._world(t, np.array([HL + 0.5, aim_y]))
        d = float(G.norm(aim - self.bpos))
        ang_noise, spd, pr = self._kick_noise(p, d)
        if penalty:
            ang_noise *= 0.5
        d_vec = aim - self.bpos
        ang = math.atan2(d_vec[1], d_vec[0]) + ang_noise * 0.9
        speed = min(self.phys.max_shot_speed, 21.0 + d * 0.25) * spd
        self.bvel = np.array([math.cos(ang), math.sin(ang)]) * speed
        self.bz = 0.1
        self.bvz = float(np.clip(self.rng.normal(1.5 + d * 0.06, 1.0 + pr), 0.0, 7.0))

    def _execute_tackle(self, p: int):
        if self.possessor < 0 or team_of(self.possessor) == team_of(p) or self.dead:
            return
        if self.tackle_cd[p] > 0 or self.stun[p] > 0:
            return
        c = self.possessor
        d_vec = self.pos[p] - self.pos[c]
        dist = float(G.norm(d_vec))
        if dist > self.phys.tackle_range:
            return
        t = team_of(p)
        self.tackle_cd[p] = 1.0
        self.stats.add(t, "tackles")
        facing = self.facing[c]
        cosang = float(np.dot(facing, d_vec) / max(dist, 1e-6))
        front, behind = cosang > 0.3, cosang < -0.3
        cspeed = float(G.norm(self.vel[c]))
        p_succ = 0.48 + 0.15 * front - 0.18 * behind - 0.08 * cspeed / 7.0 + 0.12 * (1 - dist / 2)
        p_foul = self.rules.base_foul_prob + self.rules.behind_foul_prob * behind \
            + 0.05 * float(G.norm(self.vel[p])) / 8.0
        r = self.rng.random()
        if self.rules.fouls and r < p_foul:
            self._foul(p, c)
            return
        if self.rng.random() < p_succ:
            self.stats.add(t, "tackles_won")
            self.events.append(("tackle_won", p, c))
            if self.rng.random() < 0.5:
                self._gain_possession(p, via="tackle")
            else:
                self.possessor = -1
                fwd = self._world(t, np.array([1.0, 0.0]))
                dirv = fwd * 0.6 + self.rng.normal(0, 0.7, 2)
                dirv /= max(G.norm(dirv), 1e-6)
                self.bvel = dirv * self.rng.uniform(4.0, 7.0)
                self.last_touch, self.last_touch_team = p, t
                self.kick_cd[c] = 0.4
                self.flight_team = -1
                self.kick = KickInfo(kicker=p, team=t, kind="tackle", time=self.time)
        else:
            self.stun[p] = self.phys.tackle_stun
            self.events.append(("tackle_failed", p, c))

    def _foul(self, offender: int, victim: int):
        t_off = team_of(offender)
        t_vic = team_of(victim)
        self.stats.add(t_off, "fouls")
        spot = self.bpos.copy()
        in_box = bool(G.in_penalty_area(*self._team_pos(t_off, spot)))
        if in_box:
            pspot = self._world(t_vic, np.array([HL - self.cfg.pitch.penalty_spot_dist, 0.0]))
            self.events.append(("foul", offender, victim, True))
            self._begin_setpiece(T.SP_PENALTY, t_vic, pspot, victim)
        else:
            self.events.append(("foul", offender, victim, False))
            spot[0] = np.clip(spot[0], -HL + 1, HL - 1)
            spot[1] = np.clip(spot[1], -HW + 1, HW - 1)
            self._begin_setpiece(T.SP_FREE_KICK, t_vic, spot, victim)

    # =====================================================================================
    # possession
    # =====================================================================================
    def _gain_possession(self, p: int, via: str = "control"):
        t = team_of(p)
        k = self.kick
        if self._offside_offence(p):
            return
        prev_team = self.poss_team
        self.possessor = p
        self.bz = self.bvz = 0.0
        self.flight_team = -1
        self.hold_time = 0.0
        self.stall_time = 0.0
        self.loose_time = 0.0
        self.last_touch, self.last_touch_team = p, t
        if self.double_touch >= 0 and p != self.double_touch:
            self.double_touch = -1
        self.shot_pending = None
        if prev_team != t:
            if prev_team >= 0:
                loser = self.last_controller if self.last_controller >= 0 and \
                    team_of(self.last_controller) == prev_team else -1
                self.stats.add(prev_team, "turnovers")
                lost_at = self._team_pos(prev_team, self.bpos)
                if lost_at[0] < -HL / 3:
                    self.stats.add(prev_team, "defensive_errors")
                kind = "interception" if (k.kind in PASS_KINDS and k.team == prev_team) else via
                if kind == "interception":
                    self.stats.add(t, "interceptions")
                self.stats.add(t, "recoveries")
                self.events.append(("turnover", loser, p, kind))
                dur = self.time - self.poss_start_time
                self.stats.add(prev_team, "possession_duration_sum", dur)
                self.stats.add(prev_team, "possessions")
            self.poss_start_time = self.time
            self.poss_team = t
            self.frontier[t] = float(self._team_pos(t, self.bpos)[0])
            self.nonprog_passes[t] = 0
        elif k.kind in PASS_KINDS and k.team == t and k.kicker != p:
            start_t = self._team_pos(t, k.start)
            end_t = self._team_pos(t, self.bpos)
            progressive = end_t[0] > self.frontier[t] + 5.0 and end_t[0] - start_t[0] > 8.0
            self.stats.add(t, "passes_completed")
            if progressive:
                self.stats.add(t, "progressive_passes")
                self.nonprog_passes[t] = 0
            else:
                self.nonprog_passes[t] += 1
            if start_t[0] < HL / 3 <= end_t[0]:
                self.stats.add(t, "final_third_entries")
            if not G.in_penalty_area(*start_t, attacking=True) and \
                    G.in_penalty_area(*end_t, attacking=True):
                self.stats.add(t, "box_entries")
            self.events.append(("pass_complete", k.kicker, p, bool(progressive),
                                self.nonprog_passes[t]))
            self.last_pass = (k.kicker, p, self.time)
        self.last_controller = p
        self.kick = KickInfo()
        bt = self._team_pos(t, self.bpos)[0]
        self.frontier[t] = max(self.frontier[t], float(bt))

    def _offside_offence(self, p: int) -> bool:
        """Playing/touching a team-mate's pass from an offside position -> indirect FK."""
        t = team_of(p)
        k = self.kick
        if k.kind in PASS_KINDS + ("clear",) and k.team == t and p in k.offside_set and                 p != k.kicker:
            self.stats.add(t, "offsides")
            self.events.append(("offside", p))
            spot = self.pos[p].copy()
            spot[0] = np.clip(spot[0], -HL + 1, HL - 1)
            spot[1] = np.clip(spot[1], -HW + 1, HW - 1)
            self._begin_setpiece(T.SP_INDIRECT, 1 - t, spot)
            return True
        return False

    def _update_loose_timer(self, dt: float):
        if self.possessor < 0 and not self.dead:
            self.loose_time += dt
            if self.loose_time > 15.0:     # nobody claims the ball -> dropped ball restart
                t = self.poss_team if self.poss_team >= 0 else int(self.rng.integers(2))
                spot = self.bpos.copy()
                spot[0] = np.clip(spot[0], -HL + 12, HL - 12)
                spot[1] = np.clip(spot[1], -HW + 2, HW - 2)
                self.stats.add(t, "deadlocks")
                self._begin_setpiece(T.SP_INDIRECT, t, spot)
        else:
            self.loose_time = 0.0
            if self.possessor >= 0 and not self.dead:
                self.hold_time += dt
                self.stall_time += dt
                t = team_of(self.possessor)
                bx = float(self._team_pos(t, self.bpos)[0])
                if bx > self.frontier[t] + 3.0:
                    self.frontier[t] = bx
                    self.stall_time = 0.0
                if self.possessor == self.gk_idx[team_of(self.possessor)] and \
                        self.hold_time > self.rules.gk_max_hold_s + 2.0:
                    t = team_of(self.possessor)          # GK held too long: indirect FK
                    self._begin_setpiece(T.SP_INDIRECT, 1 - t, self.bpos.copy())

    # =====================================================================================
    # movement planning & physics
    # =====================================================================================
    def _plan_movement(self, actions):
        """Turn decisions into per-player targets (world frame) and speeds."""
        self.mv_mode = np.zeros(22, dtype=np.int64)     # 0 stop, 1 direction, 2 target
        self.mv_dir = np.zeros((22, 2))
        self.mv_track_ball = np.zeros(22, bool)
        tgt_team = np.zeros((22, 2))
        sprint_dist = np.full(22, np.inf)               # sprint when farther than this
        vmax = self.vmax()
        c = self.phys
        move_speed = np.zeros(22)
        for p in range(22):
            t, i = (0, p) if p < 11 else (1, p - 11)
            v = self.views[t]
            a = int(actions[p])
            if A.MOVE_START <= a < A.MOVE_START + A.NUM_DIRS:
                self.mv_mode[p] = 1
                self.mv_dir[p] = A.DIRECTIONS[a - A.MOVE_START] * self.attack_dir[t]
                move_speed[p] = c.dribble_speed if self.possessor == p else 0.92 * vmax[p]
                continue
            if a == A.TO_ANCHOR:
                tgt_team[p], sprint_dist[p] = v.anchors[i], 8.0
            elif a == A.PRESS or a == A.TACKLE:
                tgt_team[p], sprint_dist[p] = v.press_pt[i], 0.0
                self.mv_track_ball[p] = v.opp_carrier < 0
            elif a == A.MARK:
                tgt_team[p], sprint_dist[p] = v.mark_pt[i], 5.0
            elif a == A.COVER:
                tgt_team[p], sprint_dist[p] = v.cover_pt[i], 6.0
            elif a == A.INTERCEPT:
                tgt_team[p], sprint_dist[p] = v.intercept_pt[i], 0.0
                self.mv_track_ball[p] = True
            elif a == A.SUPPORT:
                tgt_team[p], sprint_dist[p] = v.support_pt[i], 8.0
            elif a == A.RUN_BEHIND:
                tgt_team[p], sprint_dist[p] = v.run_pt[i], 0.0
            else:
                continue
            self.mv_mode[p] = 2
        for t in range(2):
            sup = [p - 11 * t for p in range(11 * t, 11 * t + 11) if int(actions[p]) == A.SUPPORT]
            if sup:
                T.ensure_support(self.views[t], sup)
                for i in sup:
                    tgt_team[11 * t + i] = self.views[t].support_pt[i]
        # low-level receiving skill: the intended receiver of a pass in flight attacks the ball
        k = self.kick
        if k.kind in PASS_KINDS and k.target >= 0 and self.possessor < 0 and not self.dead                 and self.time - k.time < 4.0:
            j = k.target
            tj = team_of(j)
            tgt_team[j] = self.views[tj].intercept_pt[j % 11]
            sprint_dist[j] = 2.0
            self.mv_mode[j] = 2
            self.mv_track_ball[j] = False      # arrive at the interception point, don't charge
        ad = np.repeat(self.attack_dir, 11)[:, None]
        self.mv_target = np.where((self.mv_mode == 2)[:, None], tgt_team * ad, self.pos)
        dist = G.norm(self.mv_target - self.pos)
        target_speed = np.where(dist > sprint_dist, vmax, np.minimum(c.jog_speed, vmax))
        self.mv_speed = np.where(self.mv_mode == 1, move_speed, target_speed)
        if self.dead:       # taker stays at the ball
            self.mv_mode[self.sp_taker] = 0

    def _substep(self, dt: float, actions):
        c = self.phys
        vmax = self.vmax()
        # ---- desired velocities
        desired = np.zeros((22, 2))
        m1 = self.mv_mode == 1
        desired[m1] = self.mv_dir[m1] * self.mv_speed[m1, None]
        m2 = self.mv_mode == 2
        if m2.any():
            tgt = self.mv_target.copy()
            track = self.mv_track_ball & m2
            if track.any():
                near = G.norm(self.pos[track] - self.bpos, axis=1) < 4.0
                idx = np.where(track)[0][near]
                tgt[idx] = self.bpos
            d = tgt[m2] - self.pos[m2]
            dist = G.norm(d, axis=1)
            spd = np.minimum(self.mv_speed[m2], dist * 1.6)
            spd = np.where(dist < 0.25, 0.0, spd)
            desired[m2] = d / np.maximum(dist[:, None], 1e-6) * spd[:, None]
            # local avoidance so target-seeking players steer around others instead of
            # ploughing through them (explicit MOVE commands are left untouched)
            diff = self.pos[:, None, :] - self.pos[None, :, :]
            d2 = np.sum(diff * diff, axis=-1)
            near = (d2 < 4.0) & (d2 > 1e-6)
            if near.any():
                rep = np.sum(np.where(near[..., None], diff / np.maximum(d2, 0.25)[..., None],
                                      0.0), axis=1)
                ball_chasers = self.mv_track_ball
                steer = m2 & ~ball_chasers
                desired[steer] += 2.5 * rep[steer]
        if self.possessor >= 0:
            p = self.possessor
            cap = c.dribble_speed * (0.8 + 0.2 * self.stamina[p])
            opp = TEAM_SLICES[1 - team_of(p)]
            if np.min(G.norm(self.pos[opp] - self.pos[p], axis=1)) < 2.0:
                cap *= 0.85
            n = G.norm(desired[p])
            if n > cap:
                desired[p] *= cap / n
        # ---- acceleration-limited velocity update
        dv = desired - self.vel
        speeding_up = np.sum(desired * desired, axis=1) >= np.sum(self.vel * self.vel, axis=1)
        lim = np.where(speeding_up, c.accel, c.decel) * dt
        n = G.norm(dv, axis=1)
        scale = np.minimum(1.0, lim / np.maximum(n, 1e-9))
        self.vel += dv * scale[:, None]
        sp = G.norm(self.vel, axis=1)
        over = sp > vmax
        self.vel[over] *= (vmax[over] / sp[over])[:, None]
        self.pos += self.vel * dt
        moving = sp > 0.3
        self.facing[moving] = self.vel[moving] / sp[moving, None]

        # ---- stamina
        run_frac = np.clip((sp - c.jog_speed) / (c.sprint_speed - c.jog_speed), 0.0, 1.0)
        self.stamina = np.clip(self.stamina - c.stamina_sprint_drain * run_frac * dt
                               + c.stamina_recover * (run_frac == 0) * dt, 0.2, 1.0)
        self.stun = np.maximum(self.stun - dt, 0.0)
        self.kick_cd = np.maximum(self.kick_cd - dt, 0.0)
        self.tackle_cd = np.maximum(self.tackle_cd - dt, 0.0)

        # ---- player-player separation (vectorised)
        self._separate()
        self._clamp_players()
        if self.dead:
            self._enforce_setpiece()

        # ---- ball
        if self.dead:
            self.bpos = self.sp_spot.copy()
            self.bvel[:] = 0.0
            return
        if self.possessor >= 0:
            p = self.possessor
            self.bpos = self.pos[p] + self.facing[p] * c.dribble_offset
            self.bvel = self.vel[p].copy()
            self.bz = self.bvz = 0.0
            if p == self.gk_idx[team_of(p)]:
                self.bpos = self.pos[p] + self.facing[p] * 0.3
            self._check_out_of_play(self.bpos - self.bvel * dt, self.bpos, 0.0, 0.0)
            return
        self._ball_flight(dt)

    def _separate(self):
        r2 = 2 * self.phys.player_radius
        diff = self.pos[:, None, :] - self.pos[None, :, :]
        dist = G.norm(diff, axis=-1)
        np.fill_diagonal(dist, np.inf)
        over = dist < r2
        if not over.any():
            self._contacts = set()
            return
        ii, jj = np.where(np.triu(over, 1))
        prev_pairs = self._contacts
        self._contacts = set(zip(ii.tolist(), jj.tolist()))
        for i, j in zip(ii, jj):
            d = max(dist[i, j], 1e-3)
            n = diff[i, j] / d
            push = (r2 - d) * 0.5
            self.pos[i] += n * push
            self.pos[j] -= n * push
            if team_of(i) != team_of(j) and (i, j) not in prev_pairs:
                rel = self.vel[i] - self.vel[j]
                approach = -float(np.dot(rel, n))
                if approach > 3.0:
                    # attribute the collision to whoever is running into the other
                    vi = -float(np.dot(self.vel[i], n))
                    vj = float(np.dot(self.vel[j], n))
                    culprit = i if vi >= vj else j
                    self.events.append(("collision", int(culprit)))
                    self.stats.add(team_of(culprit), "collisions")

    def _clamp_players(self):
        ro = self.cfg.pitch.runoff
        self.pos[:, 0] = np.clip(self.pos[:, 0], -HL - ro, HL + ro)
        self.pos[:, 1] = np.clip(self.pos[:, 1], -HW - ro, HW + ro)
        # goalkeepers stay near their own penalty area
        for t in range(2):
            g = self.gk_idx[t]
            ad = self.attack_dir[t]
            x = min(max(self.pos[g, 0] * ad, -HL - 0.5), -HL + 22.5)
            y = min(max(self.pos[g, 1] * ad, -22.0), 22.0)
            self.pos[g, 0], self.pos[g, 1] = x * ad, y * ad

    def _enforce_setpiece(self):
        t = self.sp_team
        taker = self.sp_taker
        self._place_taker()
        spot = self.sp_spot
        opp = TEAM_SLICES[1 - t]
        radius = 2.0 if self.sp_kind == T.SP_THROW_IN else self.rules.free_kick_distance
        idx = np.arange(opp.start, opp.stop)
        d = self.pos[idx] - spot
        n = G.norm(d, axis=1)
        close = n < radius
        if close.any():
            dirs = d[close] / np.maximum(n[close, None], 1e-6)
            dirs[n[close] < 1e-3] = self._world(1 - t, np.array([-1.0, 0.0]))
            self.pos[idx[close]] = spot + dirs * radius
        if self.sp_kind == T.SP_KICKOFF:
            for tt in range(2):
                sl = TEAM_SLICES[tt]
                pt = self._team_pos(tt, self.pos[sl])
                pt[:, 0] = np.minimum(pt[:, 0], -0.3)
                if tt == t:
                    pt[taker - sl.start] = self._team_pos(tt, self.pos[taker])
                self.pos[sl] = self._world(tt, pt)
        elif self.sp_kind == T.SP_GOAL_KICK:
            pt = self._team_pos(t, self.pos[opp])
            in_box = G.in_penalty_area(pt[:, 0], pt[:, 1])
            pt[in_box, 0] = -HL + self.cfg.pitch.penalty_area_depth + 0.5
            self.pos[opp] = self._world(t, pt)
        elif self.sp_kind == T.SP_PENALTY:
            gk_def = self.gk_idx[1 - t]
            for p in range(22):
                if p == taker or p == gk_def:
                    continue
                pt = self._team_pos(t, self.pos[p])
                if G.in_penalty_area(pt[0], pt[1], attacking=True) or \
                        G.norm(pt - self._team_pos(t, spot)) < 9.15:
                    pt[0] = HL - self.cfg.pitch.penalty_area_depth - 1.0 - (p % 3)
                    self.pos[p] = self._world(t, pt)
            g = self._team_pos(t, self.pos[gk_def])
            g[0] = HL - 0.2
            g[1] = np.clip(g[1], -G.GOAL_HALF, G.GOAL_HALF)
            self.pos[gk_def] = self._world(t, g)

    def _ball_flight(self, dt: float):
        c = self.phys
        old = self.bpos.copy()
        old_z = self.bz
        if self.bz > 0.0 or self.bvz > 0.0:
            self.bvz -= c.gravity * dt
            self.bz += self.bvz * dt
            self.bvel *= (1.0 - c.ball_air_damping * dt)
            if self.bz <= 0.0:
                self.bz = 0.0
                if self.bvz < -2.0:
                    self.bvz = -self.bvz * c.bounce_restitution
                    self.bvel *= 0.62          # grass absorbs horizontal speed on landing
                else:
                    self.bvz = 0.0
        else:
            s = float(G.norm(self.bvel))
            if s > 0:
                ns = max(0.0, s - (c.ball_roll_damping * s + c.ball_roll_decel) * dt)
                self.bvel *= ns / s
        self.bpos = self.bpos + self.bvel * dt
        if not np.all(np.isfinite(self.bpos)):
            self.bpos = np.zeros(2)
            self.bvel[:] = 0.0
        # contacts along the segment
        if self._ball_contacts(old, self.bpos, old_z, self.bz):
            return
        self._check_out_of_play(old, self.bpos, old_z, self.bz)

    def _ball_contacts(self, a, b, za, zb) -> bool:
        c = self.phys
        eligible = (self.kick_cd <= 0)
        if self.double_touch >= 0:
            eligible[self.double_touch] = False
        if not eligible.any():
            return False
        dist, tpar = G.segment_point_distance(a, b, self.pos)
        z_at = za + (zb - za) * tpar
        reach = np.full(22, c.control_radius)
        max_h = np.full(22, c.header_height)
        gk_hands = np.zeros(22, bool)
        since_kick = self.time - self.kick.time
        for t in range(2):
            g = self.gk_idx[t]
            pt = self._team_pos(t, self.pos[g])
            if G.in_penalty_area(pt[0], pt[1]):
                gk_hands[g] = True
                dive = 0.0
                if self.kick.kind == "shot" and self.kick.team != t:
                    dive = 1.9 * float(np.clip((since_kick - 0.1) / 0.5, 0.0, 1.0))
                reach[g] = c.gk_catch_radius + dive
                max_h[g] = 2.7
        cand = eligible & (dist <= reach) & (z_at <= max_h)
        if not cand.any():
            return False
        idx = np.where(cand)[0]
        order = idx[np.argsort(tpar[idx] + self.rng.uniform(0, 0.05, len(idx)))]
        for p in order:
            p = int(p)
            contact = a + (b - a) * tpar[p]
            if self._resolve_contact(p, contact, float(z_at[p]), float(dist[p]),
                                     float(reach[p]), bool(gk_hands[p])):
                return True
        return False

    def _resolve_contact(self, p, contact, z, dist, reach, gk_hands) -> bool:
        """Returns True if the ball was touched (its state changed)."""
        c = self.phys
        t = team_of(p)
        speed = float(G.norm(self.bvel))
        rel = float(G.norm(self.bvel - 0.5 * self.vel[p]))     # players cushion the ball
        shot = self.kick.kind == "shot" and self.kick.team != t
        if gk_hands:
            if shot:
                save_p = float(np.clip(1.0 - 0.5 * dist / reach - max(0.0, speed - 22.0) / 25.0,
                                       0.1, 0.97))
                if self.rng.random() >= save_p:
                    self.kick_cd[p] = 0.5        # beaten
                    return False
                self.stats.add(t, "saves")
                self.events.append(("save", p, self.kick.xg))
                if self.shot_pending is not None:
                    self.stats.add(self.shot_pending["team"], "shots_on_target")
                    self.shot_pending = None
                if speed < 22.0 and dist < 1.4 and self.rng.random() < 0.7:
                    self.bpos = contact
                    self._gain_possession(p, via="save")
                else:
                    self._parry(p, contact)
                return True
            if self.rng.random() < float(np.clip(1.2 - rel / 30.0, 0.5, 0.99)):
                self.bpos = contact
                self._gain_possession(p, via="catch")
            else:
                self._parry(p, contact)
            return True
        if self._offside_offence(p):
            return True
        self.bpos = contact
        if z <= c.control_height or (z <= 1.8 and speed < 9.0):   # foot / chest control
            p_ctrl = float(np.clip(1.25 - rel / 20.0, 0.12, 1.0))
            if self.kick.target == p:
                p_ctrl = min(1.0, p_ctrl + 0.15)
            if self.stun[p] > 0:
                p_ctrl -= 0.2
            if self.rng.random() < p_ctrl:
                if shot and self.shot_pending is not None:
                    self.stats.add(t, "blocks")
                    self.events.append(("block", p))
                    self.shot_pending = None
                self._gain_possession(p)
                return True
            # deflection
            ang = self.rng.uniform(-1.0, 1.0)
            ca, sa = math.cos(ang), math.sin(ang)
            v = self.bvel * self.rng.uniform(0.25, 0.6)
            self.bvel = np.array([ca * v[0] - sa * v[1], sa * v[0] + ca * v[1]])
            self.kick_cd[p] = 0.25
            if shot and self.shot_pending is not None:
                self.stats.add(t, "blocks")
                self.events.append(("block", p))
                self.shot_pending = None
        else:
            # header: redirect toward the attacking direction
            fwd = self._world(t, np.array([1.0, 0.0]))
            cur = self.bvel / max(speed, 1e-6)
            d = 0.6 * fwd + 0.4 * cur + self.rng.normal(0, 0.3, 2)
            d /= max(G.norm(d), 1e-6)
            self.bvel = d * max(speed * 0.55, 7.0)
            self.bvz = 1.0
            self.kick_cd[p] = 0.3
            if shot and self.shot_pending is not None:
                self.stats.add(t, "blocks")
                self.events.append(("block", p))
                self.shot_pending = None
        self.last_touch, self.last_touch_team = p, t
        if self.double_touch >= 0 and p != self.double_touch:
            self.double_touch = -1
        # any touch by a player breaks the "pass in flight" state
        if self.kick.kind in PASS_KINDS and self.kick.team != t:
            self.flight_team = -1
        self.kick = KickInfo(kicker=p, team=t, kind="touch", time=self.time,
                             offside_set=self.kick.offside_set if self.kick.team == t
                             else frozenset())
        return True

    def _parry(self, p, contact):
        t = team_of(p)
        out = self._world(t, np.array([1.0, 0.0]))
        lat = self.rng.choice([-1.0, 1.0]) * self.rng.uniform(0.6, 1.4)
        d = out + self._world(t, np.array([0.0, lat]))
        d /= G.norm(d)
        self.bpos = contact
        self.bvel = d * max(4.0, float(G.norm(self.bvel)) * 0.35)
        self.bvz = 1.5
        self.bz = max(self.bz, 0.3)
        self.kick_cd[p] = 0.5
        self.last_touch, self.last_touch_team = p, t
        self.kick = KickInfo(kicker=p, team=t, kind="parry", time=self.time)
        self.flight_team = -1

    # =====================================================================================
    # out of play & goals
    # =====================================================================================
    def _check_out_of_play(self, a, b, za, zb):
        x, y = b
        if abs(x) > HL:
            sgn = 1.0 if x > 0 else -1.0
            frac = (sgn * HL - a[0]) / (b[0] - a[0]) if abs(b[0] - a[0]) > 1e-9 else 1.0
            frac = float(np.clip(frac, 0.0, 1.0))
            yc = a[1] + (b[1] - a[1]) * frac
            zc = za + (zb - za) * frac
            attacker = 0 if self.attack_dir[0] == sgn else 1
            defender = 1 - attacker
            if abs(yc) < G.GOAL_HALF and zc < self.cfg.pitch.goal_height:
                self._goal(attacker)
                return
            if self.shot_pending is not None:
                self.shot_pending = None
            lk = self.kick.kind
            if self.last_touch_team == defender:
                corner = np.array([sgn * HL, (1.0 if yc > 0 else -1.0) * HW])
                self.events.append(("out", self.last_touch, "corner", lk))
                self._begin_setpiece(T.SP_CORNER, attacker, corner)
            else:
                gk_spot = np.array([sgn * (HL - self.cfg.pitch.goal_area_depth),
                                    (1.0 if yc > 0 else -1.0) * 4.0])
                self.events.append(("out", self.last_touch, "goal_kick", lk))
                self._begin_setpiece(T.SP_GOAL_KICK, defender, gk_spot)
            return
        if abs(y) > HW:
            team = 1 - self.last_touch_team if self.last_touch_team >= 0 else 0
            spot = np.array([np.clip(x, -HL + 0.5, HL - 0.5), np.sign(y) * HW])
            if self.shot_pending is not None:
                self.shot_pending = None
            self.events.append(("out", self.last_touch, "throw_in", self.kick.kind))
            self._begin_setpiece(T.SP_THROW_IN, team, spot)

    def _goal(self, team: int):
        self.score[team] += 1
        self.stats.add(team, "goals")
        scorer = self.last_touch if self.last_touch >= 0 and team_of(self.last_touch) == team \
            else -1
        if self.shot_pending is not None and self.shot_pending["team"] == team:
            self.stats.add(team, "shots_on_target")
        self.shot_pending = None
        assister = -1
        lp = self.last_pass
        if scorer >= 0 and lp is not None and lp[1] == scorer and self.time - lp[2] < 15.0:
            assister = lp[0]
        self.events.append(("goal", team, scorer, assister))
        self._kickoff(1 - team)

    def _end_half(self):
        if self.half == 0:
            self.half = 1
            self.t_half = 0.0
            self.attack_dir = -self.attack_dir
            self.stamina = np.minimum(1.0, self.stamina + 0.3)
            self.events.append(("half_time",))
            self._kickoff(1 - self.first_kickoff)
        else:
            self.done = True
            self.events.append(("full_time",))
            self.match_count += 1

    # =====================================================================================
    # stats
    # =====================================================================================
    def _track_stats(self, dt):
        for t in range(2):
            v = self.views[t]
            s = self.stats
            s.add(t, "compactness_sum", float(v.shape[6] * 20.0))
            s.add(t, "width_sum", float(v.shape[2] * G.PITCH.width))
            s.add(t, "length_sum", float(v.shape[3] * G.PITCH.length))
            s.add(t, "shape_samples")
            if v.opp_carrier >= 0 and not self.dead:
                if np.min(G.norm(v.P - v.O[v.opp_carrier], axis=1)) < 2.0:
                    s.add(t, "pressing_events", dt)
            if v.phase == T.COUNTER_ATTACK and self._prev_phase[t] != T.COUNTER_ATTACK:
                s.add(t, "counter_attacks")
            self._prev_phase[t] = v.phase

    # =====================================================================================
    # scripted AI & human hooks
    # =====================================================================================
    def scripted_actions(self, t: int) -> np.ndarray:
        from .scripted import scripted_team_actions
        return scripted_team_actions(self, t, self.scripted_skill[t])

    def teacher(self, t: int) -> np.ndarray:
        from .scripted import scripted_team_actions
        return scripted_team_actions(self, t, 1.0, deterministic=True)

    def _scripted_coach(self, t: int) -> int:
        diff = self.score[t] - self.score[1 - t]
        late = self.half == 1 and self.t_half > 0.6 * self.rules.half_duration_s
        if late and diff > 0:
            return T.BLOCK_LOW * 2 + T.STYLE_DIRECT
        if late and diff < 0:
            return T.BLOCK_HIGH * 2 + T.STYLE_DIRECT
        return T.BLOCK_MID * 2 + T.STYLE_POSSESSION

    def _human_action(self) -> int:
        cmd = self.human_command or {}
        p = self.human_player
        t, i = team_of(p), p % 11
        m = self.masks[t][i]
        if cmd.get("shoot") and m[A.SHOOT]:
            return A.SHOOT
        if cmd.get("pass"):
            ev = self.views[t].passes.best_ev()
            cand = [j for j in np.argsort(-ev) if m[A.PASS_FEET_START + j]]
            if cand:
                return A.PASS_FEET_START + int(cand[0])
        if cmd.get("tackle") and m[A.TACKLE]:
            return A.TACKLE
        d = cmd.get("dir")
        if d is None:
            return A.STAND
        d_team = np.array(d, dtype=float) * self.attack_dir[t]
        ang = math.atan2(d_team[1], d_team[0])
        k = int(round(ang / (2 * math.pi / A.NUM_DIRS))) % A.NUM_DIRS
        return A.MOVE_START + k

    # convenience for tests / rendering
    def phase_names(self):
        return [T.PHASE_NAMES[self.tactics[t].phase] for t in range(2)]
