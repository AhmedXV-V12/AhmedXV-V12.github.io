"""Football statistics tracked per team per match and aggregated for logging/evaluation."""
from __future__ import annotations

from typing import Dict, List

import numpy as np

STAT_KEYS = [
    "goals", "shots", "shots_on_target", "xg", "passes", "passes_completed",
    "progressive_passes", "turnovers", "interceptions", "tackles", "tackles_won",
    "recoveries", "possession_time", "final_third_entries", "box_entries", "chances",
    "fouls", "offsides", "corners", "throw_ins", "goal_kicks", "free_kicks", "penalties",
    "saves", "blocks", "pressing_events", "defensive_errors", "collisions", "clearances",
    "compactness_sum", "width_sum", "length_sum", "shape_samples", "deadlocks",
    "counter_attacks", "possessions", "possession_duration_sum",
]


class MatchStats:
    def __init__(self):
        self.t = [dict.fromkeys(STAT_KEYS, 0.0) for _ in range(2)]

    def add(self, team: int, key: str, value: float = 1.0):
        self.t[team][key] += value

    def summary(self) -> Dict[str, float]:
        """Flat per-match summary used for logging (team-symmetric where sensible)."""
        a, b = self.t
        total_poss = a["possession_time"] + b["possession_time"] + 1e-9
        out: Dict[str, float] = {}
        for i, s in enumerate(self.t):
            p = f"t{i}_"
            out[p + "goals"] = s["goals"]
            out[p + "shots"] = s["shots"]
            out[p + "shots_on_target"] = s["shots_on_target"]
            out[p + "xg"] = s["xg"]
            out[p + "possession"] = s["possession_time"] / total_poss
            out[p + "pass_acc"] = s["passes_completed"] / max(1.0, s["passes"])
            for k in ("passes", "progressive_passes", "turnovers", "interceptions", "tackles_won",
                      "recoveries", "final_third_entries", "box_entries", "chances", "fouls",
                      "offsides", "saves", "pressing_events", "defensive_errors", "corners",
                      "collisions", "counter_attacks", "clearances", "blocks", "deadlocks"):
                out[p + k] = s[k]
            n = max(1.0, s["shape_samples"])
            out[p + "compactness"] = s["compactness_sum"] / n
            out[p + "width"] = s["width_sum"] / n
            out[p + "length"] = s["length_sum"] / n
            out[p + "avg_possession_s"] = s["possession_duration_sum"] / max(1.0, s["possessions"])
        return out


def aggregate(summaries: List[Dict[str, float]], learner_sides: List[int] = None) -> Dict[str, float]:
    """Average a list of match summaries. If learner_sides is given, report from the learner's
    perspective (keys prefixed 'L_' for learner and 'O_' for opponent)."""
    if not summaries:
        return {}
    if learner_sides is None:
        keys = summaries[0].keys()
        return {k: float(np.mean([s[k] for s in summaries])) for k in keys}
    out: Dict[str, List[float]] = {}
    for s, side in zip(summaries, learner_sides):
        for k, v in s.items():
            team = int(k[1])
            base = k[3:]
            tag = "L_" if team == side else "O_"
            out.setdefault(tag + base, []).append(v)
    return {k: float(np.mean(v)) for k, v in out.items()}
