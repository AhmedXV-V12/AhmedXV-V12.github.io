"""Team tactical layer.

Per team and per decision step this module computes a :class:`TeamView` - the shared tactical
picture every player of the team receives:

* **phase** from a finite-state tactical manager (build-up, attack, counter-attack, transition
  to defence, pressing, high/mid/low block, loose ball, set pieces). The *block height* and the
  *attacking style* come from a learned team-level "coach" policy (hierarchical RL); the FSM
  turns match events (possession changes, ball zone, time since turnover) into the phase.
* **dynamic formation anchors**: the formation blends between its compact defensive shape and
  its attacking shape (4-4-2 -> ~2-3-5) according to the phase, with line heights driven by
  ball position, block height and the opponent's offside line, plus ball-side shift.
* **targets for tactical options**: press point (goal-side of the carrier), marking assignment,
  passing-lane cover points, interception points, support positions in open space, runs in
  behind the defensive line.
* **pass evaluation** (for the team in possession): per teammate, success probability of a
  pass to feet and of a through ball (ground or lofted), progress, threat at target, expected
  value, offside flag. **Shot evaluation**: pressure / block / goalkeeper adjusted xG.
* **shape statistics and potentials** used by observations and rewards.

Everything is computed in the *team frame* (the team attacks +x).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from . import geometry as G
from .formation import GK, CB, FB, CM, WM, ST, Formation, ROLE_ZONE_TOLERANCE

HL, HW = G.HL, G.HW

# ---- phases ------------------------------------------------------------------------------
BUILD_UP, ATTACK, COUNTER_ATTACK, TRANSITION_TO_DEFENSE, PRESSING, HIGH_BLOCK, MID_BLOCK, \
    LOW_BLOCK, LOOSE_BALL, SET_PIECE_ATTACK, SET_PIECE_DEFEND = range(11)
NUM_PHASES = 11
PHASE_NAMES = ["BUILD UP", "ATTACK", "COUNTER ATTACK", "TRANSITION TO DEF", "PRESSING",
               "HIGH BLOCK", "MID BLOCK", "LOW BLOCK", "LOOSE BALL", "SET PIECE (ATT)",
               "SET PIECE (DEF)"]
PHASE_ALPHA = np.array([0.6, 1.0, 0.9, 0.25, 0.0, 0.0, 0.0, 0.0, 0.45, 0.9, 0.0])

# ---- coach instructions (learned team-level action) --------------------------------------
BLOCK_HIGH, BLOCK_MID, BLOCK_LOW = range(3)
STYLE_POSSESSION, STYLE_DIRECT = range(2)
NUM_COACH_ACTIONS = 6
COACH_NAMES = ["HIGH/POSS", "HIGH/DIRECT", "MID/POSS", "MID/DIRECT", "LOW/POSS", "LOW/DIRECT"]
BLOCK_LINES = {BLOCK_HIGH: (-8.0, 4.0, 18.0), BLOCK_MID: (-22.0, -10.0, 2.0),
               BLOCK_LOW: (-35.0, -25.0, -11.0)}

# set-piece kinds (shared with the engine)
SP_NONE, SP_KICKOFF, SP_THROW_IN, SP_CORNER, SP_GOAL_KICK, SP_FREE_KICK, SP_PENALTY, \
    SP_INDIRECT = range(8)
NUM_SP = 8
SP_NAMES = ["", "KICKOFF", "THROW-IN", "CORNER", "GOAL KICK", "FREE KICK", "PENALTY",
            "INDIRECT FK"]

BALL_TIMES = np.arange(0.0, 3.01, 0.2)     # prediction grid for interception


@dataclass
class TacticalState:
    """Persistent per-team tactical manager state (finite-state machine)."""
    coach_action: int = 2          # MID / POSSESSION
    phase: int = MID_BLOCK
    possession: int = 0            # +1 own, -1 opponent, 0 loose
    last_possession: int = 0
    time_in_possession_state: float = 0.0
    gained_x: float = 0.0
    counter_active: bool = False

    @property
    def block(self) -> int:
        return self.coach_action // 2

    @property
    def style(self) -> int:
        return self.coach_action % 2


@dataclass
class PassOptions:
    """Pass evaluation from the current carrier to each teammate (team frame, index = slot)."""
    p_feet: np.ndarray
    p_thr: np.ndarray
    ev_feet: np.ndarray
    ev_thr: np.ndarray
    prog_feet: np.ndarray
    prog_thr: np.ndarray
    loft_feet: np.ndarray
    loft_thr: np.ndarray
    feet_target: np.ndarray        # (11, 2)
    thr_target: np.ndarray         # (11, 2)
    offside: np.ndarray            # (11,) bool
    valid: np.ndarray              # (11,) bool (False for the carrier itself)

    @staticmethod
    def empty() -> "PassOptions":
        z = np.zeros(11)
        return PassOptions(z.copy(), z.copy(), z.copy(), z.copy(), z.copy(), z.copy(), z.copy(),
                           z.copy(), np.zeros((11, 2)), np.zeros((11, 2)),
                           np.zeros(11, bool), np.zeros(11, bool))

    def best_p(self) -> np.ndarray:
        return np.maximum(self.p_feet, self.p_thr) * self.valid

    def best_ev(self) -> np.ndarray:
        return np.where(self.valid, np.maximum(self.ev_feet, self.ev_thr), -1.0)


@dataclass
class TeamView:
    """Everything a team knows / has computed about the current situation (team frame)."""
    team: int
    attack_dir: float
    P: np.ndarray                  # own positions (11, 2)
    V: np.ndarray
    O: np.ndarray                  # opponent positions (11, 2)
    OV: np.ndarray
    b: np.ndarray                  # ball (2,)
    bv: np.ndarray
    carrier: int                   # own slot index with the ball, -1 if none
    opp_carrier: int
    possession: int                # +1 own, -1 opp, 0 loose
    phase: int
    alpha: float
    anchors: np.ndarray            # (11, 2)
    rest_anchors: np.ndarray       # (11, 2) defensive-balance positions
    lines: np.ndarray              # (3,) def / mid / att line x
    t2b: np.ndarray                # (11,) time to reach the ball
    opp_t2b: np.ndarray
    rank: np.ndarray               # (11,) outfield rank by t2b (GK usually 10)
    intercept_pt: np.ndarray       # (11, 2)
    press_pt: np.ndarray
    mark_pt: np.ndarray
    mark_assign: np.ndarray        # (11,) opponent index or -1
    opp_marked: np.ndarray         # (11,) bool
    cover_pt: np.ndarray
    support_pt: np.ndarray
    run_pt: np.ndarray
    offside_line: float            # line our attackers must not pass (team frame x)
    offside_pos: np.ndarray        # (11,) own players currently in an offside position
    opp_offside_pos: np.ndarray
    openness: np.ndarray           # (11,) own players: clearance from nearest opponent
    opp_openness: np.ndarray
    opp_threat: np.ndarray         # (11,) opponents' threat to our goal
    passes: PassOptions            # our carrier's options (empty if we don't have the ball)
    opp_passes: PassOptions        # opponent carrier's options, expressed in OUR frame
    shot_xg: float                 # our carrier's adjusted xG
    carrier_pressure: float        # pressure on whichever carrier exists (0..1)
    shape: np.ndarray              # (8,) centroid x,y, width, length, def line, att line, compact, offside line
    opp_shape: np.ndarray
    phi_press: float = 0.0
    phi_opt: float = 0.0
    phi_exposure: float = 0.0
    engaged: np.ndarray = field(default_factory=lambda: np.zeros(11, bool))
    _support_ctx: Optional[tuple] = None
    _support_done: Optional[np.ndarray] = None


# =========================================================================================
# helpers
# =========================================================================================
def _unit(v: np.ndarray) -> np.ndarray:
    n = G.norm(v, axis=-1, keepdims=True)
    return v / np.maximum(n, 1e-6)


def _clip_pitch(p: np.ndarray, margin: float = 1.0) -> np.ndarray:
    out = p.copy()
    out[..., 0] = np.clip(out[..., 0], -HL + 0.5, HL - margin)
    out[..., 1] = np.clip(out[..., 1], -HW + margin, HW - margin)
    return out


def pressure_from_distance(d) -> np.ndarray:
    return np.clip((5.0 - np.asarray(d)) / 4.0, 0.0, 1.0)


def shape_stats(P: np.ndarray, gk: int, offside_line: float) -> np.ndarray:
    out_idx = [i for i in range(len(P)) if i != gk]
    X = P[out_idx]
    xs = np.sort(X[:, 0])
    cen = X.mean(axis=0)
    return np.array([
        cen[0] / HL, cen[1] / HW,
        (X[:, 1].max() - X[:, 1].min()) / G.PITCH.width,
        (X[:, 0].max() - X[:, 0].min()) / G.PITCH.length,
        xs[1] / HL,                      # defensive line (2nd deepest outfield player)
        xs[-2:].mean() / HL,             # attacking line
        G.norm(X - cen, axis=1).mean() / 20.0,
        offside_line / HL,
    ])


# =========================================================================================
# phase FSM
# =========================================================================================
def update_phase(ts: TacticalState, possession: int, dead: bool, sp_ours: bool, bx: float,
                 opp_behind_ball: int, dt: float) -> int:
    if possession != ts.possession:
        if possession == 1 and ts.possession != 1:
            ts.gained_x = bx
            ts.counter_active = (bx < 15.0) and (opp_behind_ball <= 6)
        ts.last_possession = ts.possession if ts.possession != 0 else ts.last_possession
        ts.possession = possession
        ts.time_in_possession_state = 0.0
    else:
        ts.time_in_possession_state += dt

    if dead:
        ts.phase = SET_PIECE_ATTACK if sp_ours else SET_PIECE_DEFEND
        return ts.phase

    t = ts.time_in_possession_state
    if possession == 1:
        if ts.counter_active and t < 8.0 and (ts.style == STYLE_DIRECT or t < 5.0):
            ts.phase = COUNTER_ATTACK
        else:
            ts.counter_active = False
            ts.phase = BUILD_UP if bx < -12.0 else ATTACK
    elif possession == -1:
        if ts.last_possession == 1 and t < 3.0 and bx > -35.0:
            ts.phase = TRANSITION_TO_DEFENSE
        elif bx < -32.0:
            ts.phase = LOW_BLOCK
        elif ts.block == BLOCK_HIGH:
            ts.phase = PRESSING if bx > -5.0 else HIGH_BLOCK
        elif ts.block == BLOCK_MID:
            ts.phase = MID_BLOCK
        else:
            ts.phase = LOW_BLOCK
    else:
        ts.phase = LOOSE_BALL
    return ts.phase


# =========================================================================================
# formation deformation
# =========================================================================================
def compute_lines(ts: TacticalState, phase: int, bx: float, offside_line: float, sp_kind: int,
                  sp_ours: bool):
    """Return (defensive-shape lines, attacking-shape lines), each (def, mid, att) x."""
    block = ts.block
    if phase == PRESSING:
        d = np.array(BLOCK_LINES[BLOCK_HIGH]) + 6.0
    elif phase in (HIGH_BLOCK, MID_BLOCK, LOW_BLOCK):
        d = np.array(BLOCK_LINES[{HIGH_BLOCK: BLOCK_HIGH, MID_BLOCK: BLOCK_MID,
                                  LOW_BLOCK: BLOCK_LOW}[phase]])
    else:
        d = np.array(BLOCK_LINES[block])
    # block slides with the ball, keeps the back line goal-side of the ball and stays compact
    d = d + 0.3 * (bx - d[1])
    d[0] = min(d[0], bx - 3.0)
    d[0] = float(np.clip(d[0], -HL + 5.0, 10.0))
    d[1] = float(np.clip(d[1], d[0] + 7.0, d[0] + 15.0))
    d[2] = float(np.clip(d[2], d[1] + 7.0, d[1] + 17.0))

    # legal attacking line: offside only applies in the opponent half and never behind the ball
    off = min(max(offside_line, bx, 0.0) - 0.8, HL - 6.0)
    if phase == BUILD_UP:
        a0 = float(np.clip(bx - 10.0, -42.0, -5.0))
        a = np.array([a0, a0 + 17.0, min(off, a0 + 37.0)])
    elif phase == COUNTER_ATTACK:
        a = np.array([float(np.clip(bx - 30.0, -35.0, 0.0)), bx + 5.0, off])
    else:
        a = np.array([float(np.clip(bx - 25.0, -30.0, 12.0)),
                      float(np.clip(bx - 5.0, -10.0, 30.0)), off])
    if ts.style == STYLE_DIRECT:
        a[2] = off
        a[1] += 4.0
    a[1] = min(a[1], a[2] - 4.0)
    a[0] = min(a[0], a[1] - 6.0)

    # set pieces
    if sp_kind == SP_CORNER:
        if sp_ours:
            a = np.array([-2.0, 28.0, HL - 7.0])
        else:
            d = np.array([-HL + 3.0, -HL + 11.0, -22.0])
    elif sp_kind == SP_PENALTY and not sp_ours:
        d = np.array([-HL + 17.5, -HL + 20.0, -15.0])
    return d, a


def compute_anchors(form: Formation, d_lines, a_lines, alpha: float, b: np.ndarray,
                    possession: int, gk_depth_bonus: float = 0.0):
    lat_def_y = form.lat_def * HW * 0.78 + 0.30 * b[1]
    lat_att_y = form.lat_att * HW * 0.93 + 0.12 * b[1]
    line_x_def = np.concatenate([[-HL], d_lines])
    line_x_att = np.concatenate([[-HL], a_lines])
    x_def = line_x_def[form.line_def] + form.dx_def
    x_att = line_x_att[form.line_att] + form.dx_att
    anchors = np.stack([alpha * x_att + (1 - alpha) * x_def,
                        alpha * lat_att_y + (1 - alpha) * lat_def_y], axis=1)
    # defensive balance ("rest defence") shape: mostly the block, slightly advanced
    ra = 0.15
    rest = np.stack([ra * x_att + (1 - ra) * x_def, ra * lat_att_y + (1 - ra) * lat_def_y], axis=1)
    gk = form.gk_index
    anchors[gk] = goalkeeper_anchor(b, possession, gk_depth_bonus)
    rest[gk] = anchors[gk]
    return _clip_pitch(anchors, 1.5), _clip_pitch(rest, 1.5)


def goalkeeper_anchor(b: np.ndarray, possession: int, bonus: float = 0.0) -> np.ndarray:
    goal = np.array([-HL, 0.0])
    to_ball = b - goal
    dist = float(G.norm(to_ball))
    depth = float(np.clip(1.0 + 0.07 * dist, 1.0, 5.5))
    if possession == 1 and b[0] > -10.0:
        depth = float(np.clip(depth + 0.15 * (b[0] + 10.0), 1.0, 16.0))   # sweeper keeper
    depth += bonus
    u = to_ball / max(dist, 1e-6)
    p = goal + u * depth
    p[1] = np.clip(p[1], -G.GOAL_HALF - 1.0, G.GOAL_HALF + 1.0) if dist > 25 else p[1]
    return p


# =========================================================================================
# ball prediction / interception
# =========================================================================================
def predict_ball_path(b, bv, bz, bvz, carrier_pos=None, carrier_vel=None, phys=None):
    """Predicted (T, 2) ball positions and (T,) heights on the BALL_TIMES grid (team frame)."""
    if carrier_pos is not None:
        pts = carrier_pos[None, :] + carrier_vel[None, :] * BALL_TIMES[:, None] * 0.8
        return _clip_pitch(pts, 0.3), np.zeros(len(BALL_TIMES))
    if bz > 0.05 or bvz > 0.05:
        g = 9.81
        t_land = (bvz + np.sqrt(max(bvz * bvz + 2 * g * bz, 0.0))) / g
        t = BALL_TIMES
        z = np.where(t < t_land, bz + bvz * t - 0.5 * g * t * t, 0.0)
        t_air = np.minimum(t, t_land)
        pts = b[None, :] + bv[None, :] * t_air[:, None]
        after = np.maximum(t - t_land, 0.0)
        pts = pts + 0.45 * bv[None, :] * np.minimum(after, 1.2)[:, None]
        return pts, np.maximum(z, 0.0)
    pts = G.predict_ball(b, bv, BALL_TIMES, phys.ball_roll_decel if phys else 1.9,
                         phys.ball_roll_damping if phys else 0.18)
    return pts, np.zeros(len(BALL_TIMES))


def interception(pos, vel, vmax, pts, heights, reach_height=1.9):
    """Earliest reachable predicted ball point for each player. Returns (points, times)."""
    tr = G.time_to_reach(pos, vel, pts, vmax, reaction=0.15, reach=0.9)   # (T, P)
    reachable = (heights[:, None] <= reach_height) & (tr <= BALL_TIMES[:, None] + 0.05)
    has = reachable.any(axis=0)
    first = np.where(has, reachable.argmax(axis=0), len(BALL_TIMES) - 1)
    t = np.where(has, BALL_TIMES[first], tr[-1] + 0.5)
    return pts[first], t


# =========================================================================================
# pass & shot evaluation
# =========================================================================================
THROUGH_LEADS = np.array([5.0, 9.0, 14.0])
_K = 8
_ROLL_A = 3.6            # effective deceleration for pass-time estimates


def _ground_times(d: np.ndarray, v_arr: np.ndarray, s: np.ndarray, vmax_pass: float):
    v0 = np.minimum(np.sqrt(v_arr ** 2 + 2 * _ROLL_A * d), vmax_pass)
    disc = np.maximum(v0[..., None] ** 2 - 2 * _ROLL_A * s, 1e-3)
    return (v0[..., None] - np.sqrt(disc)) / _ROLL_A


def evaluate_passes(b, carrier, P, V, vmax, O, OV, vmax_opp, offside_line, pressure,
                    vmax_pass: float = 27.0) -> PassOptions:
    n = len(P)
    valid = np.ones(n, bool)
    valid[carrier] = False
    lead_t = np.minimum(0.6, G.norm(P - b, axis=1) / 15.0)
    feet = _clip_pitch(P + V * lead_t[:, None] * 0.8, 1.0)
    fwd = _unit(np.stack([np.ones(n), -0.35 * P[:, 1] / HW], axis=1))
    thr = P[:, None, :] + fwd[:, None, :] * THROUGH_LEADS[None, :, None]       # (n, 3, 2)
    thr = _clip_pitch(thr, 1.5)
    pts = np.concatenate([feet[:, None, :], thr], axis=1)                        # (n, 4, 2)
    flat = pts.reshape(-1, 2)                                                    # (4n, 2)
    recv = np.repeat(np.arange(n), 4)
    v_arr = np.tile(np.array([7.0, 4.5, 4.5, 4.5]), n)
    slack = np.tile(np.array([0.35, 0.05, 0.05, 0.05]), n)     # through balls must be run onto

    d = G.norm(flat - b, axis=1)
    frac = np.arange(1, _K + 1) / _K
    samples = b + (flat - b)[:, None, :] * frac[None, :, None]                   # (4n, K, 2)
    s = d[:, None] * frac[None, :]
    tb = _ground_times(d, v_arr, s, vmax_pass)                                   # (4n, K)
    t_opp = G.time_to_reach(O, OV, samples, vmax_opp, reaction=0.25, reach=1.0)  # (4n, K, 11)
    margin = t_opp - tb[..., None]
    q = G.sigmoid(-margin / 0.18)                    # opp gets there first
    q_opp = q.max(axis=1)                                                        # (4n, 11)
    p_lane = np.prod(1.0 - 0.92 * q_opp, axis=1)
    t_recv = G.time_to_reach_paired(P[recv], V[recv], flat, vmax[recv], reaction=0.15, reach=0.9)
    p_recv = G.sigmoid((tb[:, -1] + slack - t_recv) / 0.25)
    p_exec = np.clip(1.0 - 0.15 * pressure - d / 160.0, 0.2, 1.0)
    p_ground = p_lane * p_recv * p_exec

    # lofted alternative (only the landing zone matters)
    T = np.clip(0.9 + d / 25.0, 1.1, 2.6)
    t_opp_land = G.time_to_reach(O, OV, flat, vmax_opp, reaction=0.25, reach=1.2)  # (4n, 11)
    m_land = t_opp_land - T[:, None]
    q_land = G.sigmoid(-(m_land - 0.3) / 0.3)
    p_recv_l = G.sigmoid((T + 0.5 - t_recv) / 0.3)
    p_loft = np.prod(1.0 - 0.9 * q_land, axis=1) * p_recv_l * np.clip(0.9 - d / 110.0, 0.2, 0.9) \
        * (1.0 - 0.1 * pressure)
    p_loft = np.where(d > 18.0, p_loft, 0.0)
    lofted = p_loft > p_ground
    p = np.maximum(p_ground, p_loft)

    tx, ty = flat[:, 0], flat[:, 1]
    xt_t = G.xt(tx, ty)
    mid = 0.5 * (flat + b)
    xt_lost = G.xt(-mid[:, 0], -mid[:, 1])
    ev = p * xt_t - (1 - p) * xt_lost
    prog = (tx - b[0]) / 30.0

    off_line = max(offside_line, b[0], 0.0)
    offside = (P[:, 0] > off_line + 0.1)
    p = p.reshape(n, 4)
    ev = ev.reshape(n, 4)
    ev = np.where(offside[:, None], -0.05, ev)
    prog = prog.reshape(n, 4)
    lofted = lofted.reshape(n, 4)
    best_thr = 1 + np.argmax(ev[:, 1:], axis=1)
    idx = np.arange(n)
    return PassOptions(
        p_feet=p[:, 0] * valid, p_thr=p[idx, best_thr] * valid,
        ev_feet=ev[:, 0] * valid, ev_thr=ev[idx, best_thr] * valid,
        prog_feet=prog[:, 0] * valid, prog_thr=prog[idx, best_thr] * valid,
        loft_feet=lofted[:, 0].astype(float), loft_thr=lofted[idx, best_thr].astype(float),
        feet_target=pts[:, 0], thr_target=pts[idx, best_thr],
        offside=offside & valid, valid=valid)


def evaluate_shot(b, O, opp_gk: int, pressure: float) -> float:
    base = float(G.xg_raw(np.array(b[0]), np.array(b[1])))
    if b[0] < 0:
        return 0.0
    goal = np.array([HL, 0.0])
    outfield = np.array([i for i in range(len(O)) if i != opp_gk])
    dist, t = G.segment_point_distance(b, goal, O[outfield])
    blockers = (dist < 1.2) & (t > 0.03) & (t < 0.95)
    block = min(0.8, 0.28 * blockers.sum())
    gd, _ = G.segment_point_distance(b, goal, O[opp_gk:opp_gk + 1])
    gk_factor = 0.8 + 0.3 * float(np.clip(gd[0] / 4.0, 0.0, 2.0))
    return float(np.clip(base * (1 - block) * gk_factor * (1 - 0.35 * pressure), 0.0, 0.95))


# =========================================================================================
# per-team targets
# =========================================================================================
def support_points(i_list, b, P, O, anchors, roles, offside_line, carrier):
    """Best support position (team frame) for each non-carrier player in ``i_list``."""
    ang = np.deg2rad(np.array([-70, -45, -20, 0, 20, 45, 70, 110, -110, 150, -150, 180]))
    radii = np.array([10.0, 16.0, 23.0])
    ring = b + np.stack([np.cos(ang)[:, None] * radii, np.sin(ang)[:, None] * radii],
                        axis=-1).reshape(-1, 2)
    ring = _clip_pitch(ring, 2.0)
    out = anchors.copy()
    idx = np.asarray(i_list, dtype=np.int64)
    if len(idx) == 0:
        return out
    off_line = max(offside_line, b[0], 0.0) - 0.8
    local_off = np.array([[0, 0], [6, 0], [-6, 0], [0, 6], [0, -6]], dtype=float)
    local = _clip_pitch(anchors[idx][:, None, :] + local_off[None], 2.0)        # (n, 5, 2)
    nr, nl = len(ring), local_off.shape[0]
    C = np.concatenate([np.broadcast_to(ring, (len(idx), nr, 2)), local], axis=1)  # (n, nr+nl, 2)
    C[..., 0] = np.minimum(C[..., 0], off_line)
    flatC = C.reshape(-1, 2)
    lane_d = G.segments_points_distance(b, flatC, O).min(axis=1).reshape(len(idx), -1)
    open_d = G.norm(flatC[:, None, :] - O[None], axis=-1).min(axis=1).reshape(len(idx), -1)
    mates = np.ones(len(P), bool)
    if carrier >= 0:
        mates[carrier] = False
    dPC = G.norm(C[:, :, None, :] - P[None, None, :, :], axis=-1)       # (n, c, 11)
    close = (dPC < 7.0) & mates[None, None, :]
    close[np.arange(len(idx)), :, idx] = False                                   # exclude self
    crowd = close.sum(axis=-1)
    tol = np.array([ROLE_ZONE_TOLERANCE[int(r)] for r in roles[idx]])[:, None] * 1.6
    zone = np.maximum(G.norm(C - anchors[idx][:, None, :], axis=-1) - tol, 0.0) / 10.0
    travel = G.norm(C - P[idx][:, None, :], axis=-1) / 15.0
    score = (1.0 * np.minimum(lane_d, 6.0) / 6.0 + 0.8 * np.minimum(open_d, 8.0) / 8.0
             + 0.5 * np.clip((C[..., 0] - b[0]) / 20.0, -1, 1) + 4.0 * G.xt(C[..., 0], C[..., 1])
             - 0.6 * travel - 0.5 * crowd - 1.2 * zone)
    best = np.argmax(score, axis=1)
    out[idx] = C[np.arange(len(idx)), best]
    return out


def build_team_view(team: int, attack_dir: float, form: Formation, ts: TacticalState,
                    pos_w, vel_w, vmax_all, ball_w, bvel_w, bz, bvz, possessor, dead, sp_kind,
                    sp_team, phys, dt, pass_opts_w: Optional[PassOptions],
                    flight_team: int = -1) -> TeamView:
    """Build the tactical picture for ``team``.

    ``pass_opts_w`` are the opponent carrier's pass options already converted to this team's
    frame (or None). ``flight_team`` is the team whose pass is currently travelling (-1 none):
    during a pass the passing team is still tactically "in possession".
    """
    own = slice(0, 11) if team == 0 else slice(11, 22)
    opp = slice(11, 22) if team == 0 else slice(0, 11)
    P = pos_w[own] * attack_dir
    V = vel_w[own] * attack_dir
    O = pos_w[opp] * attack_dir
    OV = vel_w[opp] * attack_dir
    vmax, vmax_opp = vmax_all[own], vmax_all[opp]
    b = ball_w * attack_dir
    bv = bvel_w * attack_dir
    carrier = possessor - own.start if own.start <= possessor < own.stop else -1
    opp_carrier = possessor - opp.start if opp.start <= possessor < opp.stop else -1
    gk = form.gk_index

    # tactical possession (passes in flight keep the passing team "in possession")
    if carrier >= 0:
        possession = 1
    elif opp_carrier >= 0:
        possession = -1
    elif flight_team >= 0:
        possession = 1 if flight_team == team else -1
    else:
        possession = 0
    if dead:
        possession = 1 if sp_team == team else -1
    sp_ours = dead and sp_team == team

    opp_x_sorted = np.sort(O[:, 0])[::-1]
    offside_line = float(opp_x_sorted[1])                       # second-last opponent
    own_x_sorted = np.sort(P[:, 0])
    opp_offside_line = float(own_x_sorted[1])
    opp_behind_ball = int(np.sum(O[:, 0] > b[0]))
    phase = update_phase(ts, possession, dead, sp_ours, float(b[0]), opp_behind_ball, dt)
    alpha = float(PHASE_ALPHA[phase])
    if phase == LOOSE_BALL:
        alpha = 0.6 if ts.last_possession == 1 else 0.3
    d_lines, a_lines = compute_lines(ts, phase, float(b[0]), offside_line,
                                     sp_kind if dead else SP_NONE, sp_ours)
    anchors, rest = compute_anchors(form, d_lines, a_lines, alpha, b, possession)
    lines = alpha * a_lines + (1 - alpha) * d_lines

    # interception / time to ball
    if possessor >= 0:
        cpos = pos_w[possessor] * attack_dir
        cvel = vel_w[possessor] * attack_dir
        pts, hts = predict_ball_path(b, bv, bz, bvz, cpos, cvel)
    else:
        pts, hts = predict_ball_path(b, bv, bz, bvz, phys=phys)
    ipt, t2b = interception(P, V, vmax, pts, hts)
    ipt_o, opp_t2b = interception(O, OV, vmax_opp, pts, hts)
    if carrier >= 0:
        t2b[carrier] = 0.0
    if opp_carrier >= 0:
        opp_t2b[opp_carrier] = 0.0
    ball_dist_goal = np.hypot(b[0] + HL, b[1])
    rank_key = t2b.copy()
    if ball_dist_goal > 22.0:
        rank_key[gk] = 1e9
    rank = np.empty(11, dtype=np.int64)
    rank[np.argsort(rank_key, kind="stable")] = np.arange(11)

    # openness / threat
    d_own_opp = G.norm(P[:, None, :] - O[None, :, :], axis=-1)       # (11, 11)
    openness = np.clip(d_own_opp.min(axis=1) / 8.0, 0.0, 1.0)
    opp_openness = np.clip(d_own_opp.min(axis=0) / 8.0, 0.0, 1.0)
    opp_threat = G.xt(-O[:, 0], -O[:, 1])

    own_goal = np.array([-HL, 0.0])
    # --- press
    if opp_carrier >= 0:
        cp = O[opp_carrier]
        press_pt = np.repeat((cp + _unit(own_goal - cp) * 1.2)[None], 11, axis=0)
    else:
        press_pt = ipt.copy()
    # --- marking assignment (zonal-man hybrid): most dangerous opponents first
    mark_assign = -np.ones(11, dtype=np.int64)
    opp_marked = np.zeros(11, bool)
    presser = int(np.argmin(rank)) if possession != 1 else -1
    free = np.ones(11, bool)
    free[gk] = False
    if presser >= 0:
        free[presser] = False
    d_anchor_opp = G.norm(anchors[:, None] - O[None], axis=-1)                  # (11, 11)
    for o in np.argsort(-opp_threat):
        if O[o, 0] > 20.0 or o == opp_carrier:
            continue
        dist = np.where(free, d_anchor_opp[:, o], np.inf)
        j = int(np.argmin(dist))
        if dist[j] < 20.0:
            mark_assign[j] = o
            opp_marked[o] = True
            free[j] = False
    tgt_o = np.where(mark_assign >= 0, mark_assign, np.argmin(d_anchor_opp, axis=1))
    mo = O[tgt_o]
    mark_pt = mo + _unit(own_goal - mo) * 1.5 + _unit(b - mo) * 0.5

    # --- cover: block the opponent carrier's most dangerous lanes, else rest defence
    cover_pt = rest.copy()
    opp_passes = pass_opts_w if pass_opts_w is not None else PassOptions.empty()
    if opp_carrier >= 0 and pass_opts_w is not None:
        cp = O[opp_carrier]
        danger = opp_passes.best_ev()
        tgt = np.where((opp_passes.ev_thr > opp_passes.ev_feet)[:, None], opp_passes.thr_target,
                       opp_passes.feet_target)
        used = np.zeros(11, bool)
        used[gk] = True
        if presser >= 0:
            used[presser] = True
        for lane in np.argsort(-danger)[:3]:
            if danger[lane] <= -0.5:
                continue
            lane_pt = cp + (tgt[lane] - cp) * 0.45
            cand = np.where(~used)[0]
            if len(cand) == 0:
                break
            j = cand[int(np.argmin(G.norm(P[cand] - lane_pt, axis=1)))]
            cover_pt[j] = lane_pt
            used[j] = True
    elif possession != 1:
        cover_pt = rest.copy()
        cover_pt[:, 1] += 0.15 * (b[1] - rest[:, 1])

    # --- support & runs (in possession)
    offside_pos = (P[:, 0] > max(offside_line, b[0], 0.0) + 0.1)
    opp_offside_pos = (O[:, 0] < min(opp_offside_line, b[0], 0.0) - 0.1)
    support_pt = anchors.copy()     # filled lazily by ensure_support() for players who need it
    run_x = min(max(offside_line, 0.0) + 9.0, HL - 7.0)
    run_pt = np.stack([np.full(11, run_x), np.clip(0.7 * P[:, 1] + 0.3 * anchors[:, 1],
                                                   -HW + 3, HW - 3)], axis=1)
    run_pt[offside_pos, 0] = max(offside_line, 0.0) - 0.8      # step back onside first
    run_pt = _clip_pitch(run_pt, 2.0)

    # --- passes / shot for our carrier
    passes = PassOptions.empty()
    shot_xg = 0.0
    carrier_pressure = 0.0
    if carrier >= 0:
        dmin = float(np.min(G.norm(O - P[carrier], axis=1)))
        carrier_pressure = float(pressure_from_distance(dmin))
        passes = evaluate_passes(b, carrier, P, V, vmax, O, OV, vmax_opp, offside_line,
                                 carrier_pressure, phys.max_pass_speed if phys else 27.0)
        shot_xg = evaluate_shot(b, O, gk, carrier_pressure)
    elif opp_carrier >= 0:
        carrier_pressure = float(pressure_from_distance(np.min(G.norm(P - O[opp_carrier],
                                                                               axis=1))))

    view = TeamView(
        team=team, attack_dir=attack_dir, P=P, V=V, O=O, OV=OV, b=b, bv=bv, carrier=carrier,
        opp_carrier=opp_carrier, possession=possession, phase=phase, alpha=alpha,
        anchors=anchors, rest_anchors=rest, lines=lines, t2b=t2b, opp_t2b=opp_t2b, rank=rank,
        intercept_pt=ipt, press_pt=press_pt, mark_pt=_clip_pitch(mark_pt, 0.5),
        mark_assign=mark_assign, opp_marked=opp_marked, cover_pt=_clip_pitch(cover_pt, 0.5),
        support_pt=support_pt, run_pt=run_pt, offside_line=offside_line,
        offside_pos=offside_pos, opp_offside_pos=opp_offside_pos, openness=openness,
        opp_openness=opp_openness, opp_threat=opp_threat, passes=passes, opp_passes=opp_passes,
        shot_xg=shot_xg, carrier_pressure=carrier_pressure,
        shape=shape_stats(P, gk, offside_line), opp_shape=shape_stats(O, gk, opp_offside_line))

    # --- potentials (team-shared shaping terms)
    if opp_carrier >= 0 and not dead:
        view.phi_press = float(np.max(np.clip((6.0 - G.norm(P - O[opp_carrier], axis=1))
                                              / 5.0, 0.0, 1.0)))
    if carrier >= 0 and not dead:
        bp = passes.best_p() * (0.6 + 0.4 * np.clip(np.maximum(passes.prog_feet, passes.prog_thr),
                                                     0, 1))
        view.phi_opt = float(np.sort(bp)[-3:].mean())
    if possession != 1:
        danger_zone = O[:, 0] < 20.0
        view.phi_exposure = float(min(1.0, np.sum(opp_threat * opp_openness * danger_zone) * 2.0))

    # --- engaged players (legitimately away from their zone)
    engaged = np.zeros(11, bool)
    engaged[rank <= 1] = True
    if carrier >= 0:
        engaged[carrier] = True
    has_mark = mark_assign >= 0
    engaged[has_mark] |= d_own_opp[has_mark, mark_assign[has_mark]] < 4.0
    if possession == 1:
        engaged |= np.isin(form.roles, [ST, WM, FB]) & (P[:, 0] > anchors[:, 0])  # forward runs
    view.engaged = engaged
    view._support_ctx = (form.roles, gk) if possession == 1 else None
    view._support_done = np.zeros(11, bool)
    return view


def ensure_support(view: TeamView, players) -> None:
    """Compute support positions for the given players (lazy: this is the most expensive
    target and only the players that actually choose SUPPORT need it)."""
    if view._support_ctx is None:
        return
    roles, gk = view._support_ctx
    todo = [i for i in players if not view._support_done[i] and i != view.carrier and i != gk]
    if not todo:
        return
    ref = view.P[view.carrier] if view.carrier >= 0 else view.b
    pts = support_points(todo, ref, view.P, view.O, view.anchors, roles, view.offside_line,
                         view.carrier)
    view.support_pt[todo] = pts[todo]
    view._support_done[todo] = True
