"""Central configuration for the 11v11 football simulation and MAPPO training.

Every tunable constant lives here (grouped into dataclasses) so nothing important is
scattered through the code. The full config is serialised into every checkpoint.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

VERSION = "2.1.0"
# Bump whenever the observation layout / action space / network topology changes.
# Checkpoints with a different ARCH_VERSION are rejected with a clear message.
ARCH_VERSION = 3


@dataclass
class PitchConfig:
    """Real-world FIFA dimensions in metres. Origin at the centre spot."""
    length: float = 105.0
    width: float = 68.0
    goal_width: float = 7.32
    goal_height: float = 2.44
    penalty_area_depth: float = 16.5
    penalty_area_width: float = 40.32
    goal_area_depth: float = 5.5
    goal_area_width: float = 18.32
    penalty_spot_dist: float = 11.0
    centre_circle_radius: float = 9.15
    runoff: float = 2.0  # players may step this far outside the lines

    @property
    def half_length(self) -> float:
        return self.length / 2

    @property
    def half_width(self) -> float:
        return self.width / 2


@dataclass
class PhysicsConfig:
    dt: float = 0.05                 # physics sub-step (s)
    substeps: int = 4                # sub-steps per agent decision -> 5 Hz decisions
    player_radius: float = 0.45
    ball_radius: float = 0.11
    jog_speed: float = 5.2           # m/s
    sprint_speed: float = 7.8        # m/s (scaled by stamina)
    dribble_speed: float = 6.4
    accel: float = 5.5               # m/s^2
    decel: float = 9.0
    ball_roll_decel: float = 1.9     # constant rolling resistance (m/s^2)
    ball_roll_damping: float = 0.18  # linear drag on ground (1/s)
    ball_air_damping: float = 0.03
    gravity: float = 9.81
    bounce_restitution: float = 0.35
    control_radius: float = 0.95     # distance at which a player can touch the ball
    gk_catch_radius: float = 1.5
    control_height: float = 1.1      # max ball height for foot control
    header_height: float = 2.3
    dribble_offset: float = 0.65
    kick_cooldown: float = 0.35      # s before the kicker may touch the ball again
    tackle_range: float = 2.0
    tackle_stun: float = 0.7         # s a failed tackler is slowed
    max_pass_speed: float = 27.0
    max_shot_speed: float = 29.0
    stamina_sprint_drain: float = 0.012   # per second at full sprint
    stamina_recover: float = 0.006        # per second when jogging/walking


@dataclass
class RulesConfig:
    half_duration_s: float = 300.0   # simulated seconds per half (displayed clock scales to 45:00)
    display_half_minutes: float = 45.0
    setpiece_setup_s: float = 1.0    # dead-ball time before the taker may kick
    setpiece_force_s: float = 4.0    # after this the taker must kick
    gk_max_hold_s: float = 6.0
    offside: bool = True
    fouls: bool = True
    base_foul_prob: float = 0.06
    behind_foul_prob: float = 0.30
    free_kick_distance: float = 9.15
    max_stall_s: float = 10.0        # dribbler holding ball without progress -> penalty ramps


@dataclass
class FormationConfig:
    name: str = "4-4-2"


@dataclass
class RewardConfig:
    """Reward weights. Goals are the unit of value (+1 / -1).

    Most dense shaping is *potential-based* (gamma*Phi(s') - Phi(s)) so that it cannot be
    farmed: any cyclic behaviour (endless passing, ball hoarding) nets <= 0 shaping reward.
    """
    goal: float = 1.0
    xt_potential: float = 1.0          # possession value (expected threat) potential
    pressure_potential: float = 0.015  # pressure on opposing ball carrier
    options_potential: float = 0.02    # quality of passing options available to our carrier
    exposure_potential: float = 0.03   # dangerous unmarked opponents (negative)
    shot_quality: float = 0.08         # xG-weighted shot bonus (only for xG > shot_min_xg)
    shot_min_xg: float = 0.06
    bad_shot: float = 0.03             # penalty for shots with xG < bad_shot_xg
    bad_shot_xg: float = 0.025
    pass_complete: float = 0.015
    progressive_pass: float = 0.03
    pass_decay: float = 0.6            # repeated non-progressive passes earn geometrically less
    turnover: float = 0.04             # losing the ball (x danger multiplier in own third)
    recovery: float = 0.04             # interception / tackle won
    block: float = 0.04
    save: float = 0.25                 # x shot xG
    shape: float = 0.0012              # per-step max penalty for leaving tactical zone
    crowding: float = 0.001            # per-step penalty for clustering with teammates
    ball_chase: float = 0.0015         # per-step penalty for surplus players near the ball
    collision: float = 0.003
    foul: float = 0.04
    penalty_conceded: float = 0.15
    offside: float = 0.02
    out_of_play: float = 0.01
    stall: float = 0.002               # per-step when holding the ball too long
    sprint_cost: float = 0.0002
    individual_weight: float = 1.0     # multiplier on all individual terms (curriculum-scaled)


@dataclass
class ModelConfig:
    d_model: int = 192
    n_heads: int = 6
    actor_layers: int = 3
    critic_layers: int = 3
    ff_mult: int = 4
    dropout: float = 0.0


@dataclass
class PPOConfig:
    lr: float = 2.5e-4
    lr_min: float = 5e-5
    lr_anneal_steps: int = 200_000_000
    gamma: float = 0.995
    gae_lambda: float = 0.95
    clip: float = 0.2
    value_clip: float = 0.2
    epochs: int = 4
    minibatch_team_samples: int = 1024
    rollout_len: int = 128
    entropy_coef: float = 0.012
    entropy_coef_min: float = 0.003
    coach_entropy_coef: float = 0.01
    value_coef: float = 0.5
    max_grad_norm: float = 0.5
    target_kl: float = 0.03
    amp: bool = True                 # bf16 autocast on CUDA
    kickstart_coef: float = 0.3      # teacher-imitation loss weight at step 0
    kickstart_steps: int = 3_000_000 # linearly decays to 0 over these env steps
    kickstart_smoothing: float = 0.3 # label smoothing of the teacher target (keeps entropy)


@dataclass
class LeagueConfig:
    self_play_prob: float = 0.5      # red brain vs blue brain (both learn)
    scripted_prob: float = 0.1       # opponent = scripted heuristic AI
    pool_size: int = 24              # historical opponents kept
    snapshot_interval: int = 1_000_000  # env steps between pool snapshots
    pfsp_power: float = 1.5          # prioritised fictitious self-play weighting


@dataclass
class CheckpointConfig:
    directory: str = "checkpoints"
    interval: int = 50_000           # env steps between lightweight checkpoints
    full_interval: int = 500_000     # env steps between permanent full checkpoints
    keep_last: int = 20              # lightweight checkpoints retained (full ones are never deleted)


@dataclass
class TrainConfig:
    num_envs: int = 16
    num_workers: int = 8             # subprocesses hosting envs (0 = all in main process)
    total_steps: int = 10_000_000_000  # effectively "run until stopped"
    seed: int = 12345
    log_interval_s: float = 30.0
    eval_interval: int = 2_000_000
    eval_matches: int = 2
    eval_half_duration_s: float = 120.0
    render: bool = True
    render_fps: int = 30
    speed: float = 0.0               # visual speed: 0 = MAX (uncapped), 1 = real time
    log_dir: str = "logs"
    coach_interval: int = 15         # decisions between team-coach (tactical) choices


@dataclass
class CurriculumStage:
    name: str
    min_steps: int                   # env steps at which this stage may start
    scripted_skill: float            # opponent scripted AI skill (1 = full)
    self_play_prob: float
    scripted_prob: float
    shape_mult: float
    individual_weight: float
    half_duration_s: float
    offside: bool
    fouls: bool
    gate_winrate_vs_scripted: float = 0.0  # extra requirement to enter this stage


def default_curriculum() -> List[CurriculumStage]:
    return [
        CurriculumStage("1-ball-basics", 0, 0.35, 0.0, 1.0, 1.0, 1.2, 120.0, False, False),
        CurriculumStage("2-passing-possession", 3_000_000, 0.6, 0.2, 0.8, 1.0, 1.2, 180.0, True, False),
        CurriculumStage("3-team-positioning", 10_000_000, 0.8, 0.35, 0.5, 1.2, 1.1, 240.0, True, True),
        CurriculumStage("4-attack-defend", 25_000_000, 1.0, 0.5, 0.3, 1.0, 1.0, 300.0, True, True),
        CurriculumStage("5-transitions", 50_000_000, 1.0, 0.5, 0.15, 1.0, 1.0, 300.0, True, True,
                        gate_winrate_vs_scripted=0.45),
        CurriculumStage("6-full-self-play", 100_000_000, 1.0, 0.5, 0.1, 0.8, 0.8, 300.0, True, True),
        CurriculumStage("7-tactical-optimisation", 250_000_000, 1.0, 0.45, 0.05, 0.6, 0.6, 300.0, True, True),
    ]


@dataclass
class Config:
    pitch: PitchConfig = field(default_factory=PitchConfig)
    physics: PhysicsConfig = field(default_factory=PhysicsConfig)
    rules: RulesConfig = field(default_factory=RulesConfig)
    formation: FormationConfig = field(default_factory=FormationConfig)
    reward: RewardConfig = field(default_factory=RewardConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    ppo: PPOConfig = field(default_factory=PPOConfig)
    league: LeagueConfig = field(default_factory=LeagueConfig)
    checkpoint: CheckpointConfig = field(default_factory=CheckpointConfig)
    train: TrainConfig = field(default_factory=TrainConfig)
    curriculum: List[CurriculumStage] = field(default_factory=default_curriculum)
    players_per_team: int = 11
    device: str = "auto"             # "auto" | "cuda" | "cpu"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Config":
        cfg = Config()
        for f in dataclasses.fields(cfg):
            if f.name not in d:
                continue
            val = d[f.name]
            cur = getattr(cfg, f.name)
            if f.name == "curriculum":
                setattr(cfg, f.name, [CurriculumStage(**s) for s in val])
            elif dataclasses.is_dataclass(cur):
                known = {k: v for k, v in val.items() if k in {x.name for x in dataclasses.fields(cur)}}
                setattr(cfg, f.name, type(cur)(**known))
            else:
                setattr(cfg, f.name, val)
        return cfg
