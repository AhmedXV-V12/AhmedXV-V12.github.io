"""Training orchestration: rollouts, MAPPO updates, self-play league, curriculum, logging,
checkpointing, automatic resume and the visible training window.

Two independent brains are trained: red (always team 0) and blue (always team 1). Each has
its own network, optimizer, value normalisers and opponent pool, and is saved to its own
checkpoint file. Only the brain playing a team slot learns from that slot's experience."""
from __future__ import annotations

import glob
import logging
import multiprocessing as mp
import os
import shutil
import signal
import threading
import time
import traceback
from collections import defaultdict, deque
from typing import Dict, List, Optional

import numpy as np
import torch

from . import tactics as T
from .checkpoint import BRAINS, CheckpointManager
from .config import ARCH_VERSION, VERSION, Config
from .league import Curriculum, OpponentPool
from .model import ActorCritic, GraphedPolicy, _gumbel_sample, count_parameters
from .ppo import RolloutBuffer, ValueNorm, obs_to_torch, ppo_update
from .stats import aggregate
from .utils import (MetricsWriter, configure_torch, device_label, device_report, fmt_int,
                    rng_state, seed_everything, select_device, set_rng_state, setup_logging)
from .vec_env import VecEnv
from .rewards import REWARD_COMPONENTS

LEARNER, POOL, SCRIPTED = "learner", "pool", "scripted"


class Trainer:
    def __init__(self, cfg: Config, render: bool = True, fresh: bool = False,
                 allow_human: bool = False):
        self.cfg = cfg
        self.log = setup_logging(cfg.train.log_dir)
        self.device = select_device(cfg.device)
        configure_torch(self.device)
        rep = device_report(self.device)
        self.log.info("=" * 72)
        self.log.info(f"JOWA Football AI v{VERSION} (arch {ARCH_VERSION}) - 11v11 MAPPO training")
        self.log.info(f"CUDA available: {rep['cuda_available']} | device: {rep['device']}"
                      + (f" | GPU: {rep['gpu_name']} | VRAM: {rep['vram_gb']} GB | "
                         f"bf16: {rep['bf16']}" if rep.get("gpu_name") else ""))
        self._legacy_notice()
        seed_everything(cfg.train.seed)
        self.rng = np.random.default_rng(cfg.train.seed)
        # one independent brain per team: index 0 = red, 1 = blue
        self.models = [ActorCritic(cfg.model).to(self.device) for _ in BRAINS]
        self.log.info(f"Brains: red + blue, each an entity transformer actor-critic with "
                      f"{count_parameters(self.models[0]) / 1e6:.2f}M parameters "
                      f"(actor {count_parameters(self.models[0].actor) / 1e6:.2f}M)")
        self.opts = [torch.optim.AdamW(m.parameters(), lr=cfg.ppo.lr, eps=1e-5, weight_decay=0.0)
                     for m in self.models]
        self.vnorms_p = [ValueNorm().to(self.device) for _ in BRAINS]
        self.vnorms_t = [ValueNorm().to(self.device) for _ in BRAINS]
        self.amp = cfg.ppo.amp and self.device.type == "cuda"
        ck_dir = cfg.checkpoint.directory
        if fresh:
            self._archive_existing(ck_dir)
        self.ckpt = CheckpointManager(ck_dir, cfg.checkpoint.keep_last)
        self.pools = [OpponentPool(cfg, os.path.join(ck_dir, "pool", b), self.device)
                      for b in BRAINS]           # pools[k] = snapshots of brain k
        self.curriculum = Curriculum(cfg.curriculum)
        self.metrics = MetricsWriter(os.path.join(cfg.train.log_dir, "metrics.jsonl"))
        self.eval_path = os.path.join(cfg.train.log_dir, "eval.jsonl")
        # counters / statistics (all checkpointed)
        self.global_step = 0
        self.updates = 0
        self.matches = 0
        self.results = [defaultdict(lambda: [0, 0, 0]) for _ in BRAINS]  # opp type -> [W,D,L]
        self.recent = deque(maxlen=200)                      # (summary, learner_side, opp)
        self.recent_rewards = deque(maxlen=200)
        self.best_eval = [None for _ in BRAINS]
        self.last_ckpt_name = "-"
        self.last_update_stats: List[Dict] = [{} for _ in BRAINS]
        self._resume()
        self.next_ckpt = (self.global_step // cfg.checkpoint.interval + 1) * cfg.checkpoint.interval
        self.next_full = (self.global_step // cfg.checkpoint.full_interval + 1) * \
            cfg.checkpoint.full_interval
        self.next_snapshot = (self.global_step // cfg.league.snapshot_interval + 1) * \
            cfg.league.snapshot_interval
        self.next_eval = (self.global_step // cfg.train.eval_interval + 1) * cfg.train.eval_interval
        self.curriculum.update(self.global_step)
        self.policies = None               # CUDA-graphed rollout inference per brain (lazy)
        self.renderer = None
        if render:
            from .render import Renderer
            self.renderer = Renderer("JOWA Football AI 11v11 - TRAINING", cfg.train.speed,
                                     cfg.train.render_fps, allow_human=allow_human)
        self._stop = False
        self._eval_proc = None
        self._eval_seen = 0
        self._install_signals()

    # =====================================================================================
    # setup helpers
    # =====================================================================================
    def _legacy_notice(self):
        legacy = glob.glob("football_model_*.pth") + glob.glob(os.path.join("legacy", "*.pth"))
        if legacy:
            self.log.info("Legacy 6v6 DQN models detected (" + ", ".join(legacy) + "). They are "
                          "incompatible with the new 11v11 entity-transformer MAPPO architecture "
                          "and are NOT loaded; old code/models are preserved in legacy/.")

    def _archive_existing(self, d: str):
        if os.path.isdir(d) and os.listdir(d):
            dst = f"{d}_archive_{time.strftime('%Y%m%d_%H%M%S')}"
            shutil.move(d, dst)
            self.log.warning(f"--fresh: existing checkpoints moved to {dst} (nothing deleted)")

    def _install_signals(self):
        def handler(signum, frame):
            self.log.warning(f"Signal {signum} received - saving checkpoint and stopping")
            self._stop = True
        for s in ("SIGTERM", "SIGBREAK"):
            if hasattr(signal, s):
                try:
                    signal.signal(getattr(signal, s), handler)
                except (ValueError, OSError):
                    pass

    # =====================================================================================
    # checkpoint state
    # =====================================================================================
    def _payload(self, k: int) -> dict:
        """Checkpoint payload of brain k. Shared training state (step counters, curriculum,
        RNG, config) is stored in both files so each one is self-contained."""
        return {
            "model": self.models[k].state_dict(),
            "optimizer": self.opts[k].state_dict(),
            "vnorm_p": self.vnorms_p[k].state_dict(),
            "vnorm_t": self.vnorms_t[k].state_dict(),
            "pool": self.pools[k].state_dict(),
            "results": dict(self.results[k]),
            "best_eval": self.best_eval[k],
            "updates": self.updates,
            "matches": self.matches,
            "curriculum": self.curriculum.state_dict(),
            "recent_summaries": list(self.recent)[-50:],
            "exploration": {"entropy_coef": self._ent_coef(), "kickstart_coef": self._ks_coef()},
            "rng": rng_state(),
            "np_rng": self.rng.bit_generator.state,
            "config": self.cfg.to_dict(),
            "seed": self.cfg.train.seed,
        }

    def _resume(self):
        res = self.ckpt.load_latest_valid(map_location="cpu")
        if res is None:
            self.log.info("No checkpoint found - starting a new training run")
            return
        paths, cks = res
        for k, brain in enumerate(BRAINS):
            ck, path = cks[brain], paths[brain]
            try:
                self.models[k].load_state_dict(ck["model"])
            except RuntimeError as e:
                raise SystemExit(
                    f"Checkpoint {path} does not match the current model configuration ({e}).\n"
                    f"Refusing to overwrite it. Use --checkpoint-dir <new dir> or --fresh to "
                    f"start a separate run (existing checkpoints are archived, never deleted).")
            try:
                self.opts[k].load_state_dict(ck["optimizer"])
            except Exception as e:
                self.log.warning(f"{brain} optimizer state not restored ({e}); fresh Adam")
            for name, vn in (("vnorm_p", self.vnorms_p[k]), ("vnorm_t", self.vnorms_t[k])):
                if name in ck:
                    vn.load_state_dict(ck[name])
            self.pools[k].load_state_dict(ck.get("pool", {}))
            for opp, v in ck.get("results", {}).items():
                self.results[k][opp] = list(v)
            self.best_eval[k] = ck.get("best_eval")
            if ck.get("split_from_single_brain"):
                self.log.info(f"{brain} brain starts from the former shared single brain "
                              f"(both brains begin identical and diverge from here)")
        ck = cks["red"]                                  # shared state (identical in both)
        self.global_step = int(ck["global_step"])
        self.updates = int(ck.get("updates", 0))
        self.matches = int(ck.get("matches", 0))
        self.curriculum.load_state_dict(ck.get("curriculum", {}))
        self.recent.extend(ck.get("recent_summaries", []))
        if "rng" in ck:
            set_rng_state(ck["rng"])
        if "np_rng" in ck:
            try:
                self.rng.bit_generator.state = ck["np_rng"]
            except Exception:
                pass
        self.last_ckpt_name = _ckpt_label(paths["red"])
        self.log.info(f"Resumed step {self.global_step:,}, update {self.updates:,}, "
                      f"matches {self.matches:,}, stage {self.curriculum.stage.name}, "
                      f"pools red {len(self.pools[0].entries)} / blue {len(self.pools[1].entries)}"
                      f" (in-flight rollout/matches are not restored; new matches start)")

    def save(self, full: bool = False, reason: str = "", sync: bool = False):
        """Snapshot the training state of both brains (CPU copy, fast) and write it to disk
        (one file per brain) in a background thread so the visible match never freezes.
        ``sync=True`` for shutdown/emergencies."""
        try:
            for brain, m in zip(BRAINS, self.models):
                for p in m.parameters():
                    if not torch.isfinite(p).all():
                        self.log.error(f"{brain} brain has non-finite weights - checkpoint "
                                       f"NOT saved")
                        return
            payloads = {b: _to_cpu(self._payload(k)) for k, b in enumerate(BRAINS)}
        except Exception as e:
            self.log.error(f"Checkpoint snapshot FAILED: {type(e).__name__}: {e}")
            return
        step = self.global_step
        self._join_save()

        def work():
            try:
                paths = self.ckpt.save(payloads, step, full=full)
                self.last_ckpt_name = _ckpt_label(paths["red"])
                self.log.info(f"Checkpoint saved: {paths['red']} + {os.path.basename(paths['blue'])}"
                              + (f" ({reason})" if reason else ""))
            except Exception as e:
                self.log.error(f"Checkpoint save FAILED: {type(e).__name__}: {e}")

        if sync:
            work()
        else:
            self._save_thread = threading.Thread(target=work, name="checkpoint-writer")
            self._save_thread.start()

    def _join_save(self):
        t = getattr(self, "_save_thread", None)
        if t is not None and t.is_alive():
            t.join()
        self._save_thread = None

    # =====================================================================================
    # schedules
    # =====================================================================================
    def _frac(self) -> float:
        return min(1.0, self.global_step / max(1, self.cfg.ppo.lr_anneal_steps))

    def _lr(self) -> float:
        c = self.cfg.ppo
        return c.lr + (c.lr_min - c.lr) * self._frac()

    def _ent_coef(self) -> float:
        c = self.cfg.ppo
        return c.entropy_coef + (c.entropy_coef_min - c.entropy_coef) * self._frac()

    def _ks_coef(self) -> float:
        c = self.cfg.ppo
        if c.kickstart_steps <= 0:
            return 0.0
        return max(0.0, c.kickstart_coef * (1.0 - self.global_step / c.kickstart_steps))

    # =====================================================================================
    # league / match configuration
    # =====================================================================================
    def _choose_match(self):
        """ctrl[t] for each team t: (LEARNER, None) = brain t learns, (POOL, id) = frozen
        snapshot from pools[t] (an older version of brain t), (SCRIPTED, None)."""
        st = self.curriculum.stage
        cfg = self.cfg
        side = int(self.rng.integers(2))             # learning brain if not a rival match
        r = self.rng.random()
        if r < st.self_play_prob:
            opp = (LEARNER, None)                     # red brain vs blue brain, both learn
        elif r < st.self_play_prob + st.scripted_prob:
            opp = (SCRIPTED, None)
        else:
            e = self.pools[1 - side].sample(self.rng)     # history of the rival brain
            if e is not None:
                opp = (POOL, e["id"])
            else:   # empty pool (early training): fall back to the other opponent types
                opp = (SCRIPTED, None) if (st.scripted_prob > 0 or st.self_play_prob == 0)                     else (LEARNER, None)
        ctrl = [None, None]
        ctrl[side] = (LEARNER, None)
        ctrl[1 - side] = opp
        ks = self._ks_coef() > 0
        mc = {"team_control": ["scripted" if c[0] == SCRIPTED else "policy" for c in ctrl],
              "scripted_skill": [st.scripted_skill, st.scripted_skill],
              "want_teacher": [ks and c[0] == LEARNER for c in ctrl],
              "half_duration_s": st.half_duration_s, "offside": st.offside, "fouls": st.fouls,
              "individual_weight": cfg.reward.individual_weight * st.individual_weight,
              "shape_mult": st.shape_mult}
        return mc, ctrl

    @staticmethod
    def _ctrl_label(c, side: int) -> str:
        if c[0] == LEARNER:
            return f"{BRAINS[side]} brain (learning)"
        if c[0] == SCRIPTED:
            return "scripted AI"
        return f"historical {BRAINS[side]} #{c[1]}"

    @staticmethod
    def _opp_type(c) -> str:
        return {LEARNER: "rival", SCRIPTED: "scripted", POOL: "pool"}[c[0]]

    def _record_result(self, ctrl, info):
        s = info["summary"]
        self.matches += 1
        learner_sides = [t for t in range(2) if ctrl[t][0] == LEARNER]
        for side in learner_sides:
            opp_c = ctrl[1 - side]
            opp_type = self._opp_type(opp_c)
            gf, ga = s[f"t{side}_goals"], s[f"t{1 - side}_goals"]
            res = 0 if gf > ga else (1 if gf == ga else 2)
            self.results[side][opp_type][res] += 1
            if opp_type == "scripted":
                self.curriculum.recent_vs_scripted.append([1.0, 0.5, 0.0][res])
            elif opp_type == "pool":
                self.pools[1 - side].record(opp_c[1], gf, ga)
        side = learner_sides[int(self.rng.integers(len(learner_sides)))]
        self.recent.append((s, side, self._opp_type(ctrl[1 - side])))
        if info.get("reward_log"):
            self.recent_rewards.append(info["reward_log"][side])

    # =====================================================================================
    # main loop
    # =====================================================================================
    def train(self):
        cfg = self.cfg
        E = cfg.train.num_envs
        T_ = cfg.ppo.rollout_len
        S = 2 * E
        self.log.info(f"Environments: {E} ({cfg.train.num_workers} worker processes + env 0 "
                      f"visible in the main process) | rollout {T_} steps x {S} team slots")
        self.log.info(f"Curriculum stage: {self.curriculum.stage.name} | kickstart coef "
                      f"{self._ks_coef():.3f} | entropy coef {self._ent_coef():.4f}")
        self.vec = VecEnv(cfg, E, cfg.train.num_workers, cfg.train.seed + 7919 * (self.updates + 1))
        self.vec.env0.record_frames = self.renderer is not None
        buf = RolloutBuffer(T_, S, self.device)
        slot_team = torch.arange(S, device=self.device) % 2      # slot 2e+k = team k
        self._team_mask = [slot_team == k for k in range(2)]
        # initial match assignment
        self.ctrl, self.next_ctrl = [], []
        obs_list = []
        for i in range(E):
            mc, ctrl = self._choose_match()
            obs_list.append(self.vec.configure_now(i, mc))
            self.ctrl.append(ctrl)
            mc2, ctrl2 = self._choose_match()
            self.vec.set_next_config(i, mc2)
            self.next_ctrl.append(ctrl2)
            if self.renderer:
                self.renderer.pump()
        from .vec_env import stack_obs
        obs = stack_obs(obs_list)
        coach_tick = np.ones(E, dtype=bool)
        self._obs_ref, self._tick_ref = obs, coach_tick
        t_log = time.time()
        steps_at_log = self.global_step
        t_start = time.time()
        try:
            while not self._stop and self.global_step < cfg.train.total_steps:
                stage_changed = self.curriculum.update(self.global_step)
                if stage_changed:
                    self.log.info(f"Curriculum stage now {self.curriculum.stage.name}; "
                                  f"new matches use its settings")
                t_roll = time.time()
                for t in range(T_):
                    obs, coach_tick = self._rollout_step(buf, t, obs, coach_tick)
                    self._obs_ref, self._tick_ref = obs, coach_tick
                    if self._stop or (self.renderer and self.renderer.quit_requested):
                        self._stop = True
                        break
                if self._stop:
                    break
                roll_time = time.time() - t_roll
                tick = self._display_tick if self.renderer else (lambda: None)
                tick()
                # bootstrap values and advantages
                ob = obs_to_torch(obs, self.device)
                vs, vts = [], []
                with torch.no_grad(), torch.autocast(device_type=self.device.type,
                                                     dtype=torch.bfloat16, enabled=self.amp):
                    for k in range(2):
                        v, vt = self.models[k].critic(_team_slots(ob, k))
                        vs.append(self.vnorms_p[k].denormalize(v.float()))
                        vts.append(self.vnorms_t[k].denormalize(vt.float()))
                buf.compute_gae(_interleave(*vs), _interleave(*vts), cfg.ppo.gamma,
                                cfg.ppo.gae_lambda)
                tick()
                stats = []
                for k in range(2):                       # each brain learns from its own slots
                    for g in self.opts[k].param_groups:
                        g["lr"] = self._lr()
                    t_upd = time.time()
                    self.models[k].train()
                    st = ppo_update(self.models[k], self.opts[k], buf, self.vnorms_p[k],
                                    self.vnorms_t[k], cfg.ppo, self._ent_coef(), self._ks_coef(),
                                    self.amp, pump=self._display_tick if self.renderer else None,
                                    valid=buf.learner & self._team_mask[k])
                    self.models[k].eval()
                    tick()
                    st.update(rollout_s=roll_time, update_s=time.time() - t_upd,
                              lr=self._lr(), ent_coef=self._ent_coef(), ks_coef=self._ks_coef())
                    stats.append(st)
                self.updates += 1
                self.last_update_stats = stats
                self._after_update()
                if time.time() - t_log >= cfg.train.log_interval_s:
                    sps = (self.global_step - steps_at_log) / (time.time() - t_log)
                    self._log(stats, sps)
                    t_log, steps_at_log = time.time(), self.global_step
                self._poll_eval()
        except KeyboardInterrupt:
            self.log.warning("KeyboardInterrupt - saving checkpoint and exiting")
        except Exception:
            self.log.error("Training crashed:\n" + traceback.format_exc())
            self.save(reason="emergency save after exception", sync=True)
            self._shutdown()
            raise
        self.save(reason="shutdown", sync=True)
        self._shutdown()
        self.log.info(f"Training stopped at step {self.global_step:,} after "
                      f"{(time.time() - t_start) / 60:.1f} min")

    def _shutdown(self):
        self._join_save()
        try:
            if getattr(self, "vec", None):
                self.vec.close()
        except Exception:
            pass
        if self._eval_proc is not None and self._eval_proc.is_alive():
            self._eval_proc.join(timeout=1)
        if self.renderer:
            self.renderer.close()

    # -------------------------------------------------------------------------------------
    def _rollout_step(self, buf: RolloutBuffer, t: int, obs, coach_tick):
        E = self.cfg.train.num_envs
        dev = self.device
        ob = obs_to_torch(obs, dev)
        learner_np = np.array([self.ctrl[e][k][0] == LEARNER for e in range(E) for k in range(2)])
        learner = torch.from_numpy(learner_np).to(dev, non_blocking=True)
        if self.policies is None:
            self.policies = [GraphedPolicy(self.models[k], _team_slots(ob, k)) for k in range(2)]
            self.log.info("Rollout inference: " + ("CUDA graph" if self.policies[0].graph
                                                   is not None else "eager") + " (red + blue)")
        outs = [self.policies[k](_team_slots(ob, k)) for k in range(2)]   # fixed shapes
        actions = _interleave(outs[0]["actions"], outs[1]["actions"])
        coach = _interleave(outs[0]["coach"], outs[1]["coach"])
        buf.logp[t] = _interleave(outs[0]["logp"], outs[1]["logp"])
        buf.coach_logp[t] = _interleave(outs[0]["coach_logp"], outs[1]["coach_logp"])
        buf.values[t] = _interleave(*[self.vnorms_p[k].denormalize(outs[k]["value"])
                                      for k in range(2)])
        buf.team_values[t] = _interleave(*[self.vnorms_t[k].denormalize(outs[k]["team_value"])
                                           for k in range(2)])
        groups = defaultdict(list)
        for e in range(E):
            for k in range(2):
                if self.ctrl[e][k][0] == POOL:
                    groups[(k, self.ctrl[e][k][1])].append(2 * e + k)
        if groups:
            with torch.no_grad():
                for (k, pid), idx in groups.items():
                    actor = self.pools[k].get_model(pid) or self.models[k].actor
                    idx_t = torch.tensor(idx, device=dev)
                    logits, clog = actor({kk: v[idx_t] for kk, v in ob.items()})
                    actions[idx_t] = _gumbel_sample(logits.float())
                    coach[idx_t] = _gumbel_sample(clog.float())
        for k, v in ob.items():
            buf.obs[k][t] = v
        buf.actions[t] = actions
        buf.coach[t] = coach
        buf.learner[t] = learner
        tick = torch.from_numpy(np.repeat(coach_tick, 2)).to(dev, non_blocking=True)
        buf.coach_tick[t] = tick & learner
        act_np = actions.view(E, 22).cpu().numpy()
        coach_np = coach.view(E, 2).cpu().numpy()

        hook = self._render_hook if self.renderer else None
        obs, rew, team_rew, dones, infos = self.vec.step(act_np, coach_np, local_hook=hook)
        buf.rewards[t] = torch.from_numpy(rew.reshape(2 * E, 11)).to(dev, non_blocking=True)
        buf.team_rew[t] = torch.from_numpy(team_rew.reshape(2 * E)).to(dev, non_blocking=True)
        buf.dones[t] = torch.from_numpy(np.repeat(dones, 2).astype(np.float32)).to(
            dev, non_blocking=True)
        self.global_step += E
        new_tick = np.array([inf["coach_tick_next"] for inf in infos])
        for e in np.nonzero(dones)[0]:
            self._record_result(self.ctrl[e], infos[e])
            self.ctrl[e] = self.next_ctrl[e]
            mc, ctrl = self._choose_match()
            self.vec.set_next_config(int(e), mc)
            self.next_ctrl[e] = ctrl
        return obs, new_tick

    def _display_tick(self):
        """Keep the visible match playing while the PPO update runs (display only: these
        steps are not used for training). Called between update minibatches."""
        r = self.renderer
        env = self.vec.env0
        if r.paused or not r.display_due(env.phys.dt * env.phys.substeps):
            r.handle_events(env)
            if r.quit_requested:
                self._stop = True
            return
        dev = self.device
        obs = self._obs_ref
        tob = obs_to_torch({k: v[0:1] for k, v in obs.items()}, dev)      # (2, ...)
        acts = np.zeros((2, 11), dtype=np.int64)
        coach = np.zeros(2, dtype=np.int64)
        with torch.no_grad(), torch.autocast(device_type=dev.type, dtype=torch.bfloat16,
                                             enabled=self.amp):
            for k in range(2):
                c = self.ctrl[0][k]
                if c[0] == SCRIPTED:
                    continue
                actor = self.models[k].actor if c[0] == LEARNER else \
                    (self.pools[k].get_model(c[1]) or self.models[k].actor)
                logits, clog = actor({kk: vv[k:k + 1] for kk, vv in tob.items()})
                acts[k] = _gumbel_sample(logits.float())[0].cpu().numpy()
                coach[k] = int(_gumbel_sample(clog.float())[0])
        o, _, _, done, info = self.vec.local.step(acts.reshape(22), coach)
        for key in obs:
            obs[key][0] = np.stack([o[0][key], o[1][key]])
        self._tick_ref[0] = info["coach_tick_next"]
        if done:
            self._record_result(self.ctrl[0], info)
            self.ctrl[0] = self.next_ctrl[0]
            mc, ctrl = self._choose_match()
            self.vec.set_next_config(0, mc)
            self.next_ctrl[0] = ctrl
        r.after_step(env, self._hud(), allow_sleep=False)
        if r.quit_requested:
            self._stop = True

    def _render_hook(self):
        env = self.vec.env0
        hud = self._hud()
        self.renderer.after_step(env, hud)
        if self.renderer.quit_requested:
            self._stop = True

    def _hud(self) -> dict:
        key = (self.updates, self.matches)
        if getattr(self, "_hud_key", None) == key:
            self._hud_cache["step"] = self.global_step
            self._hud_cache["controllers"] = [self._ctrl_label(c, k)
                                              for k, c in enumerate(self.ctrl[0])]
            return self._hud_cache
        self._hud_key = key
        self._hud_cache = self._build_hud()
        return self._hud_cache

    def _build_hud(self) -> dict:
        st = self.last_update_stats
        agg = self._recent_agg(50)
        hud = {"mode": "TRAINING (red brain vs blue brain, MAPPO)", "step": self.global_step,
               "episode": self.matches, "update": self.updates,
               "controllers": [self._ctrl_label(c, k) for k, c in enumerate(self.ctrl[0])],
               "stage": f"Stage: {self.curriculum.stage.name}",
               "checkpoint": f"Checkpoint: {self.last_ckpt_name}",
               "device": f"Device: {device_label(self.device)}"}
        if agg:
            hud["recent"] = [
                "Last 50 matches (learner):",
                f" goals {agg.get('L_goals', 0):.2f}-{agg.get('O_goals', 0):.2f}  "
                f"poss {100 * agg.get('L_possession', 0):.0f}%",
                f" pass acc {100 * agg.get('L_pass_acc', 0):.0f}%  "
                f"shots {agg.get('L_shots', 0):.1f}"]
        w = self.results[0].get("rival")
        if w and sum(w):
            hud["winrate"] = f"Red vs Blue W/D/L: {w[0]}/{w[1]}/{w[2]}"
        if any(st):
            hud["loss"] = "KL " + " ".join(f"{b[0].upper()} {x.get('kl', 0):.4f}"
                                           for b, x in zip(BRAINS, st))
        if self.device.type == "cuda":
            hud["gpu_mem"] = f"GPU mem: {torch.cuda.memory_allocated() / 2 ** 20:.0f} MB"
        return hud

    def _recent_agg(self, n: int) -> dict:
        items = list(self.recent)[-n:]
        if not items:
            return {}
        return aggregate([s for s, _, _ in items], [side for _, side, _ in items])

    # -------------------------------------------------------------------------------------
    def _after_update(self):
        cfg = self.cfg
        if self.global_step >= self.next_snapshot:
            for k in range(2):
                self.pools[k].add_snapshot(self.models[k].actor, self.global_step)
            self.next_snapshot += cfg.league.snapshot_interval
        ci, fi = cfg.checkpoint.interval, cfg.checkpoint.full_interval
        if self.global_step >= self.next_full:
            self.save(full=True, reason="full")
        elif self.global_step >= self.next_ckpt:
            self.save()
        self.next_full = (self.global_step // fi + 1) * fi if self.global_step >= self.next_full             else self.next_full
        self.next_ckpt = (self.global_step // ci + 1) * ci if self.global_step >= self.next_ckpt             else self.next_ckpt
        if self.global_step >= self.next_eval:
            self._launch_eval()
            while self.next_eval <= self.global_step:
                self.next_eval += cfg.train.eval_interval

    def _launch_eval(self):
        if self._eval_proc is not None and self._eval_proc.is_alive():
            return
        paths = self.ckpt.last_saved
        if not paths:
            return
        from .evaluate import background_eval
        ctx = mp.get_context("spawn")
        self._eval_proc = ctx.Process(target=background_eval, daemon=True,
                                      args=(paths, self.eval_path, self.cfg.train.eval_matches,
                                            self.cfg.train.eval_half_duration_s,
                                            int(self.global_step % 100000)))
        self._eval_proc.start()
        self.log.info(f"Background evaluation started ({self.cfg.train.eval_matches} deterministic "
                      f"matches per brain vs scripted AI, checkpoint "
                      f"{_ckpt_label(paths['red'])})")

    def _poll_eval(self):
        if not os.path.exists(self.eval_path):
            return
        try:
            with open(self.eval_path, encoding="utf-8") as f:
                lines = f.read().splitlines()
        except OSError:
            return
        import json
        for line in lines[self._eval_seen:]:
            try:
                r = json.loads(line)
            except ValueError:
                continue
            k = BRAINS.index(r["brain"]) if r.get("brain") in BRAINS else 0
            self.log.info(f"EVAL {BRAINS[k]} brain @ step {int(r.get('step', 0)):,} vs "
                          f"{r.get('opponent')}: points "
                          f"{r.get('points', 0):.2f} | goals {r.get('L_goals', 0):.2f}-"
                          f"{r.get('O_goals', 0):.2f} | xG {r.get('L_xg', 0):.2f}-"
                          f"{r.get('O_xg', 0):.2f} | pass acc {100 * r.get('L_pass_acc', 0):.0f}%"
                          f" | possession {100 * r.get('L_possession', 0):.0f}%")
            best = self.best_eval[k]
            if best is None or r.get("points", 0) > best.get("points", -1):
                self.best_eval[k] = r
        self._eval_seen = len(lines)

    # -------------------------------------------------------------------------------------
    def _log(self, stats: List[dict], sps: float):
        agg = self._recent_agg(100)
        lg = self.log
        lg.info("-" * 72)
        lg.info(f"Step: {fmt_int(self.global_step)} | Update: {fmt_int(self.updates)} | Matches: "
                f"{fmt_int(self.matches)} | {sps:,.0f} env-steps/s "
                f"({sps * 22:,.0f} agent-decisions/s) | stage {self.curriculum.stage.name}")
        if agg:
            lg.info(f"Goals (learner-opp): {agg.get('L_goals', 0):.2f}-{agg.get('O_goals', 0):.2f}"
                    f" | xG {agg.get('L_xg', 0):.2f}-{agg.get('O_xg', 0):.2f} | Shots "
                    f"{agg.get('L_shots', 0):.1f} (on target {agg.get('L_shots_on_target', 0):.1f})"
                    f" | Possession {100 * agg.get('L_possession', 0):.0f}%")
            lg.info(f"Pass accuracy: {100 * agg.get('L_pass_acc', 0):.0f}% ({agg.get('L_passes', 0):.1f}"
                    f" passes, {agg.get('L_progressive_passes', 0):.1f} progressive) | turnovers "
                    f"{agg.get('L_turnovers', 0):.1f} | interceptions {agg.get('L_interceptions', 0):.1f}"
                    f" | tackles won {agg.get('L_tackles_won', 0):.1f} | pressing "
                    f"{agg.get('L_pressing_events', 0):.0f}s | box entries {agg.get('L_box_entries', 0):.1f}")
            lg.info(f"Shape: compactness {agg.get('L_compactness', 0):.1f}m width "
                    f"{agg.get('L_width', 0):.1f}m length {agg.get('L_length', 0):.1f}m | fouls "
                    f"{agg.get('L_fouls', 0):.1f} offsides {agg.get('L_offsides', 0):.1f} | "
                    f"counters {agg.get('L_counter_attacks', 0):.1f} | def. errors "
                    f"{agg.get('L_defensive_errors', 0):.1f}")
        if self.recent_rewards:
            comp = {k: np.mean([r[k] for r in self.recent_rewards]) for k in REWARD_COMPONENTS}
            lg.info("Reward/match per learner player: total {:+.2f} | ".format(sum(comp.values())) +
                    " ".join(f"{k} {v:+.2f}" for k, v in comp.items() if abs(v) > 5e-3))
        for k, brain in enumerate(BRAINS):
            res = " | ".join(f"vs {o}: W{v[0]} D{v[1]} L{v[2]}" for o, v in self.results[k].items())
            if res:
                lg.info(f"{brain.capitalize():4s} results: {res} | pool size "
                        f"{len(self.pools[k].entries)}")
        for brain, st in zip(BRAINS, stats):
            lg.info(f"PPO {brain:4s}: pg {st.get('pg', 0):+.4f} vf {st.get('vf', 0):.4f} ent "
                    f"{st.get('ent', 0):.3f} kl {st.get('kl', 0):.4f} clip {st.get('clip', 0):.3f}"
                    f" coach_ent {st.get('coach_ent', 0):.2f} ks {st.get('ks', 0):.3f}"
                    f"(x{st.get('ks_coef', 0):.2f}) | samples {st.get('samples', 0)} | lr "
                    f"{st.get('lr', 0):.2e} | rollout {st.get('rollout_s', 0):.1f}s update "
                    f"{st.get('update_s', 0):.1f}s")
        if self.device.type == "cuda":
            lg.info(f"GPU: {torch.cuda.get_device_name(0)} | mem alloc "
                    f"{torch.cuda.memory_allocated() / 2 ** 20:.0f} MB, peak "
                    f"{torch.cuda.max_memory_allocated() / 2 ** 20:.0f} MB | "
                    f"last checkpoint: {self.last_ckpt_name}")
        rec = {"step": self.global_step, "update": self.updates, "matches": self.matches,
               "sps": sps, "stage": self.curriculum.stage.name,
               **{f"ppo_{b}_{k}": v for b, st in zip(BRAINS, stats) for k, v in st.items()},
               **agg}
        for b, results in zip(BRAINS, self.results):
            for k, v in results.items():
                rec[f"res_{b}_{k}"] = v
        self.metrics.write(rec)


def _team_slots(ob: Dict[str, torch.Tensor], k: int) -> Dict[str, torch.Tensor]:
    """Observations of team k only (slot 2e+k) -> (E, ...)."""
    return {key: v[k::2] for key, v in ob.items()}


def _interleave(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Inverse of _team_slots: red rows to even slots, blue rows to odd slots."""
    out = torch.empty((2 * a.shape[0],) + tuple(a.shape[1:]), dtype=a.dtype, device=a.device)
    out[0::2] = a
    out[1::2] = b
    return out


def _ckpt_label(path: str) -> str:
    """checkpoint_step_X_red.pt -> checkpoint_step_X (red+blue)."""
    name = os.path.basename(path)
    for suffix in ("_red.pt", "_blue.pt"):
        if name.endswith(suffix):
            return name[:-len(suffix)] + " (red+blue)"
    return name


def _to_cpu(obj):
    """Deep copy of a checkpoint payload with every tensor moved to CPU (thread-safe snapshot)."""
    if torch.is_tensor(obj):
        return obj.detach().to("cpu", copy=True)
    if isinstance(obj, dict):
        return {k: _to_cpu(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return type(obj)(_to_cpu(v) for v in obj)
    return obj
