"""Player action space.

Each player picks one discrete action per decision (5 Hz). The action space is hybrid:

* primitive movement: STAND and 8 directions (in the team frame, so 'E' is always forward).
  When the player has the ball, directional moves are dribbles.
* tactical movement options whose *target* is computed by the tactical layer and executed by
  the low-level controller: TO_ANCHOR, PRESS, MARK, COVER, INTERCEPT, SUPPORT, RUN_BEHIND.
  The policy decides *which* behaviour is right in the situation - that is the learned
  decision; the controller only runs to the point.
* ball actions: TACKLE, SHOOT, CLEAR and a pointer over teammates for PASS_FEET / PASS_THROUGH.
  Pass targets are pre-evaluated (success probability, progress, threat) and the evaluation
  is part of the observation, but the choice of receiver is made by the policy.

Invalid actions are masked out (e.g. SHOOT without the ball, TACKLE out of range).
"""
from __future__ import annotations

import numpy as np

STAND = 0
MOVE_START = 1                 # 1..8
NUM_DIRS = 8
TO_ANCHOR = 9
PRESS = 10
MARK = 11
COVER = 12
INTERCEPT = 13
SUPPORT = 14
RUN_BEHIND = 15
TACKLE = 16
SHOOT = 17
CLEAR = 18
NUM_BASE = 19
TEAM_SIZE = 11
PASS_FEET_START = NUM_BASE                   # 19..29
PASS_THROUGH_START = NUM_BASE + TEAM_SIZE    # 30..40
NUM_ACTIONS = NUM_BASE + 2 * TEAM_SIZE       # 41

_ang = np.arange(NUM_DIRS) * (2 * np.pi / NUM_DIRS)
DIRECTIONS = np.stack([np.cos(_ang), np.sin(_ang)], axis=1)   # team frame, index 0 = forward

MOVEMENT_OPTIONS = (TO_ANCHOR, PRESS, MARK, COVER, INTERCEPT, SUPPORT, RUN_BEHIND)
KICK_ACTIONS = (SHOOT, CLEAR)


def action_name(a: int) -> str:
    names = {STAND: "STAND", TO_ANCHOR: "ANCHOR", PRESS: "PRESS", MARK: "MARK", COVER: "COVER",
             INTERCEPT: "INTERCEPT", SUPPORT: "SUPPORT", RUN_BEHIND: "RUN", TACKLE: "TACKLE",
             SHOOT: "SHOOT", CLEAR: "CLEAR"}
    if a in names:
        return names[a]
    if MOVE_START <= a < MOVE_START + NUM_DIRS:
        return f"MOVE{a - MOVE_START}"
    if PASS_FEET_START <= a < PASS_THROUGH_START:
        return f"PASS>{a - PASS_FEET_START}"
    if PASS_THROUGH_START <= a < NUM_ACTIONS:
        return f"THRU>{a - PASS_THROUGH_START}"
    return f"?{a}"


def is_pass(a) -> np.ndarray:
    return (np.asarray(a) >= PASS_FEET_START) & (np.asarray(a) < NUM_ACTIONS)


def is_kick(a) -> np.ndarray:
    a = np.asarray(a)
    return is_pass(a) | (a == SHOOT) | (a == CLEAR)


def pass_target(a: int):
    """(teammate_index, kind) for a pass action; kind 0 = feet, 1 = through."""
    if PASS_FEET_START <= a < PASS_THROUGH_START:
        return a - PASS_FEET_START, 0
    return a - PASS_THROUGH_START, 1
