"""Roles and data-driven formations.

A formation is a list of 11 slots. Each slot declares its role and how it sits in the two
reference shapes the tactical manager blends between:

* **defensive shape** (compact block):   (line_def, lat_def)
* **attacking shape** (e.g. 4-4-2 -> 2-3-5): (line_att, dx_att, lat_att)

``line`` indexes the tactical lines (0 = goal, 1 = defence, 2 = midfield, 3 = attack) whose
x-positions are computed dynamically by the tactical manager from ball position, phase and
the coach's instruction. ``lat`` is a fraction of the half-width (+ = team-frame left).
New formations only need a new slot table; nothing else in the code is formation-specific.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import numpy as np

# ---- roles -----------------------------------------------------------------------------
GK, CB, FB, CM, WM, ST = range(6)
NUM_ROLES = 6
ROLE_NAMES = ["GK", "CB", "FB", "CM", "WM", "ST"]
ROLE_GROUP = {GK: "GK", CB: "DEF", FB: "DEF", CM: "MID", WM: "MID", ST: "ATT"}
# How strictly a role is expected to hold its tactical zone (metres of tolerance)
ROLE_ZONE_TOLERANCE = {GK: 6.0, CB: 7.0, FB: 9.0, CM: 10.0, WM: 11.0, ST: 12.0}


@dataclass(frozen=True)
class Slot:
    name: str
    role: int
    number: int
    line_def: int
    lat_def: float
    line_att: int
    dx_att: float
    lat_att: float
    dx_def: float = 0.0


FORMATIONS: Dict[str, List[Slot]] = {
    # 4-4-2: attacks as a 2-3-5 (FBs join midfield line, wide mids + 1 CM join the front)
    "4-4-2": [
        Slot("GK", GK, 1, 0, 0.00, 0, 0.0, 0.00),
        Slot("RB", FB, 2, 1, -0.80, 2, -2.0, -0.90),
        Slot("RCB", CB, 5, 1, -0.24, 1, 0.0, -0.34),
        Slot("LCB", CB, 4, 1, 0.24, 1, 0.0, 0.34),
        Slot("LB", FB, 3, 1, 0.80, 2, -2.0, 0.90),
        Slot("RM", WM, 7, 2, -0.72, 3, -3.0, -0.88),
        Slot("RCM", CM, 6, 2, -0.20, 2, -4.0, -0.06),
        Slot("LCM", CM, 8, 2, 0.20, 3, -9.0, 0.28),
        Slot("LM", WM, 11, 2, 0.72, 3, -3.0, 0.88),
        Slot("RS", ST, 9, 3, -0.16, 3, 1.0, -0.22),
        Slot("LS", ST, 10, 3, 0.16, 3, 0.0, 0.26, dx_def=-4.0),
    ],
    # 4-3-3 (for experimentation; changes the 4-4-2 role composition)
    "4-3-3": [
        Slot("GK", GK, 1, 0, 0.00, 0, 0.0, 0.00),
        Slot("RB", FB, 2, 1, -0.80, 2, -2.0, -0.92),
        Slot("RCB", CB, 5, 1, -0.24, 1, 0.0, -0.36),
        Slot("LCB", CB, 4, 1, 0.24, 1, 0.0, 0.36),
        Slot("LB", FB, 3, 1, 0.80, 2, -2.0, 0.92),
        Slot("DM", CM, 6, 2, 0.00, 2, -6.0, 0.00, dx_def=-5.0),
        Slot("RCM", CM, 8, 2, -0.30, 3, -10.0, -0.30),
        Slot("LCM", CM, 10, 2, 0.30, 3, -10.0, 0.30),
        Slot("RW", WM, 7, 3, -0.70, 3, -1.0, -0.88, dx_def=-8.0),
        Slot("ST", ST, 9, 3, 0.00, 3, 1.0, 0.00),
        Slot("LW", WM, 11, 3, 0.70, 3, -1.0, 0.88, dx_def=-8.0),
    ],
}


class Formation:
    """Vectorised view of a formation's slot table."""

    def __init__(self, name: str = "4-4-2"):
        if name not in FORMATIONS:
            raise ValueError(f"Unknown formation {name!r}; available: {list(FORMATIONS)}")
        self.name = name
        self.slots = FORMATIONS[name]
        if len(self.slots) != 11:
            raise ValueError("A formation must define exactly 11 slots")
        if sum(s.role == GK for s in self.slots) != 1:
            raise ValueError("A formation must contain exactly one goalkeeper")
        self.roles = np.array([s.role for s in self.slots], dtype=np.int64)
        self.numbers = np.array([s.number for s in self.slots], dtype=np.int64)
        self.line_def = np.array([s.line_def for s in self.slots], dtype=np.int64)
        self.lat_def = np.array([s.lat_def for s in self.slots], dtype=np.float64)
        self.line_att = np.array([s.line_att for s in self.slots], dtype=np.int64)
        self.dx_att = np.array([s.dx_att for s in self.slots], dtype=np.float64)
        self.lat_att = np.array([s.lat_att for s in self.slots], dtype=np.float64)
        self.dx_def = np.array([s.dx_def for s in self.slots], dtype=np.float64)
        self.gk_index = int(np.where(self.roles == GK)[0][0])
        self.names = [s.name for s in self.slots]

    def kickoff_positions(self, half_width: float, half_length: float) -> np.ndarray:
        """Team-frame positions for a kickoff (everyone in own half)."""
        line_x = np.array([-half_length + 1.5, -30.0, -15.0, -2.5])
        pos = np.zeros((11, 2))
        pos[:, 0] = line_x[self.line_def] + np.minimum(self.dx_def, 0.0)
        pos[:, 1] = self.lat_def * half_width * 0.85
        pos[:, 0] = np.minimum(pos[:, 0], -1.0)
        return pos

    def role_counts(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for r in self.roles:
            g = ROLE_GROUP[int(r)]
            out[g] = out.get(g, 0) + 1
        return out
