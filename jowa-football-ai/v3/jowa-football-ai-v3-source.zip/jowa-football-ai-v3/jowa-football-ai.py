#!/usr/bin/env python
"""JOWA Football AI - 11v11 football simulation + multi-agent reinforcement learning.

    python jowa-football-ai.py                     normal mode: visible training at real-time 1x
    python jowa-football-ai.py --train             visible training at MAX speed (fast)
    python jowa-football-ai.py --train-headless    opt-in headless training (maximum speed)
    python jowa-football-ai.py --play              watch red brain vs blue brain (no exploration)
    python jowa-football-ai.py --play --blue scripted
    python jowa-football-ai.py --play --red blue   the blue brain plays the red side
    python jowa-football-ai.py --play --blue checkpoints/full/checkpoint_step_000000500000_blue.pt
    python jowa-football-ai.py --eval 10           headless deterministic evaluation
    python jowa-football-ai.py --play --red scripted --blue scripted   (sanity demo, no model)

Two independent brains are trained: red (team 0) and blue (team 1), one checkpoint file each.
Training resumes automatically from the newest valid red+blue pair in checkpoints/.
See README.md for the architecture overview.
"""
from __future__ import annotations

import argparse
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="JOWA Football AI (11v11 MAPPO)",
                                formatter_class=argparse.RawDescriptionHelpFormatter,
                                epilog=__doc__)
    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--train", action="store_true",
                      help="visible training at MAX speed (no flag = normal mode, real-time 1x)")
    mode.add_argument("--train-headless", action="store_true", help="training without window")
    mode.add_argument("--play", action="store_true", help="watch matches with the trained model")
    mode.add_argument("--eval", type=int, metavar="N", help="headless evaluation over N matches")
    p.add_argument("--red", default="latest",
                   help="red controller: latest (= red brain) | red | blue | scripted | <ckpt>")
    p.add_argument("--blue", default=None,
                   help="blue controller: latest (= blue brain) | red | blue | scripted | <ckpt> "
                        "(default: latest for --play, scripted for --eval)")
    p.add_argument("--sample", action="store_true", help="--play: sample actions (stochastic)")
    p.add_argument("--half-seconds", type=float, default=None,
                   help="simulated seconds per half (clock is displayed scaled to 45:00)")
    p.add_argument("--num-envs", type=int, default=None)
    p.add_argument("--workers", type=int, default=None)
    p.add_argument("--speed", type=float, default=None, help="visual speed (0 = MAX)")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--device", default=None, choices=["auto", "cuda", "cpu"])
    p.add_argument("--checkpoint-dir", default=None)
    p.add_argument("--checkpoint-interval", type=int, default=None)
    p.add_argument("--full-checkpoint-interval", type=int, default=None)
    p.add_argument("--total-steps", type=int, default=None)
    p.add_argument("--rollout-len", type=int, default=None)
    p.add_argument("--lr", type=float, default=None)
    p.add_argument("--formation", default=None, help="4-4-2 (default) | 4-3-3")
    p.add_argument("--no-kickstart", action="store_true",
                   help="disable the decaying imitation of the scripted teacher")
    p.add_argument("--allow-human", action="store_true",
                   help="allow taking control of a player during training "
                        "(that player's samples are excluded from learning)")
    p.add_argument("--fresh", action="store_true",
                   help="start a new run (existing checkpoints are archived, never deleted)")
    return p


def make_config(args):
    from football.config import Config
    cfg = Config()
    t, ck, pp = cfg.train, cfg.checkpoint, cfg.ppo
    if args.num_envs is not None:
        t.num_envs = args.num_envs
    if args.workers is not None:
        t.num_workers = args.workers
    if args.speed is not None:
        t.speed = args.speed
    if args.seed is not None:
        t.seed = args.seed
    if args.device is not None:
        cfg.device = args.device
    if args.checkpoint_dir is not None:
        ck.directory = args.checkpoint_dir
    if args.checkpoint_interval is not None:
        ck.interval = args.checkpoint_interval
    if args.full_checkpoint_interval is not None:
        ck.full_interval = args.full_checkpoint_interval
    if args.total_steps is not None:
        t.total_steps = args.total_steps
    if args.rollout_len is not None:
        pp.rollout_len = args.rollout_len
    if args.lr is not None:
        pp.lr = args.lr
    if args.formation is not None:
        cfg.formation.name = args.formation
    if args.no_kickstart:
        pp.kickstart_coef = 0.0
    if args.half_seconds is not None:
        cfg.rules.half_duration_s = args.half_seconds
    return cfg


def resolve_controller(spec: str, device, ckpt_dir: str, side: str):
    from football.evaluate import load_actor
    if spec == "scripted":
        return ("scripted", 1.0), "scripted AI", None
    actor, cfg, meta = load_actor(spec, device, ckpt_dir, brain=side)
    name = f"{meta['brain']} brain" if meta.get("brain") else "model"
    return actor, f"{name} @ step {meta['step']:,}", cfg


def run_play(args, cfg):
    import dataclasses
    from football.evaluate import play_match
    from football.render import Renderer
    from football.utils import device_label, select_device, setup_logging
    log = setup_logging(cfg.train.log_dir, "play")
    device = select_device(cfg.device)
    blue = args.blue or "latest"
    red_c, red_lbl, red_cfg = resolve_controller(args.red, device, cfg.checkpoint.directory, "red")
    blue_c, blue_lbl, blue_cfg = resolve_controller(blue, device, cfg.checkpoint.directory, "blue")
    base = red_cfg or blue_cfg or cfg
    half = args.half_seconds or cfg.rules.half_duration_s
    play_cfg = dataclasses.replace(base, rules=dataclasses.replace(base.rules, half_duration_s=half))
    log.info(f"PLAY: red = {red_lbl} | blue = {blue_lbl} | "
             f"{'stochastic' if args.sample else 'deterministic (no exploration)'} | "
             f"device {device_label(device)}")
    r = Renderer("JOWA Football AI 11v11 - EVALUATION", speed=cfg.train.speed if args.speed is not None
                 else 1.0, render_fps=cfg.train.render_fps, allow_human=True)
    hud = {"mode": "EVALUATION (no training)", "controllers": [red_lbl, blue_lbl],
           "device": f"Device: {device_label(device)}"}
    m = 0
    while not r.quit_requested:
        s = play_match(play_cfg, [red_c, blue_c], device, deterministic=not args.sample,
                       seed=cfg.train.seed + m, renderer=r, hud=hud)
        m += 1
        if s.get("aborted"):
            break
        log.info(f"Match {m}: RED {s['t0_goals']:.0f} - {s['t1_goals']:.0f} BLUE | xG "
                 f"{s['t0_xg']:.2f}-{s['t1_xg']:.2f} | possession {100 * s['t0_possession']:.0f}% | "
                 f"pass acc {100 * s['t0_pass_acc']:.0f}%/{100 * s['t1_pass_acc']:.0f}%")
        hud["recent"] = [f"Last result: RED {s['t0_goals']:.0f}-{s['t1_goals']:.0f} BLUE"]
        t_end = time.time() + 2.0
        while time.time() < t_end and not r.quit_requested:
            r.handle_events()
            time.sleep(0.05)
    r.close()


def run_eval(args, cfg):
    from football.evaluate import evaluate
    from football.utils import select_device, setup_logging
    log = setup_logging(cfg.train.log_dir, "eval")
    device = select_device(cfg.device)
    learner, l_lbl, l_cfg = resolve_controller(args.red, device, cfg.checkpoint.directory, "red")
    if isinstance(learner, tuple):
        raise SystemExit("--eval needs a model for --red (latest | red | blue | checkpoint path)")
    opp, o_lbl, _ = resolve_controller(args.blue or "scripted", device, cfg.checkpoint.directory,
                                       "blue")
    half = args.half_seconds or cfg.train.eval_half_duration_s
    log.info(f"EVAL: {l_lbl} vs {o_lbl}, {args.eval} matches, {half:.0f}s halves, deterministic")
    res = evaluate(l_cfg or cfg, learner, opp, args.eval, device, half, cfg.train.seed)
    keys = ["points", "L_goals", "O_goals", "L_xg", "O_xg", "L_shots", "O_shots",
            "L_shots_on_target", "L_possession", "L_pass_acc", "O_pass_acc", "L_passes",
            "L_progressive_passes", "L_turnovers", "L_interceptions", "L_tackles_won",
            "L_pressing_events", "L_box_entries", "L_fouls", "L_offsides", "L_compactness",
            "L_width", "L_length"]
    for k in keys:
        if k in res:
            log.info(f"  {k:24s} {res[k]:8.3f}")


def main():
    args = build_parser().parse_args()
    cfg = make_config(args)
    if args.play:
        return run_play(args, cfg)
    if args.eval:
        return run_eval(args, cfg)
    from football.trainer import Trainer
    headless = args.train_headless
    normal_mode = not (args.train or args.train_headless)
    if normal_mode and args.speed is None:
        cfg.train.speed = 1.0          # plain run: watch at real-time speed (keys 1-8 change it)
    if headless:
        cfg.train.render = False
    trainer = Trainer(cfg, render=not headless, fresh=args.fresh, allow_human=args.allow_human)
    trainer.train()


if __name__ == "__main__":
    main()
