#!/bin/bash
# Linux app build inside an Ubuntu 22.04 container (glibc 2.35), so the app also runs on older
# distributions (Ubuntu 22.04+, Debian 12+, Fedora 36+). Run from the host:
#   docker run --rm -v "<project>:/src:ro" -v "<out dir>:/out" ubuntu:22.04 bash /src/packaging/build_linux_docker.sh
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive UV_PYTHON_INSTALL_DIR=/opt/uv-python
apt-get update -qq
apt-get install -y -qq --no-install-recommends binutils libgomp1 python3-venv ca-certificates >/dev/null
python3 -m venv /opt/tools
/opt/tools/bin/pip install --quiet --disable-pip-version-check uv
UV=/opt/tools/bin/uv
$UV venv --python 3.12 --python-preference only-managed /opt/venv
$UV pip install --python /opt/venv/bin/python --index-url https://download.pytorch.org/whl/cpu torch==2.5.1
$UV pip install --python /opt/venv/bin/python pygame==2.6.1 numpy==2.3.5 pyinstaller
cd /src
/opt/venv/bin/python packaging/build_app.py --out /build
cp /build/*.zip /out/
ldd --version | head -1
