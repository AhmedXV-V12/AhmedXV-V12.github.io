"""Build the packaged JOWA Football AI app for the current OS (Windows or Linux).

Run it with the Python of the build environment (see packaging/README.md):

    python packaging/build_app.py --out <build dir>

Result: <build dir>/jowa-football-ai-v3-<windows|linux>-x86_64.zip, a PyInstaller one-folder
app (jowa-football-ai.exe / ELF jowa-football-ai) plus the default weights:
checkpoints/latest_red.pt and latest_blue.pt with their .sha256 files.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import stat
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
APP = "jowa-football-ai"
BRAINS = ("red", "blue")


def stage_sources(stage: str):
    if os.path.isdir(stage):
        shutil.rmtree(stage)
    shutil.copytree(os.path.join(ROOT, "football"), os.path.join(stage, "football"),
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    # the entry script has dashes in its name; the launcher imports it as a module
    shutil.copy2(os.path.join(ROOT, "jowa-football-ai.py"), os.path.join(stage, "jowa_football_ai.py"))
    shutil.copy2(os.path.join(HERE, "app_main.py"), os.path.join(stage, "app_main.py"))


def make_icon(work: str) -> str:
    from PIL import Image
    ico = os.path.join(work, "jowa.ico")
    logo = Image.open(os.path.join(ROOT, "jowa_logo.png")).convert("RGBA")
    side = max(logo.size)
    square = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    square.paste(logo, ((side - logo.width) // 2, (side - logo.height) // 2))
    square.save(ico, sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    return ico


def run_pyinstaller(stage: str, work: str, dist: str, icon: str | None):
    import PyInstaller.__main__
    args = [os.path.join(stage, "app_main.py"),
            "--name", APP, "--onedir", "--console", "--noconfirm", "--clean",
            "--paths", stage,
            "--hidden-import", "jowa_football_ai",
            "--collect-submodules", "football",
            "--distpath", dist, "--workpath", os.path.join(work, "pyi"), "--specpath", work,
            # not used by the game; keeps the download smaller
            "--exclude-module", "tkinter", "--exclude-module", "torch.utils.tensorboard",
            "--exclude-module", "matplotlib", "--exclude-module", "IPython"]
    if icon:
        args += ["--icon", icon]
    PyInstaller.__main__.run(args)


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def add_weights(app_dir: str, weights_dir: str):
    dst = os.path.join(app_dir, "checkpoints")
    os.makedirs(dst, exist_ok=True)
    for brain in BRAINS:
        src = os.path.join(weights_dir, f"latest_{brain}.pt")
        side = src + ".sha256"
        with open(side, encoding="utf-8") as f:
            expected = f.read().strip()
        if sha256(src) != expected:
            raise SystemExit(f"{src}: SHA-256 does not match {side}")
        shutil.copy2(src, dst)
        shutil.copy2(side, dst)


def make_zip(app_dir: str, zip_path: str, root_name: str):
    if os.path.exists(zip_path):
        os.remove(zip_path)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for base, dirs, files in os.walk(app_dir):
            dirs.sort()
            for name in sorted(files):
                full = os.path.join(base, name)
                arc = root_name + "/" + os.path.relpath(full, app_dir).replace(os.sep, "/")
                info = zipfile.ZipInfo.from_file(full, arc)   # keeps the exec bit on Linux
                info.compress_type = zipfile.ZIP_DEFLATED
                if not sys.platform.startswith("win"):
                    mode = os.stat(full).st_mode
                    info.external_attr = (stat.S_IMODE(mode) | stat.S_IFREG) << 16
                with open(full, "rb") as f:
                    z.writestr(info, f.read(), compresslevel=9)


def main():
    ap = argparse.ArgumentParser(description="Build the JOWA Football AI app for this OS")
    ap.add_argument("--out", required=True, help="build directory (work files, dist, zip)")
    ap.add_argument("--weights", default=os.path.join(ROOT, "checkpoints"),
                    help="folder with latest_red.pt / latest_blue.pt (+ .sha256)")
    args = ap.parse_args()

    windows = sys.platform.startswith("win")
    out = os.path.abspath(args.out)
    work = os.path.join(out, "work")
    dist = os.path.join(out, "dist")
    os.makedirs(work, exist_ok=True)

    stage = os.path.join(work, "stage")
    stage_sources(stage)
    icon = make_icon(work) if windows else None
    run_pyinstaller(stage, work, dist, icon)

    app_dir = os.path.join(dist, APP)
    add_weights(app_dir, args.weights)
    shutil.copy2(os.path.join(HERE, "README-app.txt"), os.path.join(app_dir, "README.txt"))
    if not windows:   # files copied from a Windows drive arrive as 0777
        for name in ["README.txt"] + [f"checkpoints/latest_{b}.pt{s}" for b in BRAINS
                                      for s in ("", ".sha256")]:
            os.chmod(os.path.join(app_dir, name), 0o644)

    root_name = f"{APP}-v3-{'windows' if windows else 'linux'}-x86_64"
    zip_path = os.path.join(out, root_name + ".zip")
    make_zip(app_dir, zip_path, root_name)
    print(f"\n{zip_path}  {os.path.getsize(zip_path) / 2**20:.1f} MiB")


if __name__ == "__main__":
    main()
