JOWA Football AI v3 - 11v11 football played by two AI brains
https://ahmedxv-v12.github.io/jowa-football-ai/v3/

This folder is the app plus the default weights: the red and blue brains at
52,783,408 training steps, in checkpoints/. Keep the folder together.
The app runs on the CPU. For training on an NVIDIA GPU, use the source code.


START
  Watch the red brain play the blue brain:
    Windows:  jowa-football-ai.exe --play
    Linux:    chmod +x jowa-football-ai
              ./jowa-football-ai --play

  Without options (or a double-click on Windows) the app starts in normal mode:
  a visible match at real-time speed while both brains keep training. New
  checkpoints, logs/ and screenshots/ are written into this folder.


MORE OPTIONS
  --play --blue scripted     red brain against the rule-based AI
  --play --red blue          the blue brain plays the red side
  --train                    visible training at maximum speed
  --train-headless           training without a window
  --eval 10                  10 evaluation matches against the rule-based AI
  --num-envs 4 --workers 2   fewer parallel matches while training (lighter on the CPU)
  --help                     every option


KEYS
  P               pause / resume
  1..8, + / -     speed
  O               tactical overlay (lines, anchors, pass options)
  H               stats panel
  S               screenshot
  TAB, up/down    select a player;  ENTER take control;  ESC give it back to the AI
  WASD / arrows   move;  SPACE shoot;  F pass;  T tackle
  Q               save and quit


Open source by AXV - https://ahmedxv-v12.github.io
