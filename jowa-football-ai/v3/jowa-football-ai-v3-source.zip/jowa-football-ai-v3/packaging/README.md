# Packaging the Windows / Linux app

`build_app.py` turns the project into a one-folder PyInstaller app for the OS it runs on and
zips it with the default weights (`checkpoints/latest_red.pt`, `latest_blue.pt` + `.sha256`).
`app_main.py` is the entry point: it calls `main()` of `jowa-football-ai.py` after switching to
the app's folder, and calls `multiprocessing.freeze_support()` for the training workers.
`README-app.txt` is copied into the app as `README.txt`.

The apps use the **CPU build of PyTorch** (a CUDA build would make the download several GB).
Python comes from `uv` (python-build-standalone), not the system or Microsoft Store Python.

## Windows (PowerShell)

```powershell
$B = "C:\Users\Z GAMES\Documents\football_ai\build-apps\windows"
uv venv --python 3.12 --python-preference only-managed "$B\venv"
uv pip install --python "$B\venv\Scripts\python.exe" --index-url https://download.pytorch.org/whl/cpu torch==2.5.1
uv pip install --python "$B\venv\Scripts\python.exe" pygame==2.6.1 numpy==2.3.5 pyinstaller pillow
& "$B\venv\Scripts\python.exe" packaging\build_app.py --out $B
```

## Linux (Docker, Ubuntu 22.04 container)

PyInstaller bundles some libraries of the build system (libstdc++, libgomp, ...), so the build
system's glibc is the minimum the app needs. `build_linux_docker.sh` builds inside Ubuntu 22.04
(glibc 2.35): the app runs on Ubuntu 22.04+, Debian 12+, Fedora 36+.

```powershell
docker run --rm -v "C:\Users\Z GAMES\Documents\football_ai\jowa-football-ai:/src:ro" `
  -v "C:\Users\Z GAMES\Documents\football_ai\build-apps\linux-docker:/out" `
  ubuntu:22.04 bash /src/packaging/build_linux_docker.sh
```

Output: `<out>/jowa-football-ai-v3-<windows|linux>-x86_64.zip`.

## Published

`https://axv-1.tailce0b52.ts.net/jowa-football-ai/` (server folder `/var/www/html/jowa-football-ai/`):
both ZIPs and `SHA256SUMS.txt`.
