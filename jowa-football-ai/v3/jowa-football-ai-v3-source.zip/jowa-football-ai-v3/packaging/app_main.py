"""Entry point of the packaged Windows / Linux app (PyInstaller).

Runs the same main() as jowa-football-ai.py, with the app's own folder as the working
directory: the default weights in checkpoints/ next to the executable are found wherever the
app is started from, and logs/, screenshots/ and new checkpoints are written there too.
"""
import multiprocessing
import os
import sys


def main():
    multiprocessing.freeze_support()   # training workers are spawned processes of this exe
    if getattr(sys, "frozen", False):
        os.chdir(os.path.dirname(os.path.abspath(sys.executable)))
    import jowa_football_ai            # copy of jowa-football-ai.py made by build_app.py
    jowa_football_ai.main()


if __name__ == "__main__":
    main()
