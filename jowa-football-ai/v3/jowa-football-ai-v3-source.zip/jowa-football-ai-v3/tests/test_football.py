"""Test suite for the 11v11 football AI.

Run:  python -m unittest discover -s tests -v
(or:  python tests/test_football.py)
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
import time
import tracemalloc
import unittest

import numpy as np
import torch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from football import actions as A  # noqa: E402
from football import geometry as G  # noqa: E402
from football import tactics as T  # noqa: E402
from football.checkpoint import CheckpointManager, IncompatibleCheckpoint  # noqa: E402
from football.config import ARCH_VERSION, Config  # noqa: E402
from football.engine import FootballEnv  # noqa: E402
from football.formation import CB, CM, FB, GK, ROLE_GROUP, ST, WM, Formation  # noqa: E402
from football.model import ActorCritic, GraphedPolicy  # noqa: E402
from football.observation import F, N_TOKENS, build_team_obs  # noqa: E402
from football.ppo import obs_to_torch  # noqa: E402
from football.utils import device_report, select_device  # noqa: E402

HL, HW = G.HL, G.HW


def small_cfg(half: float = 60.0) -> Config:
    cfg = Config()
    cfg.rules.half_duration_s = half
    return cfg


def open_play(env: FootballEnv, carrier: int = -1):
    """Put the env into open play (no set piece) with an optional carrier."""
    env.dead = False
    env.sp_kind = T.SP_NONE
    env.sp_team = -1
    env.sp_taker = -1
    env.double_touch = -1
    env.kick_cd[:] = 0
    env.possessor = carrier
    if carrier >= 0:
        env.poss_team = carrier // 11
        env.bpos = env.pos[carrier] + np.array([0.6 * env.attack_dir[carrier // 11], 0.0])
        env.facing[carrier] = np.array([env.attack_dir[carrier // 11], 0.0])
    env.bvel[:] = 0
    env.bz = env.bvz = 0.0
    refresh(env)


def refresh(env: FootballEnv):
    env.views = env._analyze()
    env.masks = env._build_masks()


def stand_actions(env: FootballEnv) -> np.ndarray:
    a = np.zeros(22, dtype=np.int64)
    for p in range(22):
        m = env.masks[p // 11][p % 11]
        a[p] = A.STAND if m[A.STAND] else int(np.flatnonzero(m)[0])
    return a


def clear_area(env: FootballEnv, keep: list, x_far: float = -45.0):
    """Move all players except `keep` far away (world frame), GKs to their goals' corners."""
    for p in range(22):
        if p in keep:
            continue
        env.pos[p] = np.array([x_far, -HW + 2 + (p % 11) * 1.5 + (p // 11) * 16])
        env.vel[p] = 0


# =========================================================================================
class TestTeamsAndFormation(unittest.TestCase):
    def test_22_players_11_per_team_one_gk(self):
        env = FootballEnv(small_cfg(), seed=0)
        self.assertEqual(env.pos.shape, (22, 2))
        self.assertEqual(len(env.roles), 22)
        for t in range(2):
            roles = env.roles[11 * t:11 * t + 11]
            self.assertEqual(len(roles), 11)
            self.assertEqual(int(np.sum(roles == GK)), 1)

    def test_442_role_composition(self):
        f = Formation("4-4-2")
        self.assertEqual(f.role_counts(), {"GK": 1, "DEF": 4, "MID": 4, "ATT": 2})
        self.assertEqual(sorted(set(int(r) for r in f.roles)), [GK, CB, FB, CM, WM, ST])
        self.assertEqual(len(set(f.numbers.tolist())), 11)

    def test_formation_can_change(self):
        f = Formation("4-3-3")
        self.assertEqual(sum(f.roles == GK), 1)
        cfg = small_cfg()
        cfg.formation.name = "4-3-3"
        env = FootballEnv(cfg, seed=0)
        self.assertEqual(int(np.sum(env.roles == ST)), 2)   # 1 ST per team

    def test_kickoff_positions_in_own_half(self):
        env = FootballEnv(small_cfg(), seed=1)
        for t in range(2):
            own = env.pos[11 * t:11 * t + 11] * env.attack_dir[t]
            self.assertTrue(np.all(own[:, 0] <= 0.01), own[:, 0])
            self.assertTrue(np.all(np.abs(own[:, 1]) < HW))
        # defending team outside the centre circle
        kicking = env.sp_team
        d = np.linalg.norm(env.pos[11 * (1 - kicking):11 * (1 - kicking) + 11], axis=1)
        env.step(stand_actions(env))
        d = np.linalg.norm(env.pos[11 * (1 - kicking):11 * (1 - kicking) + 11], axis=1)
        self.assertTrue(np.all(d >= 9.0), d)


class TestRules(unittest.TestCase):
    def test_ball_reset_and_kickoff(self):
        env = FootballEnv(small_cfg(), seed=2)
        self.assertTrue(env.dead)
        self.assertEqual(env.sp_kind, T.SP_KICKOFF)
        np.testing.assert_allclose(env.bpos, [0, 0])
        self.assertEqual(env.possessor, env.sp_taker)
        taker_mask = env.masks[env.sp_team][env.sp_taker % 11]
        self.assertTrue(taker_mask[A.STAND] and not taker_mask[A.SHOOT])
        # after the set-up time the taker may pass; kicking restarts play
        for _ in range(6):
            env.step(stand_actions(env))
        m = env.masks[env.sp_team][env.sp_taker % 11]
        self.assertTrue(m[A.PASS_FEET_START:].any())
        acts = stand_actions(env)
        j = int(np.flatnonzero(m[A.PASS_FEET_START:A.PASS_FEET_START + 11])[0])
        acts[env.sp_taker] = A.PASS_FEET_START + j
        env.step(acts)
        self.assertFalse(env.dead)

    def test_goal_score_and_restart(self):
        env = FootballEnv(small_cfg(), seed=3)
        open_play(env)
        gk_blue = env.gk_idx[1]
        env.pos[gk_blue] = np.array([HL - 2.0, 20.0])
        clear_area(env, keep=[gk_blue])
        env.bpos = np.array([HL - 3.0, 0.5])
        env.bvel = np.array([15.0, 0.0])
        env.last_touch, env.last_touch_team = 9, 0
        refresh(env)
        goals, rt = [], None
        for _ in range(5):
            _, rt, _, info = env.step(stand_actions(env))
            goals = [e for e in info["events"] if e[0] == "goal"]
            if goals:
                break
        self.assertEqual(len(goals), 1)
        self.assertEqual(goals[0][1], 0)
        self.assertEqual(env.score, [1, 0])
        self.assertGreater(rt[0], 0.5)
        self.assertLess(rt[1], -0.5)
        self.assertTrue(env.dead and env.sp_kind == T.SP_KICKOFF and env.sp_team == 1)
        np.testing.assert_allclose(env.bpos, [0, 0])

    def test_ball_over_crossbar_is_not_goal(self):
        env = FootballEnv(small_cfg(), seed=4)
        open_play(env)
        clear_area(env, keep=[])
        env.bpos = np.array([HL - 1.0, 0.0])
        env.bvel = np.array([15.0, 0.0])
        env.bz, env.bvz = 3.5, 0.0
        env.last_touch, env.last_touch_team = 9, 0
        refresh(env)
        for _ in range(3):
            env.step(stand_actions(env))
        self.assertEqual(env.score, [0, 0])
        self.assertEqual(env.sp_kind, T.SP_GOAL_KICK)
        self.assertEqual(env.sp_team, 1)

    def test_throw_in_and_corner(self):
        env = FootballEnv(small_cfg(), seed=5)
        open_play(env)
        clear_area(env, keep=[])
        env.bpos = np.array([0.0, HW - 0.5])
        env.bvel = np.array([0.0, 10.0])
        env.last_touch, env.last_touch_team = 3, 0
        refresh(env)
        env.step(stand_actions(env))
        self.assertEqual(env.sp_kind, T.SP_THROW_IN)
        self.assertEqual(env.sp_team, 1)
        # defender (blue) touches last over its own goal line -> corner for red
        open_play(env)
        clear_area(env, keep=[])
        env.bpos = np.array([HL - 0.5, 15.0])
        env.bvel = np.array([10.0, 0.0])
        env.last_touch, env.last_touch_team = 14, 1
        refresh(env)
        env.step(stand_actions(env))
        self.assertEqual(env.sp_kind, T.SP_CORNER)
        self.assertEqual(env.sp_team, 0)

    def test_pitch_boundaries_long_run(self):
        env = FootballEnv(small_cfg(60), seed=6)
        rng = np.random.default_rng(0)
        for _ in range(1200):
            acts = np.array([rng.choice(np.flatnonzero(env.masks[p // 11][p % 11]))
                             for p in range(22)])
            _, _, done, _ = env.step(acts)
            self.assertTrue(np.all(np.abs(env.pos[:, 0]) <= HL + 2.0 + 1e-6))
            self.assertTrue(np.all(np.abs(env.pos[:, 1]) <= HW + 2.0 + 1e-6))
            self.assertTrue(np.all(np.abs(env.bpos) <= np.array([HL + 3, HW + 3])))
            if done:
                env.reset()

    def test_offside_gives_indirect_free_kick(self):
        env = FootballEnv(small_cfg(), seed=7)
        carrier, runner = 6, 9                # red CM passes to red striker (world idx)
        open_play(env)
        clear_area(env, keep=[carrier, runner, 11 + 2, 11 + 3, env.gk_idx[1]])
        env.pos[carrier] = np.array([5.0, 0.0])
        env.pos[11 + 2] = np.array([20.0, -5.0])   # blue defenders (second-last at x=20)
        env.pos[11 + 3] = np.array([20.0, 5.0])
        env.pos[env.gk_idx[1]] = np.array([HL - 1.0, 0.0])
        env.pos[runner] = np.array([28.0, 0.0])    # beyond the second-last defender
        open_play(env, carrier)
        self.assertTrue(env.views[0].offside_pos[runner])
        acts = stand_actions(env)
        acts[carrier] = A.PASS_FEET_START + runner
        self.assertTrue(env.masks[0][carrier][acts[carrier]])
        offside = False
        for _ in range(25):
            _, _, _, info = env.step(acts)
            acts = stand_actions(env)
            if any(e[0] == "offside" for e in info["events"]):
                offside = True
                break
        self.assertTrue(offside)
        self.assertEqual(env.sp_kind, T.SP_INDIRECT)
        self.assertEqual(env.sp_team, 1)

    def test_foul_in_box_gives_penalty(self):
        env = FootballEnv(small_cfg(), seed=8)
        attacker, defender = 9, 11 + 2
        open_play(env)
        env.pos[attacker] = np.array([HL - 10.0, 0.0])
        env.pos[defender] = np.array([HL - 11.0, 0.0])      # behind the attacker
        open_play(env, attacker)
        env.facing[attacker] = np.array([1.0, 0.0])
        env._foul(defender, attacker)
        self.assertEqual(env.sp_kind, T.SP_PENALTY)
        self.assertEqual(env.sp_team, 0)
        np.testing.assert_allclose(env.bpos, [HL - 11.0, 0.0])

    def test_halftime_and_full_time(self):
        env = FootballEnv(small_cfg(10), seed=9)
        dirs = env.attack_dir.copy()
        done, n = False, 0
        while not done:
            _, _, done, info = env.step(stand_actions(env))
            n += 1
            if env.half == 1 and n < 60:
                np.testing.assert_allclose(env.attack_dir, -dirs)
        self.assertEqual(n, 100)           # 2 x 10 s at 5 Hz
        self.assertIn("match_summary", info)


class TestBallPlay(unittest.TestCase):
    def test_possession_by_control(self):
        env = FootballEnv(small_cfg(), seed=10)
        p = 5
        open_play(env)
        clear_area(env, keep=[p])
        env.pos[p] = np.array([0.0, 0.0])
        env.bpos = np.array([-6.0, 0.0])
        env.bvel = np.array([6.0, 0.0])
        refresh(env)
        for _ in range(10):
            env.step(stand_actions(env))
            if env.possessor >= 0:
                break
        self.assertEqual(env.possessor, p)
        self.assertEqual(env.poss_team, 0)

    def test_pass_completes_to_open_teammate(self):
        ok = 0
        for seed in range(8):
            env = FootballEnv(small_cfg(), seed=100 + seed)
            carrier, target = 6, 7
            open_play(env)
            clear_area(env, keep=[carrier, target])
            env.pos[carrier] = np.array([-14.0, 0.0])
            env.pos[target] = np.array([-3.0, 8.0])        # own half: cannot be offside
            open_play(env, carrier)
            acts = stand_actions(env)
            acts[carrier] = A.PASS_FEET_START + target
            self.assertTrue(env.masks[0][carrier][acts[carrier]])
            self.assertGreater(env.views[0].passes.p_feet[target], 0.7)
            for _ in range(20):
                _, _, _, info = env.step(acts)
                acts = stand_actions(env)
                if any(e[0] == "pass_complete" for e in info["events"]):
                    ok += 1
                    break
        self.assertGreaterEqual(ok, 7)

    def test_pass_evaluation_detects_blocked_lane(self):
        env = FootballEnv(small_cfg(), seed=11)
        carrier, target, blocker = 6, 7, 11 + 5
        open_play(env)
        clear_area(env, keep=[carrier, target, blocker])
        env.pos[carrier] = np.array([-10.0, 0.0])
        env.pos[target] = np.array([10.0, 0.0])
        env.pos[blocker] = np.array([0.0, 0.0])
        open_play(env, carrier)
        self.assertLess(env.views[0].passes.p_feet[target], 0.3)

    def test_shooting(self):
        results = []
        for seed in range(10):
            env = FootballEnv(small_cfg(), seed=200 + seed)
            shooter = 9
            open_play(env)
            clear_area(env, keep=[shooter, env.gk_idx[1]])
            env.pos[shooter] = np.array([HL - 12.0, 2.0])
            env.pos[env.gk_idx[1]] = np.array([HL - 1.0, 0.0])
            open_play(env, shooter)
            m = env.masks[0][shooter]
            self.assertTrue(m[A.SHOOT])
            self.assertGreater(env.views[0].shot_xg, 0.15)
            acts = stand_actions(env)
            acts[shooter] = A.SHOOT
            outcome = None
            for _ in range(20):
                _, _, _, info = env.step(acts)
                acts = stand_actions(env)
                kinds = [e[0] for e in info["events"]]
                if "goal" in kinds:
                    outcome = "goal"
                elif "save" in kinds:
                    outcome = "save"
                elif env.dead:
                    outcome = outcome or "miss"
                if outcome:
                    break
            results.append(outcome)
        self.assertTrue(all(r is not None for r in results), results)
        self.assertIn("goal", results)

    def test_shoot_masked_far_from_goal_and_for_gk(self):
        env = FootballEnv(small_cfg(), seed=12)
        open_play(env, carrier=env.gk_idx[0])
        self.assertFalse(env.masks[0][env.form.gk_index][A.SHOOT])
        env.pos[4] = np.array([-30.0, 0.0])
        open_play(env, carrier=4)
        self.assertFalse(env.masks[0][4][A.SHOOT])

    def test_every_player_always_has_a_valid_action(self):
        env = FootballEnv(small_cfg(30), seed=13)
        env.team_control = ["scripted", "scripted"]
        for _ in range(900):
            for t in range(2):
                self.assertTrue(np.all(env.masks[t].any(axis=1)))
            _, _, done, _ = env.step(np.zeros(22, dtype=np.int64))
            if done:
                env.reset()
                env.team_control = ["scripted", "scripted"]


class TestObservationsAndModel(unittest.TestCase):
    def test_observation_shapes_and_finite(self):
        env = FootballEnv(small_cfg(), seed=14)
        env.team_control = ["scripted", "scripted"]
        for _ in range(100):
            env.step(np.zeros(22, dtype=np.int64))
        for t in range(2):
            o = build_team_obs(env, t, want_teacher=True)
            self.assertEqual(o["tokens"].shape, (N_TOKENS, F))
            self.assertTrue(np.all(np.isfinite(o["tokens"])))
            self.assertEqual(o["mask"].shape, (11, A.NUM_ACTIONS))
            self.assertTrue(np.all(o["teacher"] >= 0))
            for i in range(11):
                self.assertTrue(o["mask"][i, o["teacher"][i]])

    def test_model_outputs_finite_and_respect_masks(self):
        dev = select_device("auto")
        cfg = small_cfg()
        env = FootballEnv(cfg, seed=15)
        env.team_control = ["scripted", "scripted"]
        model = ActorCritic(cfg.model).to(dev).eval()
        for _ in range(40):
            env.step(np.zeros(22, dtype=np.int64))
            batch = {k: np.stack([build_team_obs(env, 0)[k], build_team_obs(env, 1)[k]])[None]
                     for k in build_team_obs(env, 0)}
            ob = obs_to_torch(batch, dev)
            out = model.act(ob)
            for k in ("logp", "value", "team_value", "coach_logp"):
                self.assertTrue(torch.isfinite(out[k]).all(), k)
            a = out["actions"].cpu().numpy()
            m = batch["mask"][0]
            for t in range(2):
                for i in range(11):
                    self.assertTrue(m[t, i, a[t, i]])
            ev = model.evaluate(ob, out["actions"], out["coach"])
            self.assertTrue(torch.isfinite(ev["entropy"]).all())

    def test_graphed_policy_matches_eager(self):
        dev = select_device("auto")
        cfg = small_cfg()
        env = FootballEnv(cfg, seed=16)
        model = ActorCritic(cfg.model).to(dev).eval()
        batch = {k: np.stack([build_team_obs(env, 0)[k], build_team_obs(env, 1)[k]])[None]
                 for k in build_team_obs(env, 0)}
        ob = obs_to_torch(batch, dev)
        gp = GraphedPolicy(model, ob)
        out = gp(ob)
        with torch.no_grad():
            v, vt = model.critic(ob)
        self.assertTrue(torch.allclose(out["value"], v, atol=1e-3))
        m = batch["mask"][0].reshape(2, 11, -1)
        a = out["actions"].cpu().numpy().reshape(2, 11)
        for t in range(2):
            for i in range(11):
                self.assertTrue(m[t, i, a[t, i]])

    def test_cuda_detection(self):
        rep = device_report(select_device("auto"))
        self.assertEqual(rep["cuda_available"], torch.cuda.is_available())
        if torch.cuda.is_available():
            self.assertEqual(rep["device"], "cuda")
            self.assertIn("gpu_name", rep)
            self.assertGreater(rep["vram_gb"], 0)
        self.assertEqual(str(select_device("cpu")), "cpu")


class TestRewards(unittest.TestCase):
    def test_rewards_finite_and_bounded(self):
        env = FootballEnv(small_cfg(60), seed=17)
        env.team_control = ["scripted", "scripted"]
        tot = np.zeros(22)
        done = False
        while not done:
            r, rt, done, _ = env.step(np.zeros(22, dtype=np.int64))
            self.assertTrue(np.all(np.isfinite(r)) and np.all(np.isfinite(rt)))
            self.assertTrue(np.all(np.abs(r) < 3.0))
            tot += r
        self.assertTrue(np.all(np.abs(tot) < 20))

    def test_ping_pong_passing_cannot_farm_reward(self):
        """Passing back and forth between two unpressured players must not accumulate
        positive reward (potential-based shaping + decaying pass credit)."""
        env = FootballEnv(small_cfg(300), seed=18)
        a, b = 2, 3                      # two red defenders
        open_play(env)
        clear_area(env, keep=[a, b], x_far=40.0)
        env.pos[env.gk_idx[1]] = np.array([HL - 1.0, 0.0])
        env.pos[a] = np.array([-30.0, -6.0])
        env.pos[b] = np.array([-30.0, 6.0])
        open_play(env, a)
        total = 0.0
        passes = 0
        for _ in range(250):
            acts = stand_actions(env)
            c = env.possessor
            if c in (a, b) and not env.dead:
                other = b if c == a else a
                if env.masks[0][c][A.PASS_FEET_START + other]:
                    acts[c] = A.PASS_FEET_START + other
                    passes += 1
            r, _, _, _ = env.step(acts)
            total += r[a] + r[b]
        self.assertGreater(passes, 10)
        self.assertLess(total, 0.1, f"ping-pong farmed {total:.3f} reward over {passes} passes")


class TestCheckpointing(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp(prefix="fb_ck_")
        self.steps = os.path.join(self.dir, "checkpoints")

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def _payload(self, val: float):
        return {"model": {"w": torch.full((4,), val)}, "config": Config().to_dict()}

    def _pair(self, red: float, blue: float = None):
        return {"red": self._payload(red), "blue": self._payload(red if blue is None else blue)}

    def test_save_versioned_and_latest(self):
        ck = CheckpointManager(self.dir, keep_last=3)
        for s in (100, 200, 300):
            ck.save(self._pair(s, -s), s)
        ck.save(self._pair(400, -400), 400, full=True)
        root = sorted(os.listdir(self.dir))
        for name in ("latest.json", "latest_red.pt", "latest_red.pt.sha256", "latest_blue.pt",
                     "latest_blue.pt.sha256"):
            self.assertIn(name, root)
        self.assertFalse([n for n in root if n.startswith("checkpoint_step")])
        names = os.listdir(self.steps)
        self.assertIn("checkpoint_step_000000000100_red.pt", names)
        self.assertIn("checkpoint_step_000000000100_blue.pt.sha256", names)
        for brain in ("red", "blue"):
            self.assertTrue(os.path.exists(os.path.join(
                self.dir, "full", f"checkpoint_step_000000000400_{brain}.pt")))
        paths, data = ck.load_latest_valid()
        self.assertEqual(data["red"]["global_step"], 400)
        self.assertEqual(data["red"]["arch_version"], ARCH_VERSION)
        self.assertEqual(data["red"]["brain"], "red")
        self.assertEqual(float(data["red"]["model"]["w"][0]), 400.0)    # separate weights
        self.assertEqual(float(data["blue"]["model"]["w"][0]), -400.0)
        for s in (500, 600, 700):                        # retention keeps last 3 light steps
            ck.save(self._pair(s), s)
        light = [n for n in os.listdir(self.steps) if n.endswith(".pt")]
        self.assertEqual(len(light), 6)                  # 3 steps x (red + blue)
        self.assertTrue(os.path.exists(os.path.join(self.dir, "full",
                                                    "checkpoint_step_000000000400_red.pt")))

    def test_corrupted_newest_falls_back(self):
        ck = CheckpointManager(self.dir, keep_last=10)
        ck.save(self._pair(1.0), 1000)
        ck.save(self._pair(2.0), 2000)
        newest = os.path.join(self.steps, "checkpoint_step_000000002000_blue.pt")
        with open(newest, "r+b") as f:                   # flip bytes in the middle
            f.seek(200)
            f.write(b"\x00garbage\x00" * 8)
        with open(os.path.join(self.dir, "latest_blue.pt"), "wb") as f:
            f.write(b"truncated")
        paths, data = ck.load_latest_valid()             # both brains must share one step
        self.assertEqual(data["red"]["global_step"], 1000)
        self.assertEqual(data["blue"]["global_step"], 1000)
        self.assertTrue(paths["blue"].endswith("checkpoint_step_000000001000_blue.pt"))
        path, red = ck.load_latest_brain("red")          # single brain: newest red is fine
        self.assertEqual(red["global_step"], 2000)

    def test_nan_weights_rejected(self):
        ck = CheckpointManager(self.dir, keep_last=10)
        ck.save(self._pair(1.0), 10)
        ck.save({"red": self._payload(1.0),
                 "blue": {"model": {"w": torch.tensor([float("nan")])}, "config": {}}}, 20)
        _, data = ck.load_latest_valid()
        self.assertEqual(data["blue"]["global_step"], 10)

    def test_single_brain_checkpoints_are_split(self):
        import json
        from football.checkpoint import _fsync_write, _sha256
        import io as _io

        def old_save(path, step, full=False):
            payload = {"model": {"w": torch.full((4,), float(step))}, "config": {},
                       "global_step": step, "arch_version": ARCH_VERSION,
                       "results": {"self": [1, 2, 3], "scripted": [4, 5, 6]},
                       "pool": {"entries": [{"id": 0, "path": os.path.join(
                           self.dir, "pool", "pool_step_000000000050.pt"), "step": 50,
                           "w": 0, "d": 0, "l": 0}], "next_id": 1}}
            buf = _io.BytesIO()
            torch.save(payload, buf)
            _fsync_write(path, buf.getvalue())
            _fsync_write(path + ".sha256", _sha256(buf.getvalue()).encode())
        os.makedirs(os.path.join(self.dir, "full"))
        os.makedirs(os.path.join(self.dir, "pool"))
        old_save(os.path.join(self.dir, "checkpoint_step_000000000100.pt"), 100)
        old_save(os.path.join(self.dir, "checkpoint_step_000000000200.pt"), 200)
        old_save(os.path.join(self.dir, "latest.pt"), 200)
        old_save(os.path.join(self.dir, "full", "checkpoint_step_000000000100.pt"), 100)
        with open(os.path.join(self.dir, "latest.json"), "w") as f:
            json.dump({"path": "x", "step": 200}, f)
        torch.save({"actor": {}, "step": 50}, os.path.join(self.dir, "pool",
                                                           "pool_step_000000000050.pt"))
        ck = CheckpointManager(self.dir)                  # migrates automatically
        paths, data = ck.load_latest_valid()
        self.assertEqual(data["red"]["global_step"], 200)
        self.assertEqual(data["blue"]["brain"], "blue")
        self.assertTrue(torch.equal(data["red"]["model"]["w"], data["blue"]["model"]["w"]))
        self.assertEqual(data["red"]["results"]["rival"], [1, 2, 3])
        self.assertTrue(data["blue"]["pool"]["entries"][0]["path"].endswith(
            os.path.join("pool", "blue", "pool_step_000000000050.pt")))
        for brain in ("red", "blue"):
            self.assertTrue(os.path.exists(os.path.join(self.dir, "pool", brain,
                                                        "pool_step_000000000050.pt")))
        self.assertEqual(len([n for n in os.listdir(self.steps) if n.endswith(".pt")]), 4)
        legacy = os.path.join(self.dir, "legacy_single_brain")
        for name in ("checkpoint_step_000000000100.pt", "checkpoint_step_000000000200.pt",
                     "latest.pt", "latest.json"):
            self.assertTrue(os.path.exists(os.path.join(legacy, name)), name)
        self.assertTrue(os.path.exists(os.path.join(legacy, "full",
                                                    "checkpoint_step_000000000100.pt")))
        from football.checkpoint import migrate_single_brain
        self.assertFalse(migrate_single_brain(self.dir))  # idempotent

    def test_legacy_checkpoint_detected(self):
        legacy = os.path.join(self.dir, "football_model_red.pth")
        torch.save({"policy": {"net.0.weight": torch.zeros(2, 2)}, "epsilon": 0.5}, legacy)
        with self.assertRaises(IncompatibleCheckpoint) as cm:
            CheckpointManager.load_file(legacy)
        self.assertIn("legacy", str(cm.exception))

    def test_no_checkpoint_returns_none(self):
        self.assertIsNone(CheckpointManager(self.dir).load_latest_valid())


class TestTrainingAndEval(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp(prefix="fb_train_")

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def _cfg(self, total):
        cfg = small_cfg(20)
        cfg.train.num_envs = 3
        cfg.train.num_workers = 1
        cfg.train.total_steps = total
        cfg.train.log_dir = os.path.join(self.dir, "logs")
        cfg.train.log_interval_s = 0.0
        cfg.train.eval_interval = 10 ** 12
        cfg.ppo.rollout_len = 16
        cfg.ppo.minibatch_team_samples = 32
        cfg.checkpoint.directory = os.path.join(self.dir, "ck")
        cfg.checkpoint.interval = 48
        cfg.checkpoint.full_interval = 96
        cfg.league.snapshot_interval = 96
        for st in cfg.curriculum:
            st.half_duration_s = 6.0          # 60 decisions per match
        return cfg

    def test_headless_training_checkpoint_and_resume(self):
        from football.trainer import Trainer
        tr = Trainer(self._cfg(300), render=False)
        tr.train()
        self.assertGreaterEqual(tr.global_step, 300)
        self.assertGreater(tr.updates, 0)
        self.assertGreater(tr.matches, 0)
        for brain in ("red", "blue"):
            self.assertTrue(os.path.exists(os.path.join(self.dir, "ck", f"latest_{brain}.pt")))
        for k in range(2):
            self.assertGreaterEqual(len(tr.pools[k].entries), 1)
        first_step = tr.global_step
        w0 = [next(m.parameters()).detach().cpu().clone() for m in tr.models]
        self.assertFalse(torch.equal(w0[0], w0[1]))      # two independent brains
        tr2 = Trainer(self._cfg(first_step + 60), render=False)      # automatic resume
        self.assertEqual(tr2.global_step, first_step)
        for k in range(2):
            self.assertTrue(torch.equal(next(tr2.models[k].parameters()).detach().cpu(), w0[k]))
        self.assertEqual(tr2.updates, tr.updates)
        tr2.train()
        self.assertGreater(tr2.global_step, first_step)
        for m in tr2.models:
            for p in m.parameters():
                self.assertTrue(torch.isfinite(p).all())

    def test_evaluation_mode_deterministic(self):
        from football.evaluate import evaluate
        from football.model import Actor
        dev = select_device("auto")
        cfg = small_cfg(15)
        actor = Actor(cfg.model).to(dev).eval()
        r1 = evaluate(cfg, actor, ("scripted", 1.0), 2, dev, 15.0, seed=3)
        r2 = evaluate(cfg, actor, ("scripted", 1.0), 2, dev, 15.0, seed=3)
        self.assertIn("points", r1)
        self.assertEqual(r1["matches"], 2)
        self.assertAlmostEqual(r1["L_passes"], r2["L_passes"])   # no exploration -> repeatable


class TestHumanAndRendering(unittest.TestCase):
    def test_human_control_overrides_and_is_excluded_from_training(self):
        env = FootballEnv(small_cfg(), seed=21)
        p = 5
        open_play(env)
        env.human_player = p
        env.human_command = {"dir": (1, 0), "shoot": False, "pass": False, "tackle": False}
        o = build_team_obs(env, 0)
        self.assertFalse(o["agent_valid"][p])
        self.assertTrue(o["agent_valid"][np.arange(11) != p].all())
        x0 = env.pos[p, 0]
        acts = stand_actions(env)
        acts[p] = A.STAND                      # the AI's choice is overridden by the human
        for _ in range(5):
            env.step(acts)
        self.assertGreater(env.pos[p, 0] - x0, 2.0)
        self.assertTrue(A.MOVE_START <= env.last_actions[p] < A.MOVE_START + A.NUM_DIRS)

    def test_renderer_draws_headless(self):
        os.environ["SDL_VIDEODRIVER"] = "dummy"
        from football.render import Renderer
        shot_dir = tempfile.mkdtemp(prefix="fb_shot_")
        os.environ["FOOTBALL_SCREENSHOT_DIR"] = shot_dir
        os.environ["FOOTBALL_SCREENSHOT_EVERY"] = "0"
        try:
            r = Renderer(speed=0.0)
            env = FootballEnv(small_cfg(), seed=22)
            env.record_frames = True
            env.team_control = ["scripted", "scripted"]
            r.overlay = True
            for _ in range(30):
                env.step(np.zeros(22, dtype=np.int64))
                r._draw(env, {"step": 1, "episode": 0, "mode": "TEST"}, env.pos, env.bpos, env.bz)
            r.close()
            self.assertTrue(len(os.listdir(shot_dir)) >= 1)
        finally:
            os.environ.pop("FOOTBALL_SCREENSHOT_DIR", None)
            shutil.rmtree(shot_dir, ignore_errors=True)


class TestLongRunStability(unittest.TestCase):
    def test_long_simulation_no_crash_nan_or_leak(self):
        cfg = small_cfg(150)
        env = FootballEnv(cfg, seed=19)
        rng = np.random.default_rng(1)
        tracemalloc.start()
        snap_mem = None
        loose_max = 0.0
        matches = 0
        n_steps = 6000
        for step in range(n_steps):
            if step % 2 == 0:
                env.team_control = ["scripted", "policy"]
            acts = np.array([rng.choice(np.flatnonzero(env.masks[p // 11][p % 11]))
                             for p in range(22)])
            r, rt, done, _ = env.step(acts)
            self.assertTrue(np.all(np.isfinite(env.pos)) and np.all(np.isfinite(env.bpos)))
            self.assertTrue(np.all(np.isfinite(r)))
            loose_max = max(loose_max, env.loose_time)
            if step == 1500:
                snap_mem = tracemalloc.get_traced_memory()[0]
            if done:
                matches += 1
                env.reset()
        mem = tracemalloc.get_traced_memory()[0]
        tracemalloc.stop()
        self.assertGreaterEqual(matches, 3)
        self.assertLessEqual(loose_max, 15.2)        # dropped-ball rule prevents deadlocks
        self.assertLess(mem - snap_mem, 20 * 2 ** 20, "memory grows during simulation")


if __name__ == "__main__":
    unittest.main(verbosity=2)
