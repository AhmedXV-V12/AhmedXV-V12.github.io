# JOWA Football AI — 11v11 multi-agent football

A full 11v11 football simulation (4-4-2, real pitch dimensions, simplified laws of the game)
with a hierarchical multi-agent reinforcement-learning system: an entity-transformer MAPPO
actor-critic shared by all 22 players, a learned team-level tactical "coach", a rule-based
tactical layer, self-play against a historical opponent pool, curriculum learning, and
crash-safe checkpointing with automatic resume. Training is **visible by default**.

## Quick start

```bash
pip install torch pygame numpy          # torch with CUDA (e.g. cu121) for the RTX 4060
python jowa-football-ai.py --train      # visible training, resumes automatically
```

| Command | What it does |
|---|---|
| `python jowa-football-ai.py` | Normal mode: visible training at real-time 1× speed. |
| `python jowa-football-ai.py --train` | Visible training at MAX speed (fast). Both resume from the newest valid checkpoint. |
| `python jowa-football-ai.py --train-headless` | Opt-in headless training (no window). |
| `python jowa-football-ai.py --play` | Watch the red brain vs the blue brain, deterministic (no exploration, no training). |
| `python jowa-football-ai.py --play --blue scripted` | Red brain vs the rule-based AI. |
| `python jowa-football-ai.py --play --red blue` | The blue brain plays the red side (`--red`/`--blue` accept `latest`, `red`, `blue`, `scripted` or a file). |
| `python jowa-football-ai.py --play --blue checkpoints/full/checkpoint_step_000000500000_blue.pt` | Red brain vs a historical blue checkpoint. |
| `python jowa-football-ai.py --play --red scripted --blue scripted` | Demo of the simulation without any model. |
| `python jowa-football-ai.py --eval 10` | Headless deterministic evaluation (10 matches vs scripted, alternating sides). |
| `python -m unittest discover -s tests -v` | Test suite. |

Useful options: `--num-envs 16 --workers 8` (parallel matches), `--speed 1` (start at
real time), `--allow-human` (take control of a player during training), `--fresh`
(new run; old checkpoints are *archived*, never deleted), `--checkpoint-dir DIR`,
`--checkpoint-interval N`, `--full-checkpoint-interval N`, `--half-seconds S`,
`--formation 4-3-3`, `--no-kickstart`, `--device cpu|cuda`.

### Window controls

| Key | Action |
|---|---|
| `P` (or `SPACE` when not controlling) | pause / resume training |
| `1`…`8`, `+`/`-` | speed 0.5×, 1×, 2×, 5×, 10×, 20×, 50×, MAX (default: 1× normal mode / `--play`, MAX for `--train`) |
| `O` | tactical overlay (anchors, defensive lines, pass options coloured by success probability) |
| `H` | toggle stats panel |
| `R` | pitch rendering on/off (window stays open, training at full speed) |
| `S` | save a screenshot to `screenshots/` |
| `TAB`/`↑`/`↓`, `ENTER`, `ESC` | select a player, take control, release control back to the AI |
| `WASD`/arrows, `SPACE`, `F`, `T` | move, shoot, pass (best-evaluated option), tackle |
| `Q` or close window | save a checkpoint and exit safely |

At **MAX** speed the window redraws at 30 FPS showing the live match being trained on
(env 0), while the other matches run in worker processes. Rendering never blocks training
at MAX; at slower speeds the whole training loop is throttled to that pace (use `2` for
real-time 1×).

## Architecture

```
football/
  config.py       all settings (dataclasses); serialised into every checkpoint
  geometry.py     pitch coordinates, team frame, xG / expected-threat (xT) models
  formation.py    roles (GK, CB, FB, CM, WM, ST) and data-driven formations (4-4-2, 4-3-3)
  engine.py       physics + rules engine (FootballEnv)
  tactics.py      tactical layer: phase FSM, coach instruction, formation deformation,
                  marking, cover lanes, support spots, runs, pass & shot evaluation
  actions.py      hybrid action space
  observation.py  entity-token observations
  rewards.py      reward system (potential-based team shaping + guarded individual terms)
  scripted.py     rule-based AI (benchmark opponent / early curriculum / kickstart teacher)
  model.py        entity transformer actor & centralised critic, CUDA-graph inference
  ppo.py          MAPPO rollout buffer, GAE, value normalisation, update
  league.py       opponent pool (PFSP self-play) and curriculum
  vec_env.py      multi-process vectorised environments (env 0 local & rendered)
  checkpoint.py   atomic, checksummed, versioned checkpoints with fallback loading
  trainer.py      training orchestration, logging, evaluation, resume
  evaluate.py     deterministic matches / evaluation
  render.py       Pygame renderer and controls
legacy/           the original 6v6 DQN code and models (preserved, not loaded)
tests/            unittest suite
```

### Simulation
Metres on a 105×68 m pitch. Physics runs at 20 Hz, agents decide at 5 Hz. Players have
acceleration limits, sprint/jog speeds and stamina; the ball has rolling friction, drag,
height (lofted passes, shots over the bar, headers, bounces) and segment-based contact
detection (no tunnelling). Rules: kick-off, halves with side switch, full time, goals,
throw-ins, corners, goal kicks, direct/indirect free kicks, fouls from tackles (more
likely from behind), penalties, offside (judged at the pass, punished on first touch),
GK handling in the box with a 6-second limit, 9.15 m walls, double touch, dropped-ball
restart if the ball is unclaimed for 15 s. The match clock is displayed scaled to 45:00
per half (simulated half length is configurable; default 300 s).

### Action space (per player, masked)
`STAND`, 8 directional moves/dribbles (team frame, "forward" is always the same index),
7 tactical options whose targets come from the tactical layer — `TO_ANCHOR`, `PRESS`,
`MARK`, `COVER`, `INTERCEPT`, `SUPPORT`, `RUN_BEHIND` — plus `TACKLE`, `SHOOT`, `CLEAR`,
and a **pointer over teammates** for `PASS_FEET` and `PASS_THROUGH`. The policy decides
*what* to do (who presses, who covers, when to run in behind, whom to pass to, whether to
shoot); the controller only executes the movement. Invalid actions are masked (no shooting
from 40 m or by the goalkeeper, tackles only in range, GK-specific restrictions, set-piece
takers' allowed kicks, …).

### Observations
24 entity tokens per team (context, ball, 11 teammates, 11 opponents) × 56 features in the
team frame: positions/velocities, roles, stamina, distance and time-to-ball, formation
anchor and zone deviation, openness, marking, offside position, threat, and for the team
in possession a pre-computed evaluation of every pass option (success probability for
feet/through balls, progress, expected value, lofted or ground). The context token carries
score, clock, possession, tactical phase, coach instruction, set piece and both teams'
shape (centroid, width, length, defensive/attacking/offside lines, compactness).

### Network & RL algorithm: MAPPO with an entity transformer
* One **shared actor** for all 22 players (role-conditioned through role embeddings):
  3 transformer layers, d=192, 6 heads, with a learned **geometric attention bias** from
  pairwise offsets/distances. Output per player: 19 base logits + bilinear pointer logits
  over teammates for passes. A **coach head** on the context token outputs the team
  instruction (block height × style).
* A separate **centralised critic** (same encoder type) outputs a value per player (each
  player has its own reward stream) and a team value for the coach.
* **PPO** with clipped objective, clipped value loss, running value normalisation, GAE
  (γ=0.995, λ=0.95 at 5 Hz ≈ 40 s horizon), entropy bonus, KL early stopping, gradient
  clipping, bf16 autocast for updates, and CUDA-graph-captured rollout inference.
* **Why not DQN**: 22 simultaneously-acting agents make the environment non-stationary
  for independent Q-learners; replay buffers of stale joint behaviour and ε-greedy
  exploration over a masked, state-dependent action set scale badly. On-policy MAPPO with
  parameter sharing and a centralised critic is the standard, stable choice for
  cooperative-competitive multi-agent games (it is what works on Google Research Football).

### How the 22 agents coordinate
Coordination happens at three levels: (1) the **tactical layer** gives every player the
same team picture (phase, lines, anchors, marking assignment, dangerous lanes); (2) the
**transformer** lets each player's decision attend to all teammates, opponents and the
ball in one forward pass per team — an implicit communication channel; (3) the **coach**
chooses the team instruction that shifts the whole formation. Rewards that depend on the
team (potentials for pressure, passing options and exposure) make teammates' behaviour
matter to each player's return.

### Tactical system
A finite-state manager per team: `BUILD UP`, `ATTACK`, `COUNTER ATTACK`,
`TRANSITION TO DEF` (counter-press window after losing the ball), `PRESSING`,
`HIGH/MID/LOW BLOCK`, `LOOSE BALL`, set pieces. The learned coach picks block height
(high/mid/low) and style (possession/direct) every 3 s. The formation blends between its
compact defensive shape and its attacking shape (4-4-2 → 2-3-5: full-backs join midfield,
wide midfielders and one CM join the strikers) according to the phase; line heights follow
the ball, the block height and the opponent's offside line, with ball-side shift.

### Reward system
* Team (shared): goal ±1; **potential-based shaping** γΦ(s′)−Φ(s) with Φ = expected threat
  of possession + pressure on the opposing carrier + quality of our passing options −
  exposure of dangerous unmarked opponents. Potential-based shaping cannot be farmed by
  cycles (ping-pong passing, hoarding the ball) — there is a test for this.
* Individual (small, event-based): completed passes (decaying if not progressive),
  progressive passes (only when the team's possession frontier advances), shot quality
  (xG-weighted; hopeless shots penalised), recoveries, interceptions, blocks, saves;
  penalties for turnovers (worse in own third), fouls, conceding penalties, offside,
  putting the ball out, collisions.
* Structural regularisers: leaving the tactical zone when not engaged in play, crowding
  teammates, surplus players around the ball (anti ball-chasing), holding the ball
  without progress (plus a hard limit), sprint cost.
* Anti-exploit mechanisms: action masks, dropped-ball rule, GK holding limit, stall limit,
  frontier-based pass credit, per-component reward logging so exploits are visible.

### Two brains, league and curriculum
Two independent brains are trained: **red** (always team 0) and **blue** (always team 1).
Each has its own network, optimizer, value normalisers and opponent pool
(`checkpoints/pool/red/`, `checkpoints/pool/blue/`), and learns only from the slots it plays.
Opponents per match: red brain vs blue brain (both learn), one brain vs a frozen snapshot
of the *other* brain from its **historical pool** (sampled by prioritised fictitious
self-play — opponents the learner struggles against are chosen more often), or the
scripted AI. Seven curriculum stages
move from a weakened scripted opponent with short halves and no offside/fouls to full
self-play with long matches and reduced shaping; stage 5 is gated on ≥45% points vs the
scripted AI. During the first 3M steps a decaying imitation loss towards the scripted AI
("kickstarting") speeds up the start; it reaches zero and RL takes over completely
(disable with `--no-kickstart`).

### Checkpointing and automatic resume
Every save writes **one file per brain** for the same step:
```
checkpoints/
  latest.json                       pointer + metadata of the newest red/blue pair
  latest_red.pt   (+ .sha256)       newest red brain
  latest_blue.pt  (+ .sha256)       newest blue brain
  checkpoints/checkpoint_step_XXXXXXXXXXXX_red.pt / _blue.pt   rolling, last 20 steps kept
  full/checkpoint_step_XXXXXXXXXXXX_red.pt / _blue.pt          never deleted
  pool/red/  pool/blue/             historical snapshots of each brain
  legacy_single_brain/              files from the old single-brain trainer (archived)
```
* Lightweight checkpoints every `CheckpointConfig.interval` (50,000 env steps; about every
  minute); full checkpoints every `full_interval` (500,000).
* Old single-brain checkpoints are split automatically on start (both brains begin with the
  same weights and diverge); the originals are moved to `legacy_single_brain/`, never deleted.
* Contents of each brain file: its model, optimizer, value normalisers, opponent pool and
  win/draw/loss stats; plus the shared state (step/update/match counters, curriculum stage,
  recent match statistics, exploration state, RNG states, full config, seed, version info).
  The PPO rollout in progress (at most 128 steps) is not saved.
* Every file is written to a temp name, fsync'ed and atomically renamed, with a SHA-256
  sidecar. On start the newest step where *both* brains are valid is loaded; if one is corrupted, has a checksum
  mismatch, NaN weights or an incompatible architecture, the error is logged and the next
  older one is tried. A final checkpoint is saved on `Q`, window close, Ctrl+C, SIGTERM or
  after an exception.
* The old 6v6 DQN `.pth` files are detected and explicitly rejected (architecture changed
  completely); they are preserved in `legacy/`.

### Logs
`logs/train.log` (human-readable), `logs/metrics.jsonl` (one record per log interval),
`logs/eval.jsonl` (background deterministic evaluations vs the scripted AI every 2M steps).
