import pygame
import random
import math
import os
import json
import time
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque

# Global Configuration & Device Setup
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
WIDTH, HEIGHT = 800, 600
FIELD_MARGIN = 50
GOAL_WIDTH = 120
PLAYER_RADIUS = 15
BALL_RADIUS = 10
MAX_SPEED = 4.0
KICK_FORCE = 6.0
FRICTION = 0.98
FPS = 60
CORNER_SIZE = 40

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (220, 20, 60)
BLUE = (30, 144, 255)
GREEN = (34, 139, 34)
YELLOW = (255, 215, 0)
GRAY = (105, 105, 105)
ORANGE = (255, 165, 0)

# Actions: [Stop, N, S, E, W, NE, NW, SE, SW]
ACTIONS = [(0, 0), (0, -1), (0, 1), (1, 0), (-1, 0), (0.707, -0.707), (-0.707, -0.707), (0.707, 0.707), (-0.707, 0.707)]

class DQN(nn.Module):
    def __init__(self, input_size, output_size):
        super(DQN, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_size, 256),
            nn.ReLU(),
            nn.Linear(256,256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, output_size)
        )
        self._init_weights()

    def _init_weights(self):
        for m in self.net:
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=math.sqrt(2))
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        return self.net(x)

class SharedReplayBuffer:
    def __init__(self, capacity=200000):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((
            np.array(state, dtype=np.float32),
            action,
            reward,
            np.array(next_state, dtype=np.float32),
            done
        ))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*batch)
        return (torch.FloatTensor(np.array(state)).to(DEVICE),
                torch.LongTensor(action).unsqueeze(1).to(DEVICE),
                torch.FloatTensor(reward).unsqueeze(1).to(DEVICE),
                torch.FloatTensor(np.array(next_state)).to(DEVICE),
                torch.FloatTensor(done).unsqueeze(1).to(DEVICE))

    def __len__(self):
        return len(self.buffer)

class MultiAgentBrain:
    def __init__(self, state_size, action_size, team_name="team"):
        self.team_name = team_name
        self.state_size = state_size
        self.action_size = action_size
        self.policy_net = DQN(state_size, action_size).to(DEVICE)
        self.target_net = DQN(state_size, action_size).to(DEVICE)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=0.00025)
        self.memory = SharedReplayBuffer()
        self.gamma = 0.99
        self.tau = 0.005
        self.epsilon = 1.0
        self.epsilon_min = 0.1
        self.epsilon_decay = 0.999995
        self.batch_size = 128
        self.warmup = 2000

    def choose_action(self, state, eval_mode=False):
        if not eval_mode and random.random() < self.epsilon:
            return random.randrange(self.action_size)
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0).to(DEVICE)
            return self.policy_net(state_t).argmax().item()

    def train_step(self):
        if len(self.memory) < self.warmup:
            return
        states, actions, rewards, next_states, dones = self.memory.sample(self.batch_size)
        with torch.no_grad():
            next_actions = self.policy_net(next_states).argmax(1).unsqueeze(1)
            next_q = self.target_net(next_states).gather(1, next_actions)
            target_q = rewards + (self.gamma * next_q * (1 - dones))
        current_q = self.policy_net(states).gather(1, actions)
        loss = nn.HuberLoss()(current_q, target_q)
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy_net.parameters(), 1.0)
        self.optimizer.step()
        for tp, pp in zip(self.target_net.parameters(), self.policy_net.parameters()):
            tp.data.copy_(self.tau * pp.data + (1 - self.tau) * tp.data)
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

    def save(self, path=None):
        if path is None:
            path = f"football_model_{self.team_name}.pth"
        torch.save({'policy': self.policy_net.state_dict(), 'epsilon': self.epsilon}, path)

    def load(self, path=None, force_epsilon=None):
        if path is None:
            path = f"football_model_{self.team_name}.pth"
        if os.path.exists(path):
            checkpoint = torch.load(path, map_location=DEVICE)
            self.policy_net.load_state_dict(checkpoint['policy'])
            self.target_net.load_state_dict(checkpoint['policy'])
            if force_epsilon is not None:
                self.epsilon = force_epsilon
                print(f"Loaded {path} - Epsilon forced to {force_epsilon}")
            else:
                self.epsilon = checkpoint.get('epsilon', self.epsilon)
                print(f"Loaded {path} - Epsilon: {self.epsilon:.4f}")

class Ball:
    def __init__(self):
        self.reset()
        self.last_kicker = None

    def reset(self):
        self.x, self.y = WIDTH // 2, HEIGHT // 2
        self.vx, self.vy = 0, 0
        self.last_kicker = None

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vx *= FRICTION
        self.vy *= FRICTION
        if abs(self.vx) < 0.1: self.vx = 0
        if abs(self.vy) < 0.1: self.vy = 0

        if self.y - BALL_RADIUS < FIELD_MARGIN:
            self.vy *= -0.8
            self.y = FIELD_MARGIN + BALL_RADIUS
        elif self.y + BALL_RADIUS > HEIGHT - FIELD_MARGIN:
            self.vy *= -0.8
            self.y = HEIGHT - FIELD_MARGIN - BALL_RADIUS

        in_goal_y = HEIGHT // 2 - GOAL_WIDTH // 2 < self.y < HEIGHT // 2 + GOAL_WIDTH // 2
        if self.x - BALL_RADIUS < FIELD_MARGIN:
            if not in_goal_y:
                self.vx *= -0.8
                self.x = FIELD_MARGIN + BALL_RADIUS
        elif self.x + BALL_RADIUS > WIDTH - FIELD_MARGIN:
            if not in_goal_y:
                self.vx *= -0.8
                self.x = WIDTH - FIELD_MARGIN - BALL_RADIUS

        if self.x < FIELD_MARGIN + CORNER_SIZE and self.y < FIELD_MARGIN + CORNER_SIZE:
            if (FIELD_MARGIN + CORNER_SIZE - self.x) + (FIELD_MARGIN + CORNER_SIZE - self.y) > CORNER_SIZE:
                self.vx, self.vy = abs(self.vx) * 0.8 + 1, abs(self.vy) * 0.8 + 1
                self.x, self.y = FIELD_MARGIN + CORNER_SIZE, FIELD_MARGIN + CORNER_SIZE
        elif self.x > WIDTH - FIELD_MARGIN - CORNER_SIZE and self.y < FIELD_MARGIN + CORNER_SIZE:
            if (self.x - (WIDTH - FIELD_MARGIN - CORNER_SIZE)) + (FIELD_MARGIN + CORNER_SIZE - self.y) > CORNER_SIZE:
                self.vx, self.vy = -abs(self.vx) * 0.8 - 1, abs(self.vy) * 0.8 + 1
                self.x, self.y = WIDTH - FIELD_MARGIN - CORNER_SIZE, FIELD_MARGIN + CORNER_SIZE
        elif self.x < FIELD_MARGIN + CORNER_SIZE and self.y > HEIGHT - FIELD_MARGIN - CORNER_SIZE:
            if (FIELD_MARGIN + CORNER_SIZE - self.x) + (self.y - (HEIGHT - FIELD_MARGIN - CORNER_SIZE)) > CORNER_SIZE:
                self.vx, self.vy = abs(self.vx) * 0.8 + 1, -abs(self.vy) * 0.8 - 1
                self.x, self.y = FIELD_MARGIN + CORNER_SIZE, HEIGHT - FIELD_MARGIN - CORNER_SIZE
        elif self.x > WIDTH - FIELD_MARGIN - CORNER_SIZE and self.y > HEIGHT - FIELD_MARGIN - CORNER_SIZE:
            if (self.x - (WIDTH - FIELD_MARGIN - CORNER_SIZE)) + (self.y - (HEIGHT - FIELD_MARGIN - CORNER_SIZE)) > CORNER_SIZE:
                self.vx, self.vy = -abs(self.vx) * 0.8 - 1, -abs(self.vy) * 0.8 - 1
                self.x, self.y = WIDTH - FIELD_MARGIN - CORNER_SIZE, HEIGHT - FIELD_MARGIN - CORNER_SIZE

    def draw(self, screen):
        pygame.draw.circle(screen, WHITE, (int(self.x), int(self.y)), BALL_RADIUS)
        pygame.draw.circle(screen, BLACK, (int(self.x), int(self.y)), BALL_RADIUS, 2)

class Player:
    def __init__(self, x, y, color, team_id, player_id, role):
        self.x, self.y = x, y
        self.start_x, self.start_y = x, y
        self.color = color
        self.team_id = team_id
        self.player_id = player_id
        self.role = role # 0: Attacker, 1: Midfielder, 2: Defender
        self.vx, self.vy = 0, 0
        self.just_passed = False

    def reset(self):
        self.x, self.y = self.start_x, self.start_y
        self.vx, self.vy = 0, 0
        self.just_passed = False

    def get_state(self, ball, teammates, opponents):
        side = 1 if self.team_id == 0 else -1
        def transform_x(x_val): return x_val if side == 1 else WIDTH - x_val
        def transform_vx(vx_val): return vx_val * side
        
        my_x, my_y = transform_x(self.x), self.y
        b_x, b_y = transform_x(ball.x), ball.y
        b_vx, b_vy = transform_vx(ball.vx), ball.vy
        
        state = [
            (b_x - my_x) / WIDTH, (b_y - my_y) / HEIGHT,
            (WIDTH - FIELD_MARGIN - my_x) / WIDTH, (HEIGHT/2 - my_y) / HEIGHT,
            (FIELD_MARGIN - my_x) / WIDTH, (HEIGHT/2 - my_y) / HEIGHT,
            b_vx / KICK_FORCE, b_vy / KICK_FORCE,
            my_x / WIDTH, my_y / HEIGHT,
            self.role / 2.0
        ]
        
        for group in [teammates, opponents]:
            if group:
                nearest = min(group, key=lambda p: math.hypot(p.x - self.x, p.y - self.y))
                state.extend([(transform_x(nearest.x) - my_x) / WIDTH, (nearest.y - my_y) / HEIGHT])
            else:
                state.extend([0, 0])
        return np.array(state, dtype=np.float32)

    def apply_action(self, action_idx):
        ax, ay = ACTIONS[action_idx]
        side = 1 if self.team_id == 0 else -1
        self.vx, self.vy = (ax * side) * MAX_SPEED, ay * MAX_SPEED
        self.x += self.vx
        self.y += self.vy
        self.x = max(FIELD_MARGIN + PLAYER_RADIUS, min(WIDTH - FIELD_MARGIN - PLAYER_RADIUS, self.x))
        self.y = max(FIELD_MARGIN + PLAYER_RADIUS, min(HEIGHT - FIELD_MARGIN - PLAYER_RADIUS, self.y))

    def handle_collisions(self, ball, others):
        dist = math.hypot(self.x - ball.x, self.y - ball.y)
        if dist < PLAYER_RADIUS + BALL_RADIUS:
            if ball.last_kicker is not None and ball.last_kicker.team_id == self.team_id and ball.last_kicker != self:
                ball.last_kicker.just_passed = True
            
            ball.last_kicker = self
            angle = math.atan2(ball.y - self.y, ball.x - self.x)
            overlap = (PLAYER_RADIUS + BALL_RADIUS) - dist
            ball.x += math.cos(angle) * overlap
            ball.y += math.sin(angle) * overlap
            ball.vx += math.cos(angle) * KICK_FORCE * 0.5 + self.vx * 0.5
            ball.vy += math.sin(angle) * KICK_FORCE * 0.5 + self.vy * 0.5
            
        for other in others:
            if other == self: continue
            d = math.hypot(self.x - other.x, self.y - other.y)
            if d < PLAYER_RADIUS * 2:
                angle = math.atan2(other.y - self.y, other.x - self.x)
                overlap = (PLAYER_RADIUS * 2) - d
                self.x -= math.cos(angle) * (overlap / 2)
                self.y -= math.sin(angle) * (overlap / 2)
                other.x += math.cos(angle) * (overlap / 2)
                other.y += math.sin(angle) * (overlap / 2)

    def draw(self, screen, is_selected=False, is_controlled=False):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), PLAYER_RADIUS)
        pygame.draw.circle(screen, BLACK, (int(self.x), int(self.y)), PLAYER_RADIUS, 2)
        role_char = ["A", "M", "D"][self.role]
        font = pygame.font.SysFont("Arial", 12, bold=True)
        text = font.render(role_char, True, WHITE)
        screen.blit(text, (int(self.x) - 4, int(self.y) - 6))
        if is_selected:
            pygame.draw.circle(screen, YELLOW, (int(self.x), int(self.y)), PLAYER_RADIUS + 3, 3)
        if is_controlled:
            pygame.draw.circle(screen, ORANGE, (int(self.x), int(self.y)), PLAYER_RADIUS + 6, 2)

class GameEngine:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("AI Football 6v6 - Formation 3-2-1 (Auto Epsilon)")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("Arial", 24)
        self.small_font = pygame.font.SysFont("Arial", 16)
        
        self.red_brain = MultiAgentBrain(state_size=15, action_size=len(ACTIONS), team_name="red")
        self.blue_brain = MultiAgentBrain(state_size=15, action_size=len(ACTIONS), team_name="blue")
        
        # --- EPSILON CONFIGURATION ---
        # Set to None to use the epsilon saved in the .pth file (Auto Epsilon)
        TEMP_EXPLORATION_EPSILON = None 
        
        self.red_brain.load("football_model_red.pth", force_epsilon=TEMP_EXPLORATION_EPSILON)
        self.blue_brain.load("football_model_blue.pth", force_epsilon=TEMP_EXPLORATION_EPSILON)
        
        self.ball = Ball()
        self.players = self._init_players()
        self.score = [0, 0]
        self.running = True
        self.selected_player_index = 0
        self.controlled_player_index = None
        self.selection_mode = True
        self.keys_pressed = {}

    def _init_players(self):
        p = []
        # Formation 3-2-1 (3 Defenders, 2 Midfielders, 1 Attacker)
        # Red Team (Left)
        p.append(Player(WIDTH//4 + 200, HEIGHT//2, RED, 0, 0, 0)) # 1 Attacker
        p.append(Player(WIDTH//4 + 50, HEIGHT//2 - 80, RED, 0, 1, 1)) # 2 Midfielders
        p.append(Player(WIDTH//4 + 50, HEIGHT//2 + 80, RED, 0, 2, 1))
        p.append(Player(WIDTH//4 - 100, HEIGHT//2, RED, 0, 3, 2)) # 3 Defenders
        p.append(Player(WIDTH//4 - 100, HEIGHT//2 - 120, RED, 0, 4, 2))
        p.append(Player(WIDTH//4 - 100, HEIGHT//2 + 120, RED, 0, 5, 2))
        
        # Blue Team (Right)
        p.append(Player(3*WIDTH//4 - 200, HEIGHT//2, BLUE, 1, 6, 0)) # 1 Attacker
        p.append(Player(3*WIDTH//4 - 50, HEIGHT//2 - 80, BLUE, 1, 7, 1)) # 2 Midfielders
        p.append(Player(3*WIDTH//4 - 50, HEIGHT//2 + 80, BLUE, 1, 8, 1))
        p.append(Player(3*WIDTH//4 + 100, HEIGHT//2, BLUE, 1, 9, 2)) # 3 Defenders
        p.append(Player(3*WIDTH//4 + 100, HEIGHT//2 - 120, BLUE, 1, 10, 2))
        p.append(Player(3*WIDTH//4 + 100, HEIGHT//2 + 120, BLUE, 1, 11, 2))
        return p

    def get_reward(self, player, goal_scored):
        reward = 0.0
        
        # 1. Goal Rewards
        if goal_scored is not None:
            if player.team_id == goal_scored:
                reward += 50.0
            else:
                reward -= 40.0
            return reward

        # 2. Passing Reward
        if player.just_passed:
            reward += 5.0
            player.just_passed = False

        # 3. Distance to Ball & Role Positioning
        dist_to_ball = math.hypot(player.x - self.ball.x, player.y - self.ball.y)
        
        if player.role == 0: # Attacker
            reward -= dist_to_ball * 0.005
            opp_goal_x = WIDTH - FIELD_MARGIN if player.team_id == 0 else FIELD_MARGIN
            dist_ball_to_goal = math.hypot(self.ball.x - opp_goal_x, self.ball.y - HEIGHT//2)
            reward -= dist_ball_to_goal * 0.003
        elif player.role == 1: # Midfielder
            reward -= dist_to_ball * 0.004
            dist_to_center = math.hypot(player.x - WIDTH//2, player.y - HEIGHT//2)
            reward -= dist_to_center * 0.002
        elif player.role == 2: # Defender
            own_goal_x = FIELD_MARGIN if player.team_id == 0 else WIDTH - FIELD_MARGIN
            defensive_pos_x = (self.ball.x + own_goal_x) / 2
            defensive_pos_y = (self.ball.y + HEIGHT//2) / 2
            dist_to_def_pos = math.hypot(player.x - defensive_pos_x, player.y - defensive_pos_y)
            reward -= dist_to_def_pos * 0.01
            if (player.team_id == 0 and self.ball.x < player.x) or (player.team_id == 1 and self.ball.x > player.x):
                reward -= 1.0

        # 4. Ball Interaction
        if dist_to_ball < PLAYER_RADIUS + BALL_RADIUS + 5:
            reward += 2.0
            opp_goal_x = WIDTH - FIELD_MARGIN if player.team_id == 0 else FIELD_MARGIN
            old_dist = math.hypot((self.ball.x - self.ball.vx) - opp_goal_x, (self.ball.y - self.ball.vy) - HEIGHT//2)
            new_dist = math.hypot(self.ball.x - opp_goal_x, self.ball.y - HEIGHT//2)
            if new_dist < old_dist:
                reward += 1.5
            else:
                reward -= 0.5

        # 5. Anti-Clumping
        for other in self.players:
            if other != player and other.team_id == player.team_id:
                d = math.hypot(player.x - other.x, player.y - other.y)
                if d < PLAYER_RADIUS * 6:
                    reward -= 0.8

        return reward

    def step(self):
        team_data = {0: {"states": [], "actions": [], "players": []}, 
                     1: {"states": [], "actions": [], "players": []}}
        
        for i, p in enumerate(self.players):
            if i == self.controlled_player_index:
                continue
            
            brain = self.red_brain if p.team_id == 0 else self.blue_brain
            teammates = [o for o in self.players if o.team_id == p.team_id and o != p]
            opponents = [o for o in self.players if o.team_id != p.team_id]
            s = p.get_state(self.ball, teammates, opponents)
            a = brain.choose_action(s)
            
            team_data[p.team_id]["states"].append(s)
            team_data[p.team_id]["actions"].append(a)
            team_data[p.team_id]["players"].append(p)
            p.apply_action(a)

        self.ball.update()
        for p in self.players:
            p.handle_collisions(self.ball, self.players)

        goal_scored = None
        in_goal_y = HEIGHT // 2 - GOAL_WIDTH // 2 < self.ball.y < HEIGHT // 2 + GOAL_WIDTH // 2
        if in_goal_y:
            if self.ball.x < FIELD_MARGIN:
                self.score[1] += 1
                goal_scored = 1
            elif self.ball.x > WIDTH - FIELD_MARGIN:
                self.score[0] += 1
                goal_scored = 0

        for tid in [0, 1]:
            brain = self.red_brain if tid == 0 else self.blue_brain
            for i, p in enumerate(team_data[tid]["players"]):
                teammates = [o for o in self.players if o.team_id == p.team_id and o != p]
                opponents = [o for o in self.players if o.team_id != p.team_id]
                next_s = p.get_state(self.ball, teammates, opponents)
                r = self.get_reward(p, goal_scored)
                brain.memory.push(team_data[tid]["states"][i], team_data[tid]["actions"][i], r, next_s, goal_scored is not None)
            brain.train_step()
        
        if goal_scored is not None:
            self.ball.reset()
            for p in self.players: p.reset()

    def draw(self):
        self.screen.fill(GREEN)
        pygame.draw.rect(self.screen, WHITE, (FIELD_MARGIN, FIELD_MARGIN, WIDTH-2*FIELD_MARGIN, HEIGHT-2*FIELD_MARGIN), 3)
        pygame.draw.line(self.screen, WHITE, (WIDTH//2, FIELD_MARGIN), (WIDTH//2, HEIGHT-FIELD_MARGIN), 3)
        pygame.draw.circle(self.screen, WHITE, (WIDTH//2, HEIGHT//2), 70, 3)
        pygame.draw.rect(self.screen, RED, (FIELD_MARGIN-10, HEIGHT//2 - GOAL_WIDTH//2, 10, GOAL_WIDTH))
        pygame.draw.rect(self.screen, BLUE, (WIDTH-FIELD_MARGIN, HEIGHT//2 - GOAL_WIDTH//2, 10, GOAL_WIDTH))
        for i, p in enumerate(self.players):
            is_selected = (self.selection_mode and i == self.selected_player_index)
            is_controlled = (not self.selection_mode and i == self.controlled_player_index)
            p.draw(self.screen, is_selected, is_controlled)
        self.ball.draw(self.screen)
        score_text = self.font.render(f"RED {self.score[0]} - {self.score[1]} BLUE", True, WHITE)
        self.screen.blit(score_text, (WIDTH//2 - 80, 10))
        eps_text = self.small_font.render(f"Eps Red: {self.red_brain.epsilon:.2f} Blue: {self.blue_brain.epsilon:.2f}", True, WHITE)
        self.screen.blit(eps_text, (10, 10))
        pygame.display.flip()

    def run(self):
        save_timer = 0
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT: self.running = False
                if event.type == pygame.KEYDOWN:
                    if self.selection_mode:
                        if event.key == pygame.K_UP: self.selected_player_index = (self.selected_player_index - 1) % len(self.players)
                        elif event.key == pygame.K_DOWN: self.selected_player_index = (self.selected_player_index + 1) % len(self.players)
                        elif event.key == pygame.K_RETURN or event.key == pygame.K_SPACE:
                            self.controlled_player_index = self.selected_player_index
                            self.selection_mode = False
                    elif event.key == pygame.K_ESCAPE:
                        self.selection_mode = True
                        self.controlled_player_index = None
            
            self.keys_pressed = pygame.key.get_pressed()
            if not self.selection_mode and self.controlled_player_index is not None:
                player = self.players[self.controlled_player_index]
                up = self.keys_pressed[pygame.K_w] or self.keys_pressed[pygame.K_UP]
                down = self.keys_pressed[pygame.K_s] or self.keys_pressed[pygame.K_DOWN]
                left = self.keys_pressed[pygame.K_a] or self.keys_pressed[pygame.K_LEFT]
                right = self.keys_pressed[pygame.K_d] or self.keys_pressed[pygame.K_RIGHT]
                action_idx = 0
                if up: action_idx = 1
                elif down: action_idx = 2
                elif right: action_idx = 3
                elif left: action_idx = 4
                player.apply_action(action_idx)
            
            self.step()
            self.draw()
            self.clock.tick(FPS)
            save_timer += 1
            if save_timer > 3600:
                self.red_brain.save()
                self.blue_brain.save()
                save_timer = 0
        self.red_brain.save()
        self.blue_brain.save()
        pygame.quit()

if __name__ == "__main__":
    engine = GameEngine()
    engine.run()
